/*
Copyright (c) 2023 Nordix Foundation

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package router

import (
	"context"
	"fmt"
	"net"

	"github.com/meridio-io/meridio/api/v1alpha1"
	"github.com/meridio-io/meridio/pkg/bird"
	"github.com/meridio-io/meridio/pkg/log"
	v1 "k8s.io/api/core/v1"
	apierrors "k8s.io/apimachinery/pkg/api/errors"
	"k8s.io/apimachinery/pkg/runtime"
	ctrl "sigs.k8s.io/controller-runtime"
	"sigs.k8s.io/controller-runtime/pkg/client"
	"sigs.k8s.io/controller-runtime/pkg/handler"
)

// RoutingSuite defines an interface to configure a routing suite (e.g. bird).
type RoutingSuite interface {
	// Apply applies to configuration.
	Apply(ctx context.Context) error
	// SetGateway sets/updates a gateway for the current configuration.
	SetGateway(bird.Gateway)
	// DeleteGateway deletes a gateway for the current configuration.
	DeleteGateway(name string)
	// SetVIPs sets the vips for the current configuration.
	SetVIPs(vips []string)
}

// GatewayController reconciles a Gateway object as a router.
type GatewayController struct {
	client.Client
	Scheme *runtime.Scheme
	// ServiceProxy is used to reconcile the service with the
	// correct label.
	ServiceProxy         string
	RoutingSuiteInstance RoutingSuite
}

// Reconcile implements the reconciliation of the Gateway object as a router.
// This function is trigger by any change (create/update/delete) in any resource related
// to the object (Flow).
//
// For more details, check Reconcile and its Result here:
// - https://pkg.go.dev/sigs.k8s.io/controller-runtime@v0.13.0/pkg/reconcile
func (gc *GatewayController) Reconcile(ctx context.Context, req ctrl.Request) (ctrl.Result, error) {
	// Get the gateway to reconcile and delete it if it could not be found.
	gateway := &v1alpha1.Gateway{}

	err := gc.Get(ctx, req.NamespacedName, gateway)
	if err != nil {
		if apierrors.IsNotFound(err) {
			// Delete gateway if not found
			gc.RoutingSuiteInstance.DeleteGateway(req.NamespacedName.Name)

			err = gc.RoutingSuiteInstance.Apply(ctx)
			if err != nil {
				log.FromContextOrGlobal(ctx).Error(err, "failed to delete the gateway")
			}

			return ctrl.Result{}, nil
		}

		return ctrl.Result{}, fmt.Errorf("failed to get the gateway: %w", err)
	}

	// The service proxy label does not exists or if it does not correspond to the one managed, so the
	// gateway has to be deleted.
	value, exists := gateway.GetLabels()[v1alpha1.LabelServiceProxy]
	if !exists || value != gc.ServiceProxy {
		gc.RoutingSuiteInstance.DeleteGateway(req.NamespacedName.Name)

		err = gc.RoutingSuiteInstance.Apply(ctx)
		if err != nil {
			log.FromContextOrGlobal(ctx).Error(err, "failed to delete the gateway")
		}

		return ctrl.Result{}, nil
	}

	gc.RoutingSuiteInstance.SetGateway(newGateway(gateway))

	err = gc.reconcileFlows(ctx)
	if err != nil {
		return ctrl.Result{}, fmt.Errorf("failed to reconcile the flows: %w", err)
	}

	err = gc.RoutingSuiteInstance.Apply(ctx)
	if err != nil {
		return ctrl.Result{}, fmt.Errorf("failed to set the gateway: %w", err)
	}

	return ctrl.Result{}, nil
}

// reconcileFlows gets the list of flows for this service proxy and adds all
// destination IPs to bird.
func (gc *GatewayController) reconcileFlows(ctx context.Context) error {
	flows := &v1alpha1.FlowList{}
	vips := []string{}

	err := gc.List(ctx,
		flows,
		client.MatchingLabels{
			v1alpha1.LabelServiceProxy: gc.ServiceProxy,
		})
	if err != nil {
		return fmt.Errorf("failed listing the flows: %w", err)
	}

	for _, flow := range flows.Items {
		vips = append(vips, flow.Spec.DestinationCIDRs...)
	}

	// remove duplicates and invalid VIPs
	vipMap := map[string]struct{}{}
	finalVIPList := []string{}

	for _, vip := range vips {
		_, netIP, err := net.ParseCIDR(vip)
		if err != nil {
			continue
		}

		_, exists := vipMap[netIP.String()]
		if exists {
			continue
		}

		finalVIPList = append(finalVIPList, netIP.String())
		vipMap[netIP.String()] = struct{}{}
	}

	gc.RoutingSuiteInstance.SetVIPs(finalVIPList)

	return nil
}

// SetupWithManager sets up the controller with the Manager.
func (gc *GatewayController) SetupWithManager(mgr ctrl.Manager) error {
	err := ctrl.NewControllerManagedBy(mgr).
		For(&v1alpha1.Gateway{}).
		// With EnqueueRequestsFromMapFunc, on an update the func is called twice
		// (1 time for old and 1 time for new object)
		Watches(&v1.Service{}, handler.EnqueueRequestsFromMapFunc(gc.serviceEnqueue)).
		Watches(&v1alpha1.Flow{}, handler.EnqueueRequestsFromMapFunc(gc.flowEnqueue)).
		Complete(gc)
	if err != nil {
		return fmt.Errorf("failed to build the gateway manager: %w", err)
	}

	return nil
}

func newGateway(gw *v1alpha1.Gateway) *gateway {
	protocol := gw.Spec.Protocol
	if protocol == "" {
		protocol = v1alpha1.BGP
	}

	newGw := &gateway{
		name:     gw.GetName(),
		address:  gw.Spec.Address,
		protocol: protocol,
	}

	switch newGw.GetProtocol() {
	case v1alpha1.BGP:
		newGw.bgp = &bgpSpec{
			remoteASN:  gw.Spec.Bgp.RemoteASN,
			localASN:   gw.Spec.Bgp.LocalASN,
			holdTime:   gw.Spec.Bgp.HoldTime,
			remotePort: gw.Spec.Bgp.RemotePort,
			localPort:  gw.Spec.Bgp.LocalPort,
			bfd: &bfdSpec{
				sw:         gw.Spec.Bgp.BFD.Switch,
				minTx:      gw.Spec.Bgp.BFD.MinTx,
				minRx:      gw.Spec.Bgp.BFD.MinRx,
				multiplier: gw.Spec.Bgp.BFD.Multiplier,
			},
		}
	case v1alpha1.Static:
		newGw.static = &staticSpec{
			bfd: &bfdSpec{
				sw:         gw.Spec.Bgp.BFD.Switch,
				minTx:      gw.Spec.Bgp.BFD.MinTx,
				minRx:      gw.Spec.Bgp.BFD.MinRx,
				multiplier: gw.Spec.Bgp.BFD.Multiplier,
			},
		}
	}

	return newGw
}

type gateway struct {
	name     string
	address  string
	protocol v1alpha1.RoutingProtocol
	bgp      *bgpSpec
	static   *staticSpec
}

func (gw *gateway) GetName() string {
	return gw.name
}

func (gw *gateway) GetAddress() string {
	return gw.address
}

func (gw *gateway) GetProtocol() v1alpha1.RoutingProtocol {
	return gw.protocol
}

func (gw *gateway) GetBgpSpec() bird.BgpSpec {
	return gw.bgp
}

func (gw *gateway) GetStatic() bird.StaticSpec {
	return gw.static
}

type bgpSpec struct {
	remoteASN  *uint32
	localASN   *uint32
	bfd        *bfdSpec
	holdTime   string
	remotePort *uint16
	localPort  *uint16
}

func (bgps *bgpSpec) GetRemoteASN() *uint32 {
	return bgps.remoteASN
}

func (bgps *bgpSpec) GetLocalASN() *uint32 {
	return bgps.localASN
}

func (bgps *bgpSpec) GetBfdSpec() bird.BfdSpec {
	return bgps.bfd
}

func (bgps *bgpSpec) GetHoldTime() string {
	return bgps.holdTime
}

func (bgps *bgpSpec) GetRemotePort() *uint16 {
	return bgps.remotePort
}

func (bgps *bgpSpec) GetLocalPort() *uint16 {
	return bgps.localPort
}

type staticSpec struct {
	bfd *bfdSpec
}

func (ss *staticSpec) GetBfdSpec() bird.BfdSpec {
	return ss.bfd
}

type bfdSpec struct {
	sw         *bool
	minTx      string
	minRx      string
	multiplier *uint16
}

func (bfds *bfdSpec) GetSwitch() *bool {
	return bfds.sw
}

func (bfds *bfdSpec) GetMinTx() string {
	return bfds.minTx
}

func (bfds *bfdSpec) GetMinRx() string {
	return bfds.minRx
}

func (bfds *bfdSpec) GetMultiplier() *uint16 {
	return bfds.multiplier
}
