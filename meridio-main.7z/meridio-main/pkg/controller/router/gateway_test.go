/*
Copyright (c) 2023 Nordix Foundation

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package router_test

import (
	"context"
	"sync"
	"time"

	"github.com/meridio-io/meridio/api/v1alpha1"
	"github.com/meridio-io/meridio/pkg/bird"
	. "github.com/onsi/ginkgo/v2"
	. "github.com/onsi/gomega"
	v1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
)

var _ = Describe("Gateway controller", func() {
	const (
		gateway1Name = "gateway-v4"
		namespace    = "default"
		timeout      = time.Second * 10
		interval     = time.Millisecond * 250
	)

	When("Creating a gateway without service proxy label", func() {
		var (
			gateway *v1alpha1.Gateway
			ctx     context.Context
		)

		BeforeEach(func() {
			routingSuiteInstance.lastEvent = none
			ctx = context.Background()

			gateway = &v1alpha1.Gateway{
				ObjectMeta: metav1.ObjectMeta{
					Name:      gateway1Name,
					Namespace: namespace,
				},
				Spec: v1alpha1.GatewaySpec{},
			}
			Expect(k8sClient.Create(ctx, gateway)).Should(Succeed())
		})

		AfterEach(func() {
			routingSuiteInstance.lastEvent = none
			Expect(k8sClient.Delete(ctx, gateway)).Should(Succeed())

			// Wait for the reconcile to be finished
			Eventually(func() bool {
				routingSuiteInstance.mu.Lock()
				defer routingSuiteInstance.mu.Unlock()

				return routingSuiteInstance.lastEvent == apply
			}, timeout, interval).Should(BeTrue())
		})

		It("does not register it", func() {
			By("Checking the object exists")
			key := types.NamespacedName{Name: gateway1Name, Namespace: namespace}
			fetched := &v1alpha1.Gateway{}

			Eventually(func() bool {
				err := k8sClient.Get(ctx, key, fetched)
				return err == nil
			}, timeout, interval).Should(BeTrue())

			// Wait for the reconcile to be finished
			Eventually(func() bool {
				routingSuiteInstance.mu.Lock()
				defer routingSuiteInstance.mu.Unlock()

				return routingSuiteInstance.lastEvent == apply
			}, timeout, interval).Should(BeTrue())

			By("Checking the gateway is not registered")
			Expect(routingSuiteInstance.gateways).ShouldNot(HaveKey(gateway1Name))
			Expect(routingSuiteInstance.appliedGateways).ShouldNot(HaveKey(gateway1Name))
			Expect(routingSuiteInstance.vips).Should(BeEmpty())
			Expect(routingSuiteInstance.appliedVips).Should(BeEmpty())
		})
	})

	When("Creating a gateway with a service proxy label", func() {
		var (
			gateway *v1alpha1.Gateway
			ctx     context.Context
		)

		BeforeEach(func() {
			routingSuiteInstance.lastEvent = none
			ctx = context.Background()

			gateway = &v1alpha1.Gateway{
				ObjectMeta: metav1.ObjectMeta{
					Name:      gateway1Name,
					Namespace: namespace,
					Labels: map[string]string{
						v1alpha1.LabelServiceProxy: serviceProxy,
					},
				},
				Spec: v1alpha1.GatewaySpec{},
			}
			Expect(k8sClient.Create(ctx, gateway)).Should(Succeed())
		})

		AfterEach(func() {
			routingSuiteInstance.lastEvent = none
			Expect(k8sClient.Delete(ctx, gateway)).Should(Succeed())

			// Wait for the reconcile to be finished
			Eventually(func() bool {
				routingSuiteInstance.mu.Lock()
				defer routingSuiteInstance.mu.Unlock()

				return routingSuiteInstance.lastEvent == apply
			}, timeout, interval).Should(BeTrue())

			Expect(routingSuiteInstance.gateways).ShouldNot(HaveKey(gateway1Name))
			Expect(routingSuiteInstance.appliedGateways).ShouldNot(HaveKey(gateway1Name))
			Expect(routingSuiteInstance.vips).Should(BeEmpty())
			Expect(routingSuiteInstance.appliedVips).Should(BeEmpty())
		})

		It("registers it", func() {
			By("Checking the object exists")
			key := types.NamespacedName{Name: gateway1Name, Namespace: namespace}
			fetched := &v1alpha1.Gateway{}

			Eventually(func() bool {
				err := k8sClient.Get(ctx, key, fetched)
				return err == nil
			}, timeout, interval).Should(BeTrue())

			// Wait for the reconcile to be finished
			Eventually(func() bool {
				routingSuiteInstance.mu.Lock()
				defer routingSuiteInstance.mu.Unlock()

				return routingSuiteInstance.lastEvent == apply
			}, timeout, interval).Should(BeTrue())

			By("Checking the gateway is registered and applied")
			Expect(routingSuiteInstance.gateways).Should(HaveKey(gateway1Name))
			Expect(routingSuiteInstance.appliedGateways).Should(HaveKey(gateway1Name))
		})
	})

	When("Creating a gateway with flows", func() {
		var (
			gateway *v1alpha1.Gateway
			service *v1.Service
			flow    *v1alpha1.Flow
			vips    []string
			ctx     context.Context
		)

		BeforeEach(func() {
			routingSuiteInstance.lastEvent = none
			ctx = context.Background()

			gateway = &v1alpha1.Gateway{
				ObjectMeta: metav1.ObjectMeta{
					Name:      gateway1Name,
					Namespace: namespace,
					Labels: map[string]string{
						v1alpha1.LabelServiceProxy: serviceProxy,
					},
				},
				Spec: v1alpha1.GatewaySpec{},
			}
			Expect(k8sClient.Create(ctx, gateway)).Should(Succeed())

			service = &v1.Service{
				ObjectMeta: metav1.ObjectMeta{
					Name:      gateway1Name,
					Namespace: namespace,
					Labels: map[string]string{
						v1alpha1.LabelServiceProxy: serviceProxy,
					},
				},
				Spec: v1.ServiceSpec{
					ClusterIP: "None",
				},
			}
			Expect(k8sClient.Create(ctx, service)).Should(Succeed())

			vips = []string{"20.0.0.1/32", "2000::1/128"}
			flow = &v1alpha1.Flow{
				ObjectMeta: metav1.ObjectMeta{
					Name:      gateway1Name,
					Namespace: namespace,
					Labels: map[string]string{
						v1alpha1.LabelService:      service.GetName(),
						v1alpha1.LabelServiceProxy: serviceProxy,
					},
				},
				Spec: v1alpha1.FlowSpec{
					DestinationCIDRs: vips,
					Protocols: []v1alpha1.TransportProtocol{
						v1alpha1.TCP,
					},
					Priority: 1,
				},
			}
			Expect(k8sClient.Create(ctx, flow)).Should(Succeed())
		})

		AfterEach(func() {
			routingSuiteInstance.lastEvent = none

			Expect(k8sClient.Delete(ctx, flow)).Should(Succeed())

			// Wait for the reconcile to be finished
			Eventually(func() bool {
				routingSuiteInstance.mu.Lock()
				defer routingSuiteInstance.mu.Unlock()

				return routingSuiteInstance.lastEvent == apply
			}, timeout, interval).Should(BeTrue())

			routingSuiteInstance.lastEvent = none

			Expect(k8sClient.Delete(ctx, service)).Should(Succeed())

			// Wait for the reconcile to be finished
			Eventually(func() bool {
				routingSuiteInstance.mu.Lock()
				defer routingSuiteInstance.mu.Unlock()

				return routingSuiteInstance.lastEvent == apply
			}, timeout, interval).Should(BeTrue())

			routingSuiteInstance.lastEvent = none

			Expect(k8sClient.Delete(ctx, gateway)).Should(Succeed())

			// Wait for the reconcile to be finished
			Eventually(func() bool {
				routingSuiteInstance.mu.Lock()
				defer routingSuiteInstance.mu.Unlock()

				return routingSuiteInstance.lastEvent == apply
			}, timeout, interval).Should(BeTrue())

			Expect(routingSuiteInstance.gateways).ShouldNot(HaveKey(gateway1Name))
			Expect(routingSuiteInstance.appliedGateways).ShouldNot(HaveKey(gateway1Name))
			Expect(routingSuiteInstance.vips).Should(BeEmpty())
			Expect(routingSuiteInstance.appliedVips).Should(BeEmpty())
		})

		It("registers it with the VIPs", func() {
			By("Checking the object exists")
			key := types.NamespacedName{Name: gateway1Name, Namespace: namespace}
			fetched := &v1alpha1.Gateway{}

			Eventually(func() bool {
				err := k8sClient.Get(ctx, key, fetched)
				return err == nil
			}, timeout, interval).Should(BeTrue())

			// Wait for the reconcile to be finished
			Eventually(func() bool {
				routingSuiteInstance.mu.Lock()
				defer routingSuiteInstance.mu.Unlock()

				return routingSuiteInstance.lastEvent == apply
			}, timeout, interval).Should(BeTrue())

			By("Checking the gateway is registered and applied")
			Expect(routingSuiteInstance.gateways).Should(HaveKey(gateway1Name))
			Expect(routingSuiteInstance.appliedGateways).Should(HaveKey(gateway1Name))

			By("Checking the vips are registered and applied")
			Expect(routingSuiteInstance.appliedVips).Should(ContainElements(vips))
			Expect(routingSuiteInstance.vips).Should(ContainElements(vips))
		})
	})
})

const (
	none          fakeRoutingSuiteEvent = 0
	apply         fakeRoutingSuiteEvent = 1
	setGateway    fakeRoutingSuiteEvent = 2
	deleteGateway fakeRoutingSuiteEvent = 3
	setVIPs       fakeRoutingSuiteEvent = 4
)

type fakeRoutingSuiteEvent int

type fakeRoutingSuite struct {
	appliedGateways map[string]bird.Gateway
	appliedVips     []string
	gateways        map[string]bird.Gateway
	vips            []string
	mu              sync.Mutex
	lastEvent       fakeRoutingSuiteEvent
}

func newFakeRoutingSuite() *fakeRoutingSuite {
	return &fakeRoutingSuite{
		appliedGateways: map[string]bird.Gateway{},
		appliedVips:     []string{},
		gateways:        map[string]bird.Gateway{},
		vips:            []string{},
		lastEvent:       none,
	}
}

func (frs *fakeRoutingSuite) Apply(ctx context.Context) error {
	frs.mu.Lock()
	defer frs.mu.Unlock()

	frs.appliedGateways = frs.gateways
	frs.appliedVips = frs.vips
	frs.lastEvent = apply

	return nil
}

func (frs *fakeRoutingSuite) SetGateway(g bird.Gateway) {
	frs.mu.Lock()
	defer frs.mu.Unlock()

	frs.gateways[g.GetName()] = g
	frs.lastEvent = setGateway
}

func (frs *fakeRoutingSuite) DeleteGateway(name string) {
	frs.mu.Lock()
	defer frs.mu.Unlock()

	delete(frs.gateways, name)
	frs.lastEvent = deleteGateway
}

func (frs *fakeRoutingSuite) SetVIPs(vips []string) {
	frs.mu.Lock()
	defer frs.mu.Unlock()

	frs.vips = vips
	frs.lastEvent = setVIPs
}
