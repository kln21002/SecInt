/*
Copyright (c) 2023 Nordix Foundation

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package router

import (
	"context"

	"github.com/meridio-io/meridio/api/v1alpha1"
	"github.com/meridio-io/meridio/pkg/log"
	"k8s.io/apimachinery/pkg/types"
	"sigs.k8s.io/controller-runtime/pkg/client"
	"sigs.k8s.io/controller-runtime/pkg/reconcile"
)

func (gc *GatewayController) serviceEnqueue(ctx context.Context, object client.Object) []reconcile.Request {
	// Check if the service is in this service proxy.
	reconcileRequests := []reconcile.Request{}

	_, exists := object.GetLabels()[v1alpha1.LabelServiceProxy]
	if !exists {
		return reconcileRequests
	}

	gateways := &v1alpha1.GatewayList{}

	err := gc.List(ctx,
		gateways,
		client.MatchingLabels{
			v1alpha1.LabelServiceProxy: gc.ServiceProxy,
		})
	if err != nil {
		log.FromContextOrGlobal(ctx).Error(err, "failed listing the gateways during the flow enqueue")
	}

	for _, gateway := range gateways.Items {
		reconcileRequests = append(reconcileRequests,
			reconcile.Request{
				NamespacedName: types.NamespacedName{
					Name:      gateway.GetName(),
					Namespace: gateway.GetNamespace(),
				},
			})
	}

	return reconcileRequests
}

func (gc *GatewayController) flowEnqueue(ctx context.Context, object client.Object) []reconcile.Request {
	value, exists := object.GetLabels()[v1alpha1.LabelServiceProxy]
	if !exists || value != gc.ServiceProxy {
		return []reconcile.Request{}
	}

	gateways := &v1alpha1.GatewayList{}
	reconcileRequests := []reconcile.Request{}

	err := gc.List(ctx,
		gateways,
		client.MatchingLabels{
			v1alpha1.LabelServiceProxy: gc.ServiceProxy,
		})
	if err != nil {
		log.FromContextOrGlobal(ctx).Error(err, "failed listing the gateways during the flow enqueue")
	}

	for _, gateway := range gateways.Items {
		reconcileRequests = append(reconcileRequests,
			reconcile.Request{
				NamespacedName: types.NamespacedName{
					Name:      gateway.GetName(),
					Namespace: gateway.GetNamespace(),
				},
			})
	}

	return reconcileRequests
}
