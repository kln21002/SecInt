/*
Copyright (c) 2023 Nordix Foundation

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package serviceproxy_test

import (
	"context"
	"fmt"
	"path/filepath"
	"runtime"
	"testing"

	ctrl "sigs.k8s.io/controller-runtime"

	. "github.com/onsi/ginkgo/v2"
	. "github.com/onsi/gomega"

	"k8s.io/apimachinery/pkg/util/intstr"
	"k8s.io/client-go/kubernetes/scheme"
	"k8s.io/client-go/rest"
	"sigs.k8s.io/controller-runtime/pkg/client"
	"sigs.k8s.io/controller-runtime/pkg/envtest"

	"github.com/meridio-io/meridio/api/v1alpha1"
	"github.com/meridio-io/meridio/pkg/controller/serviceproxy"
	appsv1 "k8s.io/api/apps/v1"
	corev1 "k8s.io/api/core/v1"
)

// These tests use Ginkgo (BDD-style Go testing framework). Refer to
// http://onsi.github.io/ginkgo/ to learn more about Ginkgo.

var (
	cfg       *rest.Config
	k8sClient client.Client // You'll be using this client in your tests.
	testEnv   *envtest.Environment
	ctx       context.Context
	cancel    context.CancelFunc
)

func TestControllers(t *testing.T) {
	RegisterFailHandler(Fail)

	RunSpecs(t, "Controller Suite")
}

var _ = BeforeSuite(func() {
	ctx, cancel = context.WithCancel(context.TODO())

	By("bootstrapping test environment")
	testEnv = &envtest.Environment{
		CRDDirectoryPaths:     []string{filepath.Join("..", "..", "..", "deployments", "Meridio-CRDs", "templates")},
		ErrorIfCRDPathMissing: true,
		BinaryAssetsDirectory: filepath.Join("..", "..", "..", "bin", "k8s",
			fmt.Sprintf("1.28.0-%s-%s", runtime.GOOS, runtime.GOARCH)),
	}

	var err error
	// cfg is defined in this file globally.
	cfg, err = testEnv.Start()
	Expect(err).NotTo(HaveOccurred())
	Expect(cfg).NotTo(BeNil())

	err = v1alpha1.AddToScheme(scheme.Scheme)
	Expect(err).NotTo(HaveOccurred())

	k8sClient, err = client.New(cfg, client.Options{Scheme: scheme.Scheme})
	Expect(err).NotTo(HaveOccurred())
	Expect(k8sClient).NotTo(BeNil())

	k8sManager, err := ctrl.NewManager(cfg, ctrl.Options{
		Scheme: scheme.Scheme,
	})
	Expect(err).ToNot(HaveOccurred())

	templateProvider := &fakeTemplateProvider{}

	err = (&serviceproxy.Controller{
		Client:           k8sManager.GetClient(),
		Scheme:           k8sManager.GetScheme(),
		TemplateProvider: templateProvider,
	}).SetupWithManager(k8sManager)
	Expect(err).ToNot(HaveOccurred())

	go func() {
		defer GinkgoRecover()
		err = k8sManager.Start(ctx)
		Expect(err).ToNot(HaveOccurred(), "failed to run manager")
	}()
})

var _ = AfterSuite(func() {
	cancel()
	By("tearing down the test environment")
	err := testEnv.Stop()
	Expect(err).NotTo(HaveOccurred())
})

type fakeTemplateProvider struct{}

const (
	defaultUserID  = 10002
	defaultGroupID = 10002
	defaultFSGroup = 2000
)

//nolint:funlen
func (ftp *fakeTemplateProvider) GetStatelessLoadBalancerRouterDeploymentTemplate() *appsv1.Deployment {
	fsGroupChangePolicy := corev1.FSGroupChangeOnRootMismatch
	fsGroup := int64(defaultFSGroup)
	userID := int64(defaultUserID)
	groupID := int64(defaultGroupID)
	runAsNonRoot := true
	readOnlyRootFilesystem := true
	privileged := true
	automountServiceAccountToken := false

	return &appsv1.Deployment{
		Spec: appsv1.DeploymentSpec{
			Strategy: appsv1.DeploymentStrategy{
				RollingUpdate: &appsv1.RollingUpdateDeployment{
					MaxUnavailable: &intstr.IntOrString{
						Type:   intstr.String,
						StrVal: "50%",
					},
					MaxSurge: &intstr.IntOrString{
						Type:   intstr.String,
						StrVal: "50%",
					},
				},
			},
			Template: corev1.PodTemplateSpec{
				Spec: corev1.PodSpec{
					ServiceAccountName:           "sllbr-service-account",
					AutomountServiceAccountToken: &automountServiceAccountToken,
					SecurityContext: &corev1.PodSecurityContext{
						RunAsUser:           &userID,
						RunAsGroup:          &groupID,
						RunAsNonRoot:        &runAsNonRoot,
						FSGroup:             &fsGroup,
						FSGroupChangePolicy: &fsGroupChangePolicy,
					},
					InitContainers: []corev1.Container{
						{
							Name:            "sysctl-init",
							Image:           "busybox:latest",
							ImagePullPolicy: corev1.PullAlways,
							Command:         []string{"/bin/sh"},
							Args: []string{
								"-c",
								fmt.Sprintf("%s ; %s ; %s ; %s ; %s ; %s ; %s ; %s",
									"sysctl -w net.ipv4.conf.all.forwarding=1",
									"sysctl -w net.ipv4.fib_multipath_hash_policy=1",
									"sysctl -w net.ipv4.conf.all.rp_filter=0",
									"sysctl -w net.ipv4.conf.default.rp_filter=0",
									"sysctl -w net.ipv4.ip_local_port_range='49152 65535'",
									"sysctl -w net.ipv6.conf.all.forwarding=1",
									"sysctl -w net.ipv6.fib_multipath_hash_policy=1",
									"sysctl -w net.ipv6.conf.all.accept_dad=0",
								),
							},
							SecurityContext: &corev1.SecurityContext{
								Privileged: &privileged,
							},
							TerminationMessagePath:   "/dev/termination-log",
							TerminationMessagePolicy: corev1.TerminationMessageReadFile,
						},
					},
					Containers: []corev1.Container{
						{
							Name:            "stateless-load-balancer",
							Image:           "localhost:5000/meridio-io/stateless-load-balancer:latest",
							ImagePullPolicy: corev1.PullAlways,
							Command: []string{
								"./stateless-load-balancer",
							},
							Args: []string{
								"run",
							},
							SecurityContext: &corev1.SecurityContext{
								RunAsNonRoot:           &runAsNonRoot,
								ReadOnlyRootFilesystem: &readOnlyRootFilesystem,
								Capabilities: &corev1.Capabilities{
									Drop: []corev1.Capability{
										"all",
									},
									Add: []corev1.Capability{
										"NET_ADMIN",    // required by load-balancer and nfqlb
										"IPC_LOCK",     // required by nfqlb because of shared-mem
										"IPC_OWNER",    // required by nfqlb because of shared-mem
										"DAC_OVERRIDE", // required by debug tools (netstat, ss)
										"NET_RAW",      // required by debug tools (tcpdump, ping)
										"SYS_PTRACE",   // required by debug tools (netstat, ss to list process names/ids)
									},
								},
							},
							TerminationMessagePath:   "/dev/termination-log",
							TerminationMessagePolicy: corev1.TerminationMessageReadFile,
						},
						{
							Name:            "router",
							Image:           "localhost:5000/meridio-io/router:latest",
							ImagePullPolicy: corev1.PullAlways,
							Command: []string{
								"./router",
							},
							Args: []string{
								"run",
							},
							SecurityContext: &corev1.SecurityContext{
								RunAsNonRoot:           &runAsNonRoot,
								ReadOnlyRootFilesystem: &readOnlyRootFilesystem,
								Capabilities: &corev1.Capabilities{
									Drop: []corev1.Capability{
										"all",
									},
									Add: []corev1.Capability{
										"NET_ADMIN",        // required by router and bird
										"NET_BIND_SERVICE", // required by bird to support binding to classic BGP port number 173
										"DAC_OVERRIDE",     // required by debug tools (netstat, ss)
										"NET_RAW",          // required by debug tools (tcpdump, ping)
										"SYS_PTRACE",       // required by debug tools (netstat, ss to list process names/ids)
									},
								},
							},
							VolumeMounts: []corev1.VolumeMount{
								{
									Name:      "tmp",
									MountPath: "/tmp",
									ReadOnly:  false,
								},
								{
									Name:      "run",
									MountPath: "/var/run/bird",
									ReadOnly:  false,
								},
								{
									Name:      "etc",
									MountPath: "/etc/bird",
									ReadOnly:  false,
								},
								{
									Name:      "log",
									MountPath: "/var/log",
									ReadOnly:  false,
								},
							},
							TerminationMessagePath:   "/dev/termination-log",
							TerminationMessagePolicy: corev1.TerminationMessageReadFile,
						},
					},
					Volumes: []corev1.Volume{
						{
							Name: "tmp",
							VolumeSource: corev1.VolumeSource{
								EmptyDir: &corev1.EmptyDirVolumeSource{
									Medium: corev1.StorageMediumMemory,
								},
							},
						},
						{
							Name: "run",
							VolumeSource: corev1.VolumeSource{
								EmptyDir: &corev1.EmptyDirVolumeSource{
									Medium: corev1.StorageMediumMemory,
								},
							},
						},
						{
							Name: "etc",
							VolumeSource: corev1.VolumeSource{
								EmptyDir: &corev1.EmptyDirVolumeSource{
									Medium: corev1.StorageMediumMemory,
								},
							},
						},
						{
							Name: "log",
							VolumeSource: corev1.VolumeSource{
								EmptyDir: &corev1.EmptyDirVolumeSource{
									Medium: corev1.StorageMediumMemory,
								},
							},
						},
					},
				},
			},
		},
	}
}

func (ftp *fakeTemplateProvider) GetStatelessLoadBalancerControllerManagerDeploymentTemplate() *appsv1.Deployment {
	fsGroupChangePolicy := corev1.FSGroupChangeOnRootMismatch
	fsGroup := int64(defaultFSGroup)
	runAsNonRoot := true
	readOnlyRootFilesystem := true
	replicas := int32(1)

	return &appsv1.Deployment{
		Spec: appsv1.DeploymentSpec{
			Replicas: &replicas,
			Template: corev1.PodTemplateSpec{
				Spec: corev1.PodSpec{
					ServiceAccountName: "sllb-cm-service-account",
					SecurityContext: &corev1.PodSecurityContext{
						FSGroup:             &fsGroup,
						FSGroupChangePolicy: &fsGroupChangePolicy,
					},
					Containers: []corev1.Container{
						{
							Name:            "stateless-load-balancer-controller-manager",
							Image:           "localhost:5000/meridio-io/stateless-load-balancer-controller-manager:latest",
							ImagePullPolicy: corev1.PullAlways,
							Command: []string{
								"./stateless-load-balancer-controller-manager",
							},
							Args: []string{
								"run",
							},
							SecurityContext: &corev1.SecurityContext{
								RunAsNonRoot:           &runAsNonRoot,
								ReadOnlyRootFilesystem: &readOnlyRootFilesystem,
								Capabilities: &corev1.Capabilities{
									Drop: []corev1.Capability{
										"all",
									},
								},
							},
							TerminationMessagePath:   "/dev/termination-log",
							TerminationMessagePolicy: corev1.TerminationMessageReadFile,
						},
					},
				},
			},
		},
	}
}
