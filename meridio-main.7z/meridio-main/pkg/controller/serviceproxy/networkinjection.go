/*
Copyright (c) 2023 Nordix Foundation

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package serviceproxy

import (
	"encoding/json"
	"fmt"

	netdefv1 "github.com/k8snetworkplumbingwg/network-attachment-definition-client/pkg/apis/k8s.cni.cncf.io/v1"
	"github.com/meridio-io/meridio/api/v1alpha1"
	appsv1 "k8s.io/api/apps/v1"
)

func injectNetworks(
	serviceProxy *v1alpha1.ServiceProxy,
	deployment *appsv1.Deployment,
) error {
	networkAttachmentAnnotations := []*v1alpha1.NetworkAttachementAnnotation{}

	for _, network := range serviceProxy.Spec.Networks {
		if network.ProxyMountMethod != v1alpha1.MountMountMethod {
			continue
		}

		if network.NetworkAttachementAnnotation != nil {
			networkAttachmentAnnotations = append(networkAttachmentAnnotations, network.NetworkAttachementAnnotation)
		}
	}

	err := injectNetworkAttachmentAnnotations(networkAttachmentAnnotations, deployment)
	if err != nil {
		return err
	}

	return nil
}

func injectNetworkAttachmentAnnotations(
	networkAttachmentAnnotations []*v1alpha1.NetworkAttachementAnnotation,
	deployment *appsv1.Deployment,
) error {
	annotations := map[string][]netdefv1.NetworkSelectionElement{}

	for _, network := range networkAttachmentAnnotations {
		var networkSelectionElements []netdefv1.NetworkSelectionElement

		err := json.Unmarshal([]byte(network.Value), &networkSelectionElements)
		if err != nil {
			return fmt.Errorf("failed to json.Unmarshal Network Attachment Annotation (%s): %w", network, err)
		}

		annotations[network.Key] = append(annotations[network.Key], networkSelectionElements...)
	}

	if deployment.Spec.Template.Annotations == nil {
		deployment.Spec.Template.Annotations = map[string]string{}
	}

	for key, value := range annotations {
		newNetworkSelectionElementsJSON, err := json.Marshal(value)
		if err != nil {
			return fmt.Errorf("failed to json.Marshal network selection elements: %w", err)
		}

		deployment.Spec.Template.Annotations[key] = string(newNetworkSelectionElementsJSON)
	}

	return nil
}
