/*
Copyright (c) 2023 Nordix Foundation

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package serviceproxy

import (
	"context"
	"encoding/json"
	"fmt"

	"github.com/meridio-io/meridio/api/v1alpha1"
	appsv1 "k8s.io/api/apps/v1"
	apierrors "k8s.io/apimachinery/pkg/api/errors"
	v1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
	ctrl "sigs.k8s.io/controller-runtime"
)

const (
	label                                               = "app"
	statelessLoadBalancerContainerName                  = "stateless-load-balancer"
	routerContainerName                                 = "router"
	statelessLoadBalancerControllerManagerContainerName = "stateless-load-balancer-controller-manager"
)

// reconcileStatelessLoadBalancerRouter reconciles the resources for a stateless load-balancer router type of
// service proxy.
func (c *Controller) reconcileStatelessLoadBalancerRouter(
	ctx context.Context,
	serviceProxy *v1alpha1.ServiceProxy,
	templateProvider TemplateProvider,
) error {
	err := c.reconcileStatelessLoadBalancerRouterDeployment(ctx, serviceProxy, templateProvider)
	if err != nil {
		return err
	}

	err = c.reconcileStatelessLoadBalancerControllerManagerDeployment(ctx, serviceProxy, templateProvider)
	if err != nil {
		return err
	}

	return nil
}

func (c *Controller) reconcileStatelessLoadBalancerRouterDeployment(
	ctx context.Context,
	serviceProxy *v1alpha1.ServiceProxy,
	templateProvider TemplateProvider,
) error {
	sllbrDeployment := &appsv1.Deployment{}

	sllbrDeploymentLatestState, err := c.getStatelessLoadBalancerRouterDeployment(serviceProxy, templateProvider)
	if err != nil {
		return err
	}

	err = c.Get(ctx, types.NamespacedName{
		Name:      getStatelessLoadBalancerRouterDeploymentName(serviceProxy),
		Namespace: serviceProxy.Namespace,
	}, sllbrDeployment)
	if err != nil {
		if apierrors.IsNotFound(err) {
			// Create
			err = c.Create(ctx, sllbrDeploymentLatestState)
			if err != nil {
				return fmt.Errorf("failed to create the statelessLoadBalancerRouter deployment: %w", err)
			}

			return nil
		}

		return fmt.Errorf("failed to get the statelessLoadBalancerRouter deployment: %w", err)
	}

	// update
	if *sllbrDeployment.Spec.Replicas != *sllbrDeploymentLatestState.Spec.Replicas {
		err = c.Update(ctx, sllbrDeploymentLatestState)
		if err != nil {
			return fmt.Errorf("failed to update the statelessLoadBalancerRouter deployment: %w", err)
		}
	}

	return nil
}

func (c *Controller) getStatelessLoadBalancerRouterDeployment(
	serviceProxy *v1alpha1.ServiceProxy,
	templateProvider TemplateProvider,
) (*appsv1.Deployment, error) {
	deployment := templateProvider.GetStatelessLoadBalancerRouterDeploymentTemplate()
	name := getStatelessLoadBalancerRouterDeploymentName(serviceProxy)

	deployment.ObjectMeta.Name = name
	deployment.ObjectMeta.Namespace = serviceProxy.Namespace

	if deployment.Labels == nil {
		deployment.Labels = map[string]string{}
	}

	deployment.Labels[label] = name
	deployment.Labels[v1alpha1.LabelServiceProxyType] = string(v1alpha1.StatelessloadbalancerRouter)
	deployment.Labels[v1alpha1.LabelServiceProxy] = serviceProxy.Name
	deployment.Labels[v1alpha1.LabelServiceProxyPlane] = v1alpha1.ValueDataPlane

	deployment.Spec.Replicas = serviceProxy.Spec.Replicas

	deployment.Spec.Selector = &v1.LabelSelector{
		MatchLabels: map[string]string{
			label: name,
		},
	}

	if deployment.Spec.Template.Labels == nil {
		deployment.Spec.Template.Labels = map[string]string{}
	}

	deployment.Spec.Template.Labels[label] = name
	deployment.Spec.Template.Labels[v1alpha1.LabelServiceProxyType] = string(v1alpha1.StatelessloadbalancerRouter)
	deployment.Spec.Template.Labels[v1alpha1.LabelServiceProxy] = serviceProxy.Name
	deployment.Spec.Template.Labels[v1alpha1.LabelServiceProxyPlane] = v1alpha1.ValueDataPlane

	err := injectNetworks(serviceProxy, deployment)
	if err != nil {
		return nil, err
	}

	for index, container := range deployment.Spec.Template.Spec.Containers {
		switch container.Name {
		case statelessLoadBalancerContainerName:
			deployment.Spec.Template.Spec.Containers[index].Args = append(deployment.Spec.Template.Spec.Containers[index].Args,
				fmt.Sprintf("--namespace=%s", serviceProxy.Namespace),
				fmt.Sprintf("--service-proxy=%s", serviceProxy.Name),
			)
		case routerContainerName:
			deployment.Spec.Template.Spec.Containers[index].Args = append(deployment.Spec.Template.Spec.Containers[index].Args,
				fmt.Sprintf("--namespace=%s", serviceProxy.Namespace),
				fmt.Sprintf("--service-proxy=%s", serviceProxy.Name),
				fmt.Sprintf("--network-interface-name=%s", "vlan-100"), // todo
			)
		}
	}

	err = ctrl.SetControllerReference(serviceProxy, deployment, c.Scheme)
	if err != nil {
		return nil, fmt.Errorf("failed to SetControllerReference on stateless load balancer router deployment: %w", err)
	}

	return deployment, nil
}

func getStatelessLoadBalancerRouterDeploymentName(serviceProxy *v1alpha1.ServiceProxy) string {
	return fmt.Sprintf("sllbr-%s", serviceProxy.Name)
}

func (c *Controller) reconcileStatelessLoadBalancerControllerManagerDeployment(
	ctx context.Context,
	serviceProxy *v1alpha1.ServiceProxy,
	templateProvider TemplateProvider,
) error {
	sllbcmDeployment := &appsv1.Deployment{}

	sllbcmDeploymentLatestState, err := c.getStatelessLoadBalancerControllerManagerDeployment(
		serviceProxy,
		templateProvider,
	)
	if err != nil {
		return err
	}

	err = c.Get(ctx, types.NamespacedName{
		Name:      getStatelessLoadBalancerControllerManagerDeploymentName(serviceProxy),
		Namespace: serviceProxy.Namespace,
	}, sllbcmDeployment)
	if err != nil {
		if apierrors.IsNotFound(err) {
			// Create
			err = c.Create(ctx, sllbcmDeploymentLatestState)
			if err != nil {
				return fmt.Errorf("failed to create the statelessLoadBalancerControllerManager deployment: %w", err)
			}

			return nil
		}

		return fmt.Errorf("failed to get the statelessLoadBalancerControllerManager deployment: %w", err)
	}

	// update
	if *sllbcmDeployment.Spec.Replicas != 1 {
		err = c.Update(ctx, sllbcmDeploymentLatestState)
		if err != nil {
			return fmt.Errorf("failed to update the statelessLoadBalancerControllerManager deployment: %w", err)
		}
	}

	return nil
}

func (c *Controller) getStatelessLoadBalancerControllerManagerDeployment(
	serviceProxy *v1alpha1.ServiceProxy,
	templateProvider TemplateProvider,
) (*appsv1.Deployment, error) {
	deployment := templateProvider.GetStatelessLoadBalancerControllerManagerDeploymentTemplate()
	name := getStatelessLoadBalancerControllerManagerDeploymentName(serviceProxy)

	deployment.ObjectMeta.Name = name
	deployment.ObjectMeta.Namespace = serviceProxy.Namespace

	if deployment.Labels == nil {
		deployment.Labels = map[string]string{}
	}

	deployment.Labels[label] = name
	deployment.Labels[v1alpha1.LabelServiceProxyType] = string(v1alpha1.StatelessloadbalancerRouter)
	deployment.Labels[v1alpha1.LabelServiceProxy] = serviceProxy.Name
	deployment.Labels[v1alpha1.LabelServiceProxyPlane] = v1alpha1.ValueControlPlane

	deployment.Spec.Selector = &v1.LabelSelector{
		MatchLabels: map[string]string{
			label: name,
		},
	}

	if deployment.Spec.Template.Labels == nil {
		deployment.Spec.Template.Labels = map[string]string{}
	}

	deployment.Spec.Template.Labels[label] = name
	deployment.Spec.Template.Labels[v1alpha1.LabelServiceProxyType] = string(v1alpha1.StatelessloadbalancerRouter)
	deployment.Spec.Template.Labels[v1alpha1.LabelServiceProxy] = serviceProxy.Name
	deployment.Spec.Template.Labels[v1alpha1.LabelServiceProxyPlane] = v1alpha1.ValueControlPlane

	jsonNetworks, err := json.Marshal(serviceProxy.Spec.Networks)
	if err != nil {
		return nil, fmt.Errorf("failed to json.Marshal networks: %w", err)
	}

	for i, container := range deployment.Spec.Template.Spec.Containers {
		switch container.Name {
		case statelessLoadBalancerControllerManagerContainerName:
			deployment.Spec.Template.Spec.Containers[i].Args = append(deployment.Spec.Template.Spec.Containers[i].Args,
				fmt.Sprintf("--namespace=%s", serviceProxy.Namespace),
				fmt.Sprintf("--service-proxy=%s", serviceProxy.Name),
				fmt.Sprintf("--networks=%s", string(jsonNetworks)),
			)
		default:
			continue
		}
	}

	err = ctrl.SetControllerReference(serviceProxy, deployment, c.Scheme)
	if err != nil {
		return nil,
			fmt.Errorf("failed to SetControllerReference on stateless load balancer controller manager deployment: %w", err)
	}

	return deployment, nil
}

func getStatelessLoadBalancerControllerManagerDeploymentName(
	serviceProxy *v1alpha1.ServiceProxy,
) string {
	return fmt.Sprintf("sllb-cm-%s", serviceProxy.Name)
}
