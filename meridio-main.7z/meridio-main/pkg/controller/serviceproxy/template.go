/*
Copyright (c) 2023 Nordix Foundation

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package serviceproxy

import (
	"fmt"
	"os"

	appsv1 "k8s.io/api/apps/v1"
	"k8s.io/apimachinery/pkg/util/yaml"
)

const (
	decoderBufferSize = 4096
)

// FileTemplateProvider implements the TemplateProvider interface to provides
// from files.
type FileTemplateProvider struct {
	statelessLoadBalancerRouterDeploymentTemplate            *appsv1.Deployment
	statelessLoadBalancerControllerManagerDeploymentTemplate *appsv1.Deployment
}

// NewFileTemplateProvider is the constructor for the FileTemplateProvider struct.
// It reads the templates/sllbr.yaml and templates/sllb-cm.yaml files, verifies they are valid,
// and stores it in memory.
func NewFileTemplateProvider() (*FileTemplateProvider, error) {
	ftp := &FileTemplateProvider{}

	var err error

	ftp.statelessLoadBalancerRouterDeploymentTemplate, err = readTemplate("templates/sllbr.yaml")
	if err != nil {
		return nil, err
	}

	ftp.statelessLoadBalancerControllerManagerDeploymentTemplate, err = readTemplate("templates/sllb-cm.yaml")
	if err != nil {
		return nil, err
	}

	return ftp, nil
}

// GetStatelessLoadBalancerRouterDeploymentTemplate returns a deployment from the template
// provided in the templates/sllbr.yaml file.
func (ftp *FileTemplateProvider) GetStatelessLoadBalancerRouterDeploymentTemplate() *appsv1.Deployment {
	return ftp.statelessLoadBalancerRouterDeploymentTemplate.DeepCopy()
}

// GetStatelessLoadBalancerControllerManagerDeploymentTemplate returns a deployment from the template
// provided in the templates/sllb-cm.yaml file.
func (ftp *FileTemplateProvider) GetStatelessLoadBalancerControllerManagerDeploymentTemplate() *appsv1.Deployment {
	return ftp.statelessLoadBalancerControllerManagerDeploymentTemplate.DeepCopy()
}

func readTemplate(file string) (*appsv1.Deployment, error) {
	data, err := os.Open(file)
	if err != nil {
		return nil, fmt.Errorf("fail to open file: %w", err)
	}

	deployment := &appsv1.Deployment{}

	err = yaml.NewYAMLOrJSONDecoder(data, decoderBufferSize).Decode(deployment)
	if err != nil {
		return nil, fmt.Errorf("failed to decode template: %w", err)
	}

	return deployment, nil
}
