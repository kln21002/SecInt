/*
Copyright (c) 2023 Nordix Foundation

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package serviceproxy_test

import (
	"context"
	"time"

	netdefv1 "github.com/k8snetworkplumbingwg/network-attachment-definition-client/pkg/apis/k8s.cni.cncf.io/v1"
	"github.com/meridio-io/meridio/api/v1alpha1"
	. "github.com/onsi/ginkgo/v2"
	. "github.com/onsi/gomega"
	appsv1 "k8s.io/api/apps/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/labels"
	"sigs.k8s.io/controller-runtime/pkg/client"
)

var _ = Describe("ServiceProxy controller", func() {
	const (
		serviceProxy1Name = "service-proxy-1"
		namespace         = "default"
		timeout           = time.Second * 10
		interval          = time.Millisecond * 250
	)

	When("Creating a StatelessLoadBalancerRouter service proxy with ManualMultus", func() {
		var (
			serviceProxy *v1alpha1.ServiceProxy
			ctx          context.Context
			replicas     int32
			deployment   *appsv1.Deployment
		)

		BeforeEach(func() {
			ctx = context.Background()
			replicas = 2

			serviceProxy = &v1alpha1.ServiceProxy{
				ObjectMeta: metav1.ObjectMeta{
					Name:      serviceProxy1Name,
					Namespace: namespace,
				},
				Spec: v1alpha1.ServiceProxySpec{
					Type:     v1alpha1.StatelessloadbalancerRouter,
					Replicas: &replicas,
				},
			}
			Expect(k8sClient.Create(ctx, serviceProxy)).Should(Succeed())
		})

		AfterEach(func() {
			Expect(k8sClient.Delete(ctx, serviceProxy)).Should(Succeed())

			// https://book.kubebuilder.io/reference/envtest.html#testing-considerations
			// https://stackoverflow.com/questions/64821970/operator-controller-could-not-delete-correlated-resources
			// Kubelet garbage collection doesn't work with envTest, so the deployment has to be deleted manually.
			if deployment != nil {
				Expect(k8sClient.Delete(ctx, deployment)).Should(Succeed())
			}

			labelSelector := labels.Set{
				v1alpha1.LabelServiceProxyType:  string(v1alpha1.StatelessloadbalancerRouter),
				v1alpha1.LabelServiceProxy:      serviceProxy1Name,
				v1alpha1.LabelServiceProxyPlane: v1alpha1.ValueDataPlane,
			}
			deploymentList := &appsv1.DeploymentList{}
			Eventually(func() bool {
				err := k8sClient.List(ctx, deploymentList, &client.ListOptions{
					LabelSelector: labelSelector.AsSelector(),
					Namespace:     namespace,
				})
				return err == nil && len(deploymentList.Items) == 0
			}, timeout, interval).Should(BeTrue())
		})

		It("has deployed the stateless-load-balancer-router deployment", func() {
			By("Checking the stateless-load-balancer-router deployment exists")
			labelSelector := labels.Set{
				v1alpha1.LabelServiceProxyType:  string(v1alpha1.StatelessloadbalancerRouter),
				v1alpha1.LabelServiceProxy:      serviceProxy1Name,
				v1alpha1.LabelServiceProxyPlane: v1alpha1.ValueDataPlane,
			}
			deploymentList := &appsv1.DeploymentList{}

			Eventually(func() bool {
				err := k8sClient.List(ctx, deploymentList, &client.ListOptions{
					LabelSelector: labelSelector.AsSelector(),
					Namespace:     namespace,
				})
				return err == nil && len(deploymentList.Items) > 0
			}, timeout, interval).Should(BeTrue())
			Expect(len(deploymentList.Items)).Should(Equal(1))
			deployment = &deploymentList.Items[0]
			Expect(deployment.Spec.Replicas).Should(Not(BeNil()))
			Expect(*deployment.Spec.Replicas).Should(Equal(replicas))
		})

		It("can be updated", func() {
			replicas = 1
			serviceProxy.Spec.Replicas = &replicas
			Expect(k8sClient.Update(ctx, serviceProxy)).Should(Succeed())

			By("Checking the stateless-load-balancer-router deployment has been updated")
			labelSelector := labels.Set{
				v1alpha1.LabelServiceProxyType:  string(v1alpha1.StatelessloadbalancerRouter),
				v1alpha1.LabelServiceProxy:      serviceProxy1Name,
				v1alpha1.LabelServiceProxyPlane: v1alpha1.ValueDataPlane,
			}
			deploymentList := &appsv1.DeploymentList{}

			Eventually(func() bool {
				err := k8sClient.List(ctx, deploymentList, &client.ListOptions{
					LabelSelector: labelSelector.AsSelector(),
					Namespace:     namespace,
				})
				return err == nil &&
					len(deploymentList.Items) > 0 &&
					deploymentList.Items[0].Spec.Replicas != nil &&
					*deploymentList.Items[0].Spec.Replicas == replicas
			}, timeout, interval).Should(BeTrue())
			deployment = &deploymentList.Items[0]
		})
	})

	When("Creating a service proxy with networkAttachementAnnotation networks", func() {
		var (
			serviceProxy *v1alpha1.ServiceProxy
			ctx          context.Context
			replicas     int32
			deployment   *appsv1.Deployment
			mergedNetAnn string
		)

		BeforeEach(func() {
			ctx = context.Background()
			replicas = 2

			mergedNetAnn = "[{\"name\":\"macvlan-vlan-200\",\"interface\":\"macvlan-200\"},{\"name\":\"vlan-200\",\"interface\":\"vlan-200\"},{\"name\":\"vlan-500\",\"interface\":\"vlan-500\"}]"

			serviceProxy = &v1alpha1.ServiceProxy{
				ObjectMeta: metav1.ObjectMeta{
					Name:      serviceProxy1Name,
					Namespace: namespace,
				},
				Spec: v1alpha1.ServiceProxySpec{
					Type:     v1alpha1.StatelessloadbalancerRouter,
					Replicas: &replicas,
					Networks: []v1alpha1.Network{
						{
							Name:             "vlan-100",
							ProxyMountMethod: v1alpha1.ManualMountMethod,
							NetworkAttachementAnnotation: &v1alpha1.NetworkAttachementAnnotation{
								Key:       "k8s.v1.cni.cncf.io/networks",
								StatusKey: "k8s.v1.cni.cncf.io/network-status",
								Value:     "[{\"name\": \"vlan-100\",\"interface\": \"vlan-100\"}]",
							},
						},
						{
							Name:             "macvlan-vlan-200",
							ProxyMountMethod: v1alpha1.MountMountMethod,
							NetworkAttachementAnnotation: &v1alpha1.NetworkAttachementAnnotation{
								Key:       "k8s.v1.cni.cncf.io/networks",
								StatusKey: "k8s.v1.cni.cncf.io/network-status",
								Value:     "[{\"name\": \"macvlan-vlan-200\",\"interface\": \"macvlan-200\"},{\"name\": \"vlan-200\",\"interface\": \"vlan-200\"}]",
							},
						},
						{
							Name:             "manual-mount-vlan-300",
							ProxyMountMethod: v1alpha1.ManualMountMethod,
							NetworkAttachementAnnotation: &v1alpha1.NetworkAttachementAnnotation{
								Key:       "k8s.v1.cni.cncf.io/networks",
								StatusKey: "k8s.v1.cni.cncf.io/network-status",
								Value:     "[{\"name\": \"vlan-300\",\"interface\": \"vlan-300\"}]",
							},
						},
						{
							Name:             "manual-mount-vlan-400",
							ProxyMountMethod: v1alpha1.NoMountMountMethod,
							NetworkAttachementAnnotation: &v1alpha1.NetworkAttachementAnnotation{
								Key:       "k8s.v1.cni.cncf.io/networks",
								StatusKey: "k8s.v1.cni.cncf.io/network-status",
								Value:     "[{\"name\": \"vlan-400\",\"interface\": \"vlan-400\"}]",
							},
						},
						{
							Name:             "macvlan-vlan-500",
							ProxyMountMethod: v1alpha1.MountMountMethod,
							NetworkAttachementAnnotation: &v1alpha1.NetworkAttachementAnnotation{
								Key:       "k8s.v1.cni.cncf.io/networks",
								StatusKey: "k8s.v1.cni.cncf.io/network-status",
								Value:     "[{\"name\": \"vlan-500\",\"interface\": \"vlan-500\"}]",
							},
						},
						{
							Name:             "other",
							ProxyMountMethod: v1alpha1.MountMountMethod,
						},
					},
				},
			}
			Expect(k8sClient.Create(ctx, serviceProxy)).Should(Succeed())
		})

		AfterEach(func() {
			Expect(k8sClient.Delete(ctx, serviceProxy)).Should(Succeed())

			// https://book.kubebuilder.io/reference/envtest.html#testing-considerations
			// https://stackoverflow.com/questions/64821970/operator-controller-could-not-delete-correlated-resources
			// Kubelet garbage collection doesn't work with envTest, so the deployment has to be deleted manually.
			if deployment != nil {
				Expect(k8sClient.Delete(ctx, deployment)).Should(Succeed())
			}

			labelSelector := labels.Set{
				v1alpha1.LabelServiceProxyType:  string(v1alpha1.StatelessloadbalancerRouter),
				v1alpha1.LabelServiceProxy:      serviceProxy1Name,
				v1alpha1.LabelServiceProxyPlane: v1alpha1.ValueDataPlane,
			}
			deploymentList := &appsv1.DeploymentList{}
			Eventually(func() bool {
				err := k8sClient.List(ctx, deploymentList, &client.ListOptions{
					LabelSelector: labelSelector.AsSelector(),
					Namespace:     namespace,
				})
				return err == nil && len(deploymentList.Items) == 0
			}, timeout, interval).Should(BeTrue())
		})

		It("has deployed the stateless-load-balancer-router deployment with the network attachements", func() {
			By("Checking the stateless-load-balancer-router deployment exists")
			labelSelector := labels.Set{
				v1alpha1.LabelServiceProxyType:  string(v1alpha1.StatelessloadbalancerRouter),
				v1alpha1.LabelServiceProxy:      serviceProxy1Name,
				v1alpha1.LabelServiceProxyPlane: v1alpha1.ValueDataPlane,
			}
			deploymentList := &appsv1.DeploymentList{}

			Eventually(func() bool {
				err := k8sClient.List(ctx, deploymentList, &client.ListOptions{
					LabelSelector: labelSelector.AsSelector(),
					Namespace:     namespace,
				})
				return err == nil && len(deploymentList.Items) > 0
			}, timeout, interval).Should(BeTrue())
			Expect(len(deploymentList.Items)).Should(Equal(1))
			deployment = &deploymentList.Items[0]
			Expect(deployment.Spec.Replicas).Should(Not(BeNil()))
			Expect(*deployment.Spec.Replicas).Should(Equal(replicas))

			By("Checking the stateless-load-balancer-router deployment exists")
			netAnn, exists := deployment.Spec.Template.Annotations[netdefv1.NetworkAttachmentAnnot]
			Expect(exists).Should(BeTrue())
			Expect(netAnn).Should(Equal(mergedNetAnn))
		})
	})
})
