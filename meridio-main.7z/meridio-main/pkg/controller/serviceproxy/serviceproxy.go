/*
Copyright (c) 2023 Nordix Foundation

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package serviceproxy

import (
	"context"
	"fmt"

	"github.com/meridio-io/meridio/api/v1alpha1"
	appsv1 "k8s.io/api/apps/v1"
	apierrors "k8s.io/apimachinery/pkg/api/errors"
	"k8s.io/apimachinery/pkg/runtime"
	ctrl "sigs.k8s.io/controller-runtime"
	"sigs.k8s.io/controller-runtime/pkg/client"
)

// TemplateProvider provides the deployment templates used for the StatelessLoadBalancerRouter and
// the StatelessLoadBalancerControllerManager deployments.
type TemplateProvider interface {
	GetStatelessLoadBalancerRouterDeploymentTemplate() *appsv1.Deployment
	GetStatelessLoadBalancerControllerManagerDeploymentTemplate() *appsv1.Deployment
}

// ServiceProxyController reconcile the ServiceProxies to deploy and maintain
// the workload running the services.
type Controller struct {
	client.Client
	Scheme           *runtime.Scheme
	TemplateProvider TemplateProvider
}

// Reconcile implements the reconciliation of the ServiceProxy object.
//
// For more details, check Reconcile and its Result here:
// - https://pkg.go.dev/sigs.k8s.io/controller-runtime@v0.13.0/pkg/reconcile
func (c *Controller) Reconcile(ctx context.Context, req ctrl.Request) (ctrl.Result, error) {
	serviceProxy := &v1alpha1.ServiceProxy{}

	err := c.Get(ctx, req.NamespacedName, serviceProxy)
	if err != nil {
		if apierrors.IsNotFound(err) {
			return ctrl.Result{}, nil
		}

		return ctrl.Result{}, fmt.Errorf("failed to get the service proxy: %w", err)
	}

	if v1alpha1.StatelessloadbalancerRouter == serviceProxy.Spec.Type {
		err = c.reconcileStatelessLoadBalancerRouter(ctx, serviceProxy, c.TemplateProvider)
		if err != nil {
			return ctrl.Result{}, err
		}
	}

	return ctrl.Result{}, nil
}

// SetupWithManager sets up the controller with the Manager.
func (c *Controller) SetupWithManager(mgr ctrl.Manager) error {
	err := ctrl.NewControllerManagedBy(mgr).
		For(&v1alpha1.ServiceProxy{}).
		Owns(&appsv1.Deployment{}).
		Complete(c)
	if err != nil {
		return fmt.Errorf("failed to build the service proxy controller manager: %w", err)
	}

	return nil
}
