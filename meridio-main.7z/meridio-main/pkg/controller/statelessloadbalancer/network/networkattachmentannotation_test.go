/*
Copyright (c) 2023 Nordix Foundation

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package network_test

import (
	"fmt"
	"reflect"
	"regexp"
	"testing"

	netdefv1 "github.com/k8snetworkplumbingwg/network-attachment-definition-client/pkg/apis/k8s.cni.cncf.io/v1"
	"github.com/meridio-io/meridio/api/v1alpha1"
	"github.com/meridio-io/meridio/pkg/controller/statelessloadbalancer/network"
	v1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
)

func TestGetIPsFromNetworkAttachmentAnnotation(t *testing.T) {
	type args struct {
		namespace string
		networks  string
		status    string
	}
	tests := []struct {
		name    string
		args    args
		want    []string
		wantErr bool
	}{
		{
			name: "no networks",
			args: args{
				namespace: "default",
				networks:  "",
				status:    "",
			},
			want:    []string{},
			wantErr: false,
		},
		{
			name: "ipv4",
			args: args{
				namespace: "default",
				networks:  `[{"name":"macvlan-nad","interface":"net1"}]`,
				status:    `[{"name":"kindnet","interface":"eth0","ips":["10.244.1.5","fd00:10:244:1::5"],"mac":"46:db:9f:b0:46:fe","default":true,"dns":{},"gateway":["u003cnilu003e","u003cnilu003e"]},{"name":"default/macvlan-nad","interface":"net1","ips":["169.255.100.2"],"mac":"0a:45:14:32:ec:f2","dns":{}}]`,
			},
			want:    []string{"169.255.100.2"},
			wantErr: false,
		},
		{
			name: "ipv6",
			args: args{
				namespace: "default",
				networks:  `[{"name":"macvlan-nad","interface":"net1"}]`,
				status:    `[{"name":"kindnet","interface":"eth0","ips":["10.244.1.5","fd00:10:244:1::5"],"mac":"46:db:9f:b0:46:fe","default":true,"dns":{},"gateway":["u003cnilu003e","u003cnilu003e"]},{"name":"default/macvlan-nad","interface":"net1","ips":["fd00::1"],"mac":"0a:45:14:32:ec:f2","dns":{}}]`,
			},
			want:    []string{"fd00::1"},
			wantErr: false,
		},
		{
			name: "ipv4 and ipv6",
			args: args{
				namespace: "default",
				networks:  `[{"name":"macvlan-nad","interface":"net1"}]`,
				status:    `[{"name":"kindnet","interface":"eth0","ips":["10.244.1.5","fd00:10:244:1::5"],"mac":"46:db:9f:b0:46:fe","default":true,"dns":{},"gateway":["u003cnilu003e","u003cnilu003e"]},{"name":"default/macvlan-nad","interface":"net1","ips":["169.255.100.2","fd00::1"],"mac":"0a:45:14:32:ec:f2","dns":{}}]`,
			},
			want:    []string{"169.255.100.2", "fd00::1"},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := network.GetIPsFromNetworkAttachmentAnnotation(tt.args.namespace, tt.args.networks, tt.args.status)
			if (err != nil) != tt.wantErr {
				t.Errorf("GetIPsFromNetworkAttachmentAnnotation() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("GetIPsFromNetworkAttachmentAnnotation() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestSetNetworkAttachmentAnnotation(t *testing.T) {
	type args struct {
		pod          *v1.Pod
		serviceProxy string
		vipV4        []string
		vipV6        []string
		gatewaysV4   []string
		gatewaysV6   []string
	}
	tests := []struct {
		name    string
		args    args
		want    *v1.Pod
		wantErr bool
	}{
		{
			name: "no new network",
			args: args{
				pod: &v1.Pod{
					ObjectMeta: metav1.ObjectMeta{
						Annotations: map[string]string{
							netdefv1.NetworkAttachmentAnnot: `[{"name":"macvlan-nad","interface":"net1"}]`,
						},
					},
				},
				serviceProxy: "abc",
				vipV4:        []string{},
				vipV6:        []string{},
				gatewaysV4:   []string{},
				gatewaysV6:   []string{},
			},
			want: &v1.Pod{
				ObjectMeta: metav1.ObjectMeta{
					Annotations: map[string]string{
						netdefv1.NetworkAttachmentAnnot: `[{"name":"macvlan-nad","interface":"net1"}]`,
					},
				},
			},
			wantErr: false,
		},
		{
			name: "add vip v4",
			args: args{
				pod: &v1.Pod{
					ObjectMeta: metav1.ObjectMeta{
						Annotations: map[string]string{
							netdefv1.NetworkAttachmentAnnot: `[{"name":"macvlan-nad","interface":"net1"}]`,
						},
					},
				},
				serviceProxy: "abc",
				vipV4:        []string{"20.0.0.0/24"},
				vipV6:        []string{},
				gatewaysV4:   []string{"172.16.0.11"},
				gatewaysV6:   []string{},
			},
			want: &v1.Pod{
				ObjectMeta: metav1.ObjectMeta{
					Annotations: map[string]string{
						netdefv1.NetworkAttachmentAnnot: fmt.Sprintf(`[{"name":"macvlan-nad","interface":"net1"},{"name":"vip","interface":"88c79cf9ac2c0f6","cni-args":{"%s":"abc","vip":"20.0.0.0/24"}},{"name":"policy-route","interface":"d67c0ae05bd64f7","cni-args":{"gateways":["172.16.0.11"],"policyRoutes":[{"srcPrefix":"20.0.0.0/24"}],"%s":"abc","tableId":5000}}]`, v1alpha1.LabelServiceProxy, v1alpha1.LabelServiceProxy),
					},
				},
			},
			wantErr: false,
		},
		{
			name: "delete vip v4",
			args: args{
				pod: &v1.Pod{
					ObjectMeta: metav1.ObjectMeta{
						Annotations: map[string]string{
							netdefv1.NetworkAttachmentAnnot: fmt.Sprintf(`[{"name":"macvlan-nad","interface":"net1"},{"name":"vip","interface":"8835e86677ae9fa","cni-args":{"%s":"abc","vip":"20.0.0.0/24"}},{"name":"policy-route","interface":"a7b82115ff6864b","cni-args":{"gateways":["172.16.0.11"],"%s":"abc","policyRoutes":[{"srcPrefix":"20.0.0.0/24"}],"tableId":5000}}]`, v1alpha1.LabelServiceProxy, v1alpha1.LabelServiceProxy),
						},
					},
				},
				serviceProxy: "abc",
				vipV4:        []string{},
				vipV6:        []string{},
				gatewaysV4:   []string{"172.16.0.11"},
				gatewaysV6:   []string{},
			},
			want: &v1.Pod{
				ObjectMeta: metav1.ObjectMeta{
					Annotations: map[string]string{
						netdefv1.NetworkAttachmentAnnot: `[{"name":"macvlan-nad","interface":"net1"}]`,
					},
				},
			},
			wantErr: false,
		},
		{
			name: "update vip v4",
			args: args{
				pod: &v1.Pod{
					ObjectMeta: metav1.ObjectMeta{
						Annotations: map[string]string{
							netdefv1.NetworkAttachmentAnnot: fmt.Sprintf(`[{"name":"macvlan-nad","interface":"net1"},{"name":"vip","interface":"8835e86677ae9fa","cni-args":{"%s":"abc","vip":"20.0.0.0/24"}},{"name":"policy-route","interface":"a7b82115ff6864b","cni-args":{"gateways":["172.16.0.11"],"%s":"abc","policyRoutes":[{"srcPrefix":"20.0.0.0/24"}],"tableId":5000}}]`, v1alpha1.LabelServiceProxy, v1alpha1.LabelServiceProxy),
						},
					},
				},
				serviceProxy: "abc",
				vipV4:        []string{"20.0.0.0/24"},
				vipV6:        []string{},
				gatewaysV4:   []string{"172.16.0.12"},
				gatewaysV6:   []string{},
			},
			want: &v1.Pod{
				ObjectMeta: metav1.ObjectMeta{
					Annotations: map[string]string{
						netdefv1.NetworkAttachmentAnnot: fmt.Sprintf(`[{"name":"macvlan-nad","interface":"net1"},{"name":"vip","interface":"88c79cf9ac2c0f6","cni-args":{"%s":"abc","vip":"20.0.0.0/24"}},{"name":"policy-route","interface":"b9e3ffcd6725bc5","cni-args":{"gateways":["172.16.0.12"],"policyRoutes":[{"srcPrefix":"20.0.0.0/24"}],"%s":"abc","tableId":5001}}]`, v1alpha1.LabelServiceProxy, v1alpha1.LabelServiceProxy),
					},
				},
			},
			wantErr: false,
		},
		{
			name: "no update vip v4",
			args: args{
				pod: &v1.Pod{
					ObjectMeta: metav1.ObjectMeta{
						Annotations: map[string]string{
							netdefv1.NetworkAttachmentAnnot: fmt.Sprintf(`[{"name":"macvlan-nad","interface":"net1"},{"name":"vip","interface":"8835e86677ae9fa","cni-args":{"%s":"abc","vip":"20.0.0.0/24"}},{"name":"policy-route","interface":"a7b82115ff6864b","cni-args":{"gateways":["172.16.0.11"],"%s":"abc","policyRoutes":[{"srcPrefix":"20.0.0.0/24"}],"tableId":5000}}]`, v1alpha1.LabelServiceProxy, v1alpha1.LabelServiceProxy),
						},
					},
				},
				serviceProxy: "abc",
				vipV4:        []string{"20.0.0.0/24"},
				vipV6:        []string{},
				gatewaysV4:   []string{"172.16.0.11"},
				gatewaysV6:   []string{},
			},
			want: &v1.Pod{
				ObjectMeta: metav1.ObjectMeta{
					Annotations: map[string]string{
						netdefv1.NetworkAttachmentAnnot: fmt.Sprintf(`[{"name":"macvlan-nad","interface":"net1"},{"name":"vip","interface":"8835e86677ae9fa","cni-args":{"%s":"abc","vip":"20.0.0.0/24"}},{"name":"policy-route","interface":"a7b82115ff6864b","cni-args":{"gateways":["172.16.0.11"],"policyRoutes":[{"srcPrefix":"20.0.0.0/24"}],"%s":"abc","tableId":5000}}]`, v1alpha1.LabelServiceProxy, v1alpha1.LabelServiceProxy),
					},
				},
			},
			wantErr: false,
		},
		{
			name: "add vip v6",
			args: args{
				pod: &v1.Pod{
					ObjectMeta: metav1.ObjectMeta{
						Annotations: map[string]string{
							netdefv1.NetworkAttachmentAnnot: `[{"name":"macvlan-nad","interface":"net1"}]`,
						},
					},
				},
				serviceProxy: "abc",
				vipV4:        []string{},
				vipV6:        []string{"2000::/64"},
				gatewaysV4:   []string{},
				gatewaysV6:   []string{"fd00::1"},
			},
			want: &v1.Pod{
				ObjectMeta: metav1.ObjectMeta{
					Annotations: map[string]string{
						netdefv1.NetworkAttachmentAnnot: fmt.Sprintf(`[{"name":"macvlan-nad","interface":"net1"},{"name":"vip","interface":"d9a91b16cfe0b5c","cni-args":{"%s":"abc","vip":"2000::/64"}},{"name":"policy-route","interface":"ed5c1de4436b7cb","cni-args":{"gateways":["fd00::1"],"policyRoutes":[{"srcPrefix":"2000::/64"}],"%s":"abc","tableId":5000}}]`, v1alpha1.LabelServiceProxy, v1alpha1.LabelServiceProxy),
					},
				},
			},
			wantErr: false,
		},
		{
			name: "delete vip v6",
			args: args{
				pod: &v1.Pod{
					ObjectMeta: metav1.ObjectMeta{
						Annotations: map[string]string{
							netdefv1.NetworkAttachmentAnnot: fmt.Sprintf(`[{"name":"macvlan-nad","interface":"net1"},{"name":"vip","interface":"dedc54dc60bf7d0","cni-args":{"%s":"abc","vip":"2000::/64"}},{"name":"policy-route","interface":"fe993ad3229e79f","cni-args":{"gateways":["fd00::1"],"%s":"abc","policyRoutes":[{"srcPrefix":"2000::/64"}],"tableId":5000}}]`, v1alpha1.LabelServiceProxy, v1alpha1.LabelServiceProxy),
						},
					},
				},
				serviceProxy: "abc",
				vipV4:        []string{},
				vipV6:        []string{},
				gatewaysV4:   []string{},
				gatewaysV6:   []string{"fd00::1"},
			},
			want: &v1.Pod{
				ObjectMeta: metav1.ObjectMeta{
					Annotations: map[string]string{
						netdefv1.NetworkAttachmentAnnot: `[{"name":"macvlan-nad","interface":"net1"}]`,
					},
				},
			},
			wantErr: false,
		},
		{
			name: "update vip v6",
			args: args{
				pod: &v1.Pod{
					ObjectMeta: metav1.ObjectMeta{
						Annotations: map[string]string{
							netdefv1.NetworkAttachmentAnnot: fmt.Sprintf(`[{"name":"macvlan-nad","interface":"net1"},{"name":"vip","interface":"d9a91b16cfe0b5c","cni-args":{"%s":"abc","vip":"2000::/64"}},{"name":"policy-route","interface":"fe993ad3229e79f","cni-args":{"gateways":["fd00::1"],"%s":"abc","policyRoutes":[{"srcPrefix":"2000::/64"}],"tableId":5000}}]`, v1alpha1.LabelServiceProxy, v1alpha1.LabelServiceProxy),
						},
					},
				},
				serviceProxy: "abc",
				vipV4:        []string{},
				vipV6:        []string{"2000::/64"},
				gatewaysV4:   []string{},
				gatewaysV6:   []string{"fd00::2"},
			},
			want: &v1.Pod{
				ObjectMeta: metav1.ObjectMeta{
					Annotations: map[string]string{
						netdefv1.NetworkAttachmentAnnot: fmt.Sprintf(`[{"name":"macvlan-nad","interface":"net1"},{"name":"vip","interface":"d9a91b16cfe0b5c","cni-args":{"%s":"abc","vip":"2000::/64"}},{"name":"policy-route","interface":"627f641b3120d05","cni-args":{"gateways":["fd00::2"],"policyRoutes":[{"srcPrefix":"2000::/64"}],"%s":"abc","tableId":5001}}]`, v1alpha1.LabelServiceProxy, v1alpha1.LabelServiceProxy),
					},
				},
			},
			wantErr: false,
		},
		{
			name: "add vip v4, no annotation",
			args: args{
				pod: &v1.Pod{
					ObjectMeta: metav1.ObjectMeta{},
				},
				serviceProxy: "abc",
				vipV4:        []string{"20.0.0.0/24"},
				vipV6:        []string{},
				gatewaysV4:   []string{"172.16.0.11"},
				gatewaysV6:   []string{},
			},
			want: &v1.Pod{
				ObjectMeta: metav1.ObjectMeta{
					Annotations: map[string]string{
						netdefv1.NetworkAttachmentAnnot: fmt.Sprintf(`[{"name":"vip","interface":"88c79cf9ac2c0f6","cni-args":{"%s":"abc","vip":"20.0.0.0/24"}},{"name":"policy-route","interface":"d67c0ae05bd64f7","cni-args":{"gateways":["172.16.0.11"],"policyRoutes":[{"srcPrefix":"20.0.0.0/24"}],"%s":"abc","tableId":5000}}]`, v1alpha1.LabelServiceProxy, v1alpha1.LabelServiceProxy),
					},
				},
			},
			wantErr: false,
		},
		{
			name: "add vip v4, empty annotation",
			args: args{
				pod: &v1.Pod{
					ObjectMeta: metav1.ObjectMeta{
						Annotations: map[string]string{},
					},
				},
				serviceProxy: "abc",
				vipV4:        []string{"20.0.0.0/24"},
				vipV6:        []string{},
				gatewaysV4:   []string{"172.16.0.11"},
				gatewaysV6:   []string{},
			},
			want: &v1.Pod{
				ObjectMeta: metav1.ObjectMeta{
					Annotations: map[string]string{
						netdefv1.NetworkAttachmentAnnot: fmt.Sprintf(`[{"name":"vip","interface":"88c79cf9ac2c0f6","cni-args":{"%s":"abc","vip":"20.0.0.0/24"}},{"name":"policy-route","interface":"d67c0ae05bd64f7","cni-args":{"gateways":["172.16.0.11"],"policyRoutes":[{"srcPrefix":"20.0.0.0/24"}],"%s":"abc","tableId":5000}}]`, v1alpha1.LabelServiceProxy, v1alpha1.LabelServiceProxy),
					},
				},
			},
			wantErr: false,
		},
	}
	interfaceMatch := regexp.MustCompile(`(?m)"interface":"([^"]*)"`)
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := network.SetNetworkAttachmentAnnotation(tt.args.pod, tt.args.serviceProxy, tt.args.vipV4, tt.args.vipV6, tt.args.gatewaysV4, tt.args.gatewaysV6)
			if (err != nil) != tt.wantErr {
				t.Errorf("SetNetworkAttachmentAnnotation() error = %v, wantErr %v", err, tt.wantErr)
				return
			}

			// Remove interface names as they are randomly generated and would break the tests
			// for each minor modification of the network attachement
			got.Annotations[netdefv1.NetworkAttachmentAnnot] = interfaceMatch.ReplaceAllString(got.Annotations[netdefv1.NetworkAttachmentAnnot], "\"interface\":\"\"")
			tt.want.Annotations[netdefv1.NetworkAttachmentAnnot] = interfaceMatch.ReplaceAllString(tt.want.Annotations[netdefv1.NetworkAttachmentAnnot], "\"interface\":\"\"")

			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("SetNetworkAttachmentAnnotation() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestEqualNetworkAttachmentAnnotation(t *testing.T) {
	type args struct {
		podA *v1.Pod
		podB *v1.Pod
	}
	tests := []struct {
		name string
		args args
		want bool
	}{
		{
			name: "simple equal",
			args: args{
				podA: &v1.Pod{
					ObjectMeta: metav1.ObjectMeta{
						Annotations: map[string]string{
							netdefv1.NetworkAttachmentAnnot: fmt.Sprintf(`[{"name":"macvlan-nad","interface":"net1"},{"name":"vip","cni-args":{"%s":"abc","vip":"2000::/64"}},{"name":"policy-route","cni-args":{"gateways":"[\"fd00::1\"]","%s":"abc","policyRoutes":"{\"srcPrefix\":\"2000::/64\"}","tableId":5000}}]`, v1alpha1.LabelServiceProxy, v1alpha1.LabelServiceProxy),
						},
					},
				},
				podB: &v1.Pod{
					ObjectMeta: metav1.ObjectMeta{
						Annotations: map[string]string{
							netdefv1.NetworkAttachmentAnnot: fmt.Sprintf(`[{"name":"macvlan-nad","interface":"net1"},{"name":"vip","cni-args":{"%s":"abc","vip":"2000::/64"}},{"name":"policy-route","cni-args":{"gateways":"[\"fd00::1\"]","%s":"abc","policyRoutes":"{\"srcPrefix\":\"2000::/64\"}","tableId":5000}}]`, v1alpha1.LabelServiceProxy, v1alpha1.LabelServiceProxy),
						},
					},
				},
			},
			want: true,
		},
		{
			name: "not equal empty",
			args: args{
				podA: &v1.Pod{
					ObjectMeta: metav1.ObjectMeta{
						Annotations: map[string]string{
							netdefv1.NetworkAttachmentAnnot: fmt.Sprintf(`[{"name":"macvlan-nad","interface":"net1"},{"name":"vip","cni-args":{"%s":"abc","vip":"2000::/64"}},{"name":"policy-route","cni-args":{"gateways":"[\"fd00::1\"]","%s":"abc","policyRoutes":"{\"srcPrefix\":\"2000::/64\"}","tableId":5000}}]`, v1alpha1.LabelServiceProxy, v1alpha1.LabelServiceProxy),
						},
					},
				},
				podB: &v1.Pod{
					ObjectMeta: metav1.ObjectMeta{
						Annotations: map[string]string{},
					},
				},
			},
			want: false,
		},
		{
			name: "not equal different",
			args: args{
				podA: &v1.Pod{
					ObjectMeta: metav1.ObjectMeta{
						Annotations: map[string]string{
							netdefv1.NetworkAttachmentAnnot: fmt.Sprintf(`[{"name":"macvlan-nad","interface":"net1"},{"name":"vip","cni-args":{"%s":"abc","vip":"2000::/64"}},{"name":"policy-route","cni-args":{"gateways":"[\"fd00::1\"]","%s":"abc","policyRoutes":"{\"srcPrefix\":\"2000::/64\"}","tableId":5000}}]`, v1alpha1.LabelServiceProxy, v1alpha1.LabelServiceProxy),
						},
					},
				},
				podB: &v1.Pod{
					ObjectMeta: metav1.ObjectMeta{
						Annotations: map[string]string{
							netdefv1.NetworkAttachmentAnnot: fmt.Sprintf(`[{"name":"macvlan-nad","interface":"net1"},{"name":"vip","cni-args":{"%s":"abc","vip":"2000::/64"}},{"name":"policy-route","cni-args":{"gateways":"[\"fd00::1\"]","%s":"abc","policyRoutes":"{\"srcPrefix\":\"2000::/64\"}","tableId":5001}}]`, v1alpha1.LabelServiceProxy, v1alpha1.LabelServiceProxy),
						},
					},
				},
			},
			want: false,
		},
		{
			name: "equal different order",
			args: args{
				podA: &v1.Pod{
					ObjectMeta: metav1.ObjectMeta{
						Annotations: map[string]string{
							netdefv1.NetworkAttachmentAnnot: fmt.Sprintf(`[{"name":"macvlan-nad","interface":"net1"},{"name":"vip","cni-args":{"%s":"abc","vip":"20.0.0.0/24"}},{"name":"policy-route","cni-args":{"gateways":"[\"172.16.0.11\"]","%s":"abc","policyRoutes":"{\"srcPrefix\":\"20.0.0.0/64\"}","tableId":5000}},{"name":"vip","cni-args":{"%s":"abc","vip":"2000::/64"}},{"name":"policy-route","cni-args":{"gateways":"[\"fd00::1\"]","%s":"abc","policyRoutes":"{\"srcPrefix\":\"2000::/64\"}","tableId":5000}}]`, v1alpha1.LabelServiceProxy, v1alpha1.LabelServiceProxy, v1alpha1.LabelServiceProxy, v1alpha1.LabelServiceProxy),
						},
					},
				},
				podB: &v1.Pod{
					ObjectMeta: metav1.ObjectMeta{
						Annotations: map[string]string{
							netdefv1.NetworkAttachmentAnnot: fmt.Sprintf(`[{"name":"macvlan-nad","interface":"net1"},{"name":"vip","cni-args":{"%s":"abc","vip":"2000::/64"}},{"name":"policy-route","cni-args":{"gateways":"[\"fd00::1\"]","%s":"abc","policyRoutes":"{\"srcPrefix\":\"2000::/64\"}","tableId":5000}},{"name":"vip","cni-args":{"%s":"abc","vip":"20.0.0.0/24"}},{"name":"policy-route","cni-args":{"gateways":"[\"172.16.0.11\"]","%s":"abc","policyRoutes":"{\"srcPrefix\":\"20.0.0.0/64\"}","tableId":5000}}]`, v1alpha1.LabelServiceProxy, v1alpha1.LabelServiceProxy, v1alpha1.LabelServiceProxy, v1alpha1.LabelServiceProxy),
						},
					},
				},
			},
			want: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := network.EqualNetworkAttachmentAnnotation(tt.args.podA, tt.args.podB); got != tt.want {
				t.Errorf("EqualNetworkAttachmentAnnotation() = %v, want %v", got, tt.want)
			}
		})
	}
}
