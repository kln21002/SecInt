/*
Copyright (c) 2023 Nordix Foundation

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package statelessloadbalancer_test

import (
	"context"
	"time"

	"github.com/meridio-io/meridio/api/v1alpha1"
	"github.com/meridio-io/meridio/pkg/controller/statelessloadbalancer/endpoint"
	. "github.com/onsi/ginkgo/v2"
	. "github.com/onsi/gomega"
	v1 "k8s.io/api/core/v1"
	v1discovery "k8s.io/api/discovery/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
)

var _ = Describe("Service controller", func() {
	const (
		serviceAName = "service-a"
		flowAName    = "flow-a"
		namespace    = "default"
		timeout      = time.Second * 10
		interval     = time.Millisecond * 250
	)

	When("Creating a service without service proxy label", func() {
		var (
			service *v1.Service
			ctx     context.Context
		)

		BeforeEach(func() {
			ctx = context.Background()

			service = &v1.Service{
				ObjectMeta: metav1.ObjectMeta{
					Name:      serviceAName,
					Namespace: namespace,
				},
				Spec: v1.ServiceSpec{
					ClusterIP: "None",
				},
			}
			Expect(k8sClient.Create(ctx, service)).Should(Succeed())
		})

		AfterEach(func() {
			Expect(k8sClient.Delete(ctx, service)).Should(Succeed())
		})

		It("does not register it", func() {
			Eventually(func() bool {
				return len(fakeLB.services) == 0
			}, timeout, interval).Should(BeTrue())
		})
	})

	When("Creating a service", func() {
		var (
			service *v1.Service
			ctx     context.Context
		)

		BeforeEach(func() {
			ctx = context.Background()

			service = &v1.Service{
				ObjectMeta: metav1.ObjectMeta{
					Name:      serviceAName,
					Namespace: namespace,
					Labels: map[string]string{
						v1alpha1.LabelServiceProxy: serviceProxy,
					},
				},
				Spec: v1.ServiceSpec{
					ClusterIP: "None",
				},
			}
			Expect(k8sClient.Create(ctx, service)).Should(Succeed())
		})

		AfterEach(func() {
			Expect(k8sClient.Delete(ctx, service)).Should(Succeed())

			Eventually(func() bool {
				fakeLB.mu.Lock()
				defer fakeLB.mu.Unlock()
				return len(fakeLB.services) == 0
			}, timeout, interval).Should(BeTrue())
		})

		It("does register it", func() {
			By("Checking the service is configured")
			Eventually(func() bool {
				fakeLB.mu.Lock()
				defer fakeLB.mu.Unlock()
				return len(fakeLB.services) == 1
			}, timeout, interval).Should(BeTrue())
		})
	})

	When("Creating a service with flow after", func() {
		var (
			service *v1.Service
			flow    *v1alpha1.Flow
			ctx     context.Context
		)

		BeforeEach(func() {
			ctx = context.Background()

			service = &v1.Service{
				ObjectMeta: metav1.ObjectMeta{
					Name:      serviceAName,
					Namespace: namespace,
					Labels: map[string]string{
						v1alpha1.LabelServiceProxy: serviceProxy,
					},
				},
				Spec: v1.ServiceSpec{
					ClusterIP: "None",
				},
			}
			Expect(k8sClient.Create(ctx, service)).Should(Succeed())

			By("Checking the service is configured")
			Eventually(func() bool {
				fakeLB.mu.Lock()
				defer fakeLB.mu.Unlock()
				return len(fakeLB.services) == 1
			}, timeout, interval).Should(BeTrue())

			flow = &v1alpha1.Flow{
				ObjectMeta: metav1.ObjectMeta{
					Name:      flowAName,
					Namespace: namespace,
					Labels: map[string]string{
						v1alpha1.LabelService: serviceAName,
					},
				},
				Spec: v1alpha1.FlowSpec{
					DestinationCIDRs: []string{"20.0.0.1/32", "2000::1/128"},
					Protocols: []v1alpha1.TransportProtocol{
						v1alpha1.TCP,
					},
					Priority: 1,
				},
			}
			Expect(k8sClient.Create(ctx, flow)).Should(Succeed())
		})

		AfterEach(func() {
			Expect(k8sClient.Delete(ctx, service)).Should(Succeed())

			Eventually(func() bool {
				fakeLB.mu.Lock()
				defer fakeLB.mu.Unlock()
				return len(fakeLB.services) == 0
			}, timeout, interval).Should(BeTrue())

			Expect(k8sClient.Delete(ctx, flow)).Should(Succeed())
		})

		It("does register it and the flow too", func() {
			service, exists := fakeLB.services[serviceAName]
			Expect(exists).To(BeTrue())
			Expect(service).ToNot(BeNil())

			By("Checking the flow is configured")
			Eventually(func() bool {
				service.mu.Lock()
				defer service.mu.Unlock()
				return len(service.flows) == 1
			}, timeout, interval).Should(BeTrue())
		})
	})

	When("Creating a service with flow before", func() {
		var (
			service *v1.Service
			flow    *v1alpha1.Flow
			ctx     context.Context
		)

		BeforeEach(func() {
			ctx = context.Background()

			flow = &v1alpha1.Flow{
				ObjectMeta: metav1.ObjectMeta{
					Name:      flowAName,
					Namespace: namespace,
					Labels: map[string]string{
						v1alpha1.LabelService: serviceAName,
					},
				},
				Spec: v1alpha1.FlowSpec{
					DestinationCIDRs: []string{"20.0.0.1/32", "2000::1/128"},
					Protocols: []v1alpha1.TransportProtocol{
						v1alpha1.TCP,
					},
					Priority: 1,
				},
			}
			Expect(k8sClient.Create(ctx, flow)).Should(Succeed())

			service = &v1.Service{
				ObjectMeta: metav1.ObjectMeta{
					Name:      serviceAName,
					Namespace: namespace,
					Labels: map[string]string{
						v1alpha1.LabelServiceProxy: serviceProxy,
					},
				},
				Spec: v1.ServiceSpec{
					ClusterIP: "None",
				},
			}
			Expect(k8sClient.Create(ctx, service)).Should(Succeed())
		})

		AfterEach(func() {
			Expect(k8sClient.Delete(ctx, flow)).Should(Succeed())

			lbService, exists := fakeLB.services[serviceAName]
			Expect(exists).To(BeTrue())
			Expect(lbService).ToNot(BeNil())

			Eventually(func() bool {
				lbService.mu.Lock()
				defer lbService.mu.Unlock()
				return len(lbService.flows) == 0
			}, timeout, interval).Should(BeTrue())

			Expect(k8sClient.Delete(ctx, service)).Should(Succeed())

			Eventually(func() bool {
				fakeLB.mu.Lock()
				defer fakeLB.mu.Unlock()
				return len(fakeLB.services) == 0
			}, timeout, interval).Should(BeTrue())
		})

		It("does register it and the flow too", func() {
			By("Checking the service is configured")
			Eventually(func() bool {
				fakeLB.mu.Lock()
				defer fakeLB.mu.Unlock()
				return len(fakeLB.services) == 1
			}, timeout, interval).Should(BeTrue())

			service, exists := fakeLB.services[serviceAName]
			Expect(exists).To(BeTrue())
			Expect(service).ToNot(BeNil())

			By("Checking the flow is configured")
			Eventually(func() bool {
				service.mu.Lock()
				defer service.mu.Unlock()
				return len(service.flows) == 1
			}, timeout, interval).Should(BeTrue())
		})
	})

	When("Creating a service with dualstack endpointslice", func() {
		var (
			service         *v1.Service
			endpointSliceV4 *v1discovery.EndpointSlice
			endpointSliceV6 *v1discovery.EndpointSlice
			ctx             context.Context
		)

		BeforeEach(func() {
			ctx = context.Background()

			service = &v1.Service{
				ObjectMeta: metav1.ObjectMeta{
					Name:      serviceAName,
					Namespace: namespace,
					Labels: map[string]string{
						v1alpha1.LabelServiceProxy: serviceProxy,
					},
				},
				Spec: v1.ServiceSpec{
					ClusterIP: "None",
				},
			}

			id := "10"
			targetRef := &v1.ObjectReference{
				Name: "pod-a",
				UID:  "123",
			}
			readyTrue := true
			endpointSliceV4 = &v1discovery.EndpointSlice{
				ObjectMeta: metav1.ObjectMeta{
					Name:      endpoint.GetEndpointSliceName(service, v1discovery.AddressTypeIPv4),
					Namespace: namespace,
					Labels: map[string]string{
						v1alpha1.LabelService: service.GetName(),
					},
				},
				Endpoints: []v1discovery.Endpoint{
					{
						Addresses: []string{"172.16.0.1"},
						TargetRef: targetRef,
						Zone:      &id,
						Conditions: v1discovery.EndpointConditions{
							Ready: &readyTrue,
						},
					},
				},
				AddressType: v1discovery.AddressTypeIPv4,
			}
			Expect(k8sClient.Create(ctx, endpointSliceV4)).Should(Succeed())

			endpointSliceV6 = &v1discovery.EndpointSlice{
				ObjectMeta: metav1.ObjectMeta{
					Name:      endpoint.GetEndpointSliceName(service, v1discovery.AddressTypeIPv6),
					Namespace: namespace,
					Labels: map[string]string{
						v1alpha1.LabelService: service.GetName(),
					},
				},
				Endpoints: []v1discovery.Endpoint{
					{
						Addresses: []string{"fd00::1"},
						TargetRef: targetRef,
						Zone:      &id,
						Conditions: v1discovery.EndpointConditions{
							Ready: &readyTrue,
						},
					},
				},
				AddressType: v1discovery.AddressTypeIPv6,
			}
			Expect(k8sClient.Create(ctx, endpointSliceV6)).Should(Succeed())

			Expect(k8sClient.Create(ctx, service)).Should(Succeed())
		})

		AfterEach(func() {
			Expect(k8sClient.Delete(ctx, service)).Should(Succeed())

			Eventually(func() bool {
				fakeLB.mu.Lock()
				defer fakeLB.mu.Unlock()
				return len(fakeLB.services) == 0
			}, timeout, interval).Should(BeTrue())

			Expect(k8sClient.Delete(ctx, endpointSliceV4)).Should(Succeed())
			Expect(k8sClient.Delete(ctx, endpointSliceV6)).Should(Succeed())
		})

		It("does register it and the flow too", func() {
			By("Checking the service is configured")
			Eventually(func() bool {
				fakeLB.mu.Lock()
				defer fakeLB.mu.Unlock()
				return len(fakeLB.services) == 1
			}, timeout, interval).Should(BeTrue())

			service, exists := fakeLB.services[serviceAName]
			Expect(exists).To(BeTrue())
			Expect(service).ToNot(BeNil())

			By("Checking the target is configured")
			Eventually(func() bool {
				service.mu.Lock()
				defer service.mu.Unlock()
				return len(service.targets) == 1
			}, timeout, interval).Should(BeTrue())
		})
	})
})
