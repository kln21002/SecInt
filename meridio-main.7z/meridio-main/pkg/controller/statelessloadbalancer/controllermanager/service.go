/*
Copyright (c) 2023 Nordix Foundation

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package controllermanager

import (
	"context"
	"fmt"

	"github.com/meridio-io/meridio/api/v1alpha1"
	"github.com/meridio-io/meridio/pkg/controller/statelessloadbalancer/network"
	v1 "k8s.io/api/core/v1"
	v1discovery "k8s.io/api/discovery/v1"
	apierrors "k8s.io/apimachinery/pkg/api/errors"
	"k8s.io/apimachinery/pkg/runtime"
	ctrl "sigs.k8s.io/controller-runtime"
	"sigs.k8s.io/controller-runtime/pkg/client"
	"sigs.k8s.io/controller-runtime/pkg/handler"
)

// GetIPs represents the function to get the IPs assigned to a pod
// for a specific network.
type GetIPs func(pod v1.Pod, networks []*v1alpha1.Network) ([]string, error)

// ServiceController reconciles a Service object as a stateless load-balancer
// controller manager. It manages the endpointslices for a service proxy.
type ServiceController struct {
	client.Client
	Scheme *runtime.Scheme
	// ServiceProxy is used to reconcile the service with the
	// correct label.
	ServiceProxy string
	// GetIPsFunc is used when the endpointSlice will be reconciled to get the IPs
	// of the pods attached to the service.
	GetIPsFunc GetIPs
	// Networks is used when calling GetIPsFunc.
	// They represent the networks that will be reconciled.
	Networks []*v1alpha1.Network
}

// NewServiceController is the constructor of the ServiceController struct.
func NewServiceController(
	clnt client.Client,
	scheme *runtime.Scheme,
	serviceProxy string,
	networks []*v1alpha1.Network,
) *ServiceController {
	serviceController := &ServiceController{
		Client:       clnt,
		Scheme:       scheme,
		ServiceProxy: serviceProxy,
		Networks:     networks,
		GetIPsFunc:   network.GetIPs,
	}

	return serviceController
}

// Reconcile implements the reconciliation of the Service object as a stateless load-balancer
// conctroller manager.
// This function is trigger by any change (create/update/delete) in any resource related
// to the object (Service, Pod, EndpointSlice).
//
// For more details, check Reconcile and its Result here:
// - https://pkg.go.dev/sigs.k8s.io/controller-runtime@v0.13.0/pkg/reconcile
func (sc *ServiceController) Reconcile(ctx context.Context, req ctrl.Request) (ctrl.Result, error) {
	service := &v1.Service{}

	err := sc.Get(ctx, req.NamespacedName, service)
	if err != nil {
		if apierrors.IsNotFound(err) {
			return ctrl.Result{}, nil
		}

		return ctrl.Result{}, fmt.Errorf("failed to get the service: %w", err)
	}

	// Get pods for this service so the endpointslices can be reconciled.
	var matchingLabels client.MatchingLabels = service.Spec.Selector

	pods := &v1.PodList{}

	err = sc.List(ctx,
		pods,
		matchingLabels)
	if err != nil {
		return ctrl.Result{}, fmt.Errorf("failed to list the pods: %w", err)
	}

	err = sc.reconcileEndpointSlices(ctx, service, pods)
	if err != nil {
		return ctrl.Result{}, err
	}

	return ctrl.Result{}, nil
}

// SetupWithManager sets up the controller with the Manager.
func (sc *ServiceController) SetupWithManager(mgr ctrl.Manager) error {
	err := ctrl.NewControllerManagedBy(mgr).
		For(&v1.Service{}).
		Owns(&v1discovery.EndpointSlice{}).
		// With EnqueueRequestsFromMapFunc, on an update the func is called twice
		// (1 time for old and 1 time for new object)
		Watches(&v1.Pod{}, handler.EnqueueRequestsFromMapFunc(sc.podEnqueue)).
		Complete(sc)
	if err != nil {
		return fmt.Errorf("failed to build the service controller manager: %w", err)
	}

	return nil
}
