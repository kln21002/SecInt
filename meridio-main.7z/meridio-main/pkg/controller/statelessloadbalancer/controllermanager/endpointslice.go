/*
Copyright (c) 2023 Nordix Foundation

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package controllermanager

import (
	"context"
	"fmt"
	"net"
	"strconv"

	"github.com/meridio-io/meridio/api/v1alpha1"
	"github.com/meridio-io/meridio/pkg/controller/statelessloadbalancer/endpoint"
	v1 "k8s.io/api/core/v1"
	v1discovery "k8s.io/api/discovery/v1"
	apierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
	ctrl "sigs.k8s.io/controller-runtime"
)

type createUpdateEndpointSliceFunc func(
	ctx context.Context,
	addressType v1discovery.AddressType,
	endpointSlice *v1discovery.EndpointSlice,
) error

// reconcileEndpointSlices reconciles the EndpointSlices for IPv4 and IPv6 for a specific service.
func (sc *ServiceController) reconcileEndpointSlices(
	ctx context.Context,
	service *v1.Service,
	pods *v1.PodList,
) error {
	createUpdateEndpointSliceIPv4Func := sc.updateEndpointSlice
	createUpdateEndpointSliceIPv6Func := sc.updateEndpointSlice
	ipv4EndpointSlice := &v1discovery.EndpointSlice{}
	ipv6EndpointSlice := &v1discovery.EndpointSlice{}

	// Check if previous endpointslice was existing
	err := sc.Get(ctx, types.NamespacedName{
		Name:      endpoint.GetEndpointSliceName(service, v1discovery.AddressTypeIPv4),
		Namespace: service.GetNamespace(),
	}, ipv4EndpointSlice)
	if err != nil {
		if !apierrors.IsNotFound(err) {
			return fmt.Errorf("failed to get IPv4 EndpointSlice: %w", err)
		}

		createUpdateEndpointSliceIPv4Func = sc.createEndpointSlice
	}

	err = sc.Get(ctx, types.NamespacedName{
		Name:      endpoint.GetEndpointSliceName(service, v1discovery.AddressTypeIPv6),
		Namespace: service.GetNamespace(),
	}, ipv6EndpointSlice)
	if err != nil {
		if !apierrors.IsNotFound(err) {
			return fmt.Errorf("failed to get IPv6 EndpointSlice: %w", err)
		}

		createUpdateEndpointSliceIPv6Func = sc.createEndpointSlice
	}

	mergedEndpointSlices := endpoint.MergeEndpointSlices(ipv4EndpointSlice, ipv6EndpointSlice)
	mergedEndpoints := []v1discovery.Endpoint{}

	if mergedEndpointSlices != nil {
		mergedEndpoints = mergedEndpointSlices.Endpoints
	}

	var maxEndpoints uint32 = 100 // default max endpoints

	valueServiceMaxEndpoints, exists := service.GetLabels()[v1alpha1.LabelServiceMaxEndpoints]
	if exists {
		maxEndpointsInt, err := strconv.Atoi(valueServiceMaxEndpoints)
		if err == nil {
			maxEndpoints = uint32(maxEndpointsInt)
		}
	}

	identifiers := getIdentifiers(maxEndpoints, pods, mergedEndpoints)

	// reconcile ipv4 endpointslice
	err = sc.reconcileEndpointSlice(
		ctx,
		service,
		pods,
		v1discovery.AddressTypeIPv4,
		identifiers,
		createUpdateEndpointSliceIPv4Func,
	)
	if err != nil {
		return err
	}

	// reconcile ipv6 endpointslice
	err = sc.reconcileEndpointSlice(
		ctx,
		service,
		pods,
		v1discovery.AddressTypeIPv6,
		identifiers,
		createUpdateEndpointSliceIPv6Func,
	)
	if err != nil {
		return err
	}

	return nil
}

func (sc *ServiceController) reconcileEndpointSlice(
	ctx context.Context,
	service *v1.Service,
	pods *v1.PodList,
	addressType v1discovery.AddressType,
	identifiers map[string]int,
	createUpdateEndpointSlice createUpdateEndpointSliceFunc,
) error {
	endpointSlice, err := sc.getEndpointSlice(
		service,
		pods,
		addressType,
		identifiers,
	)
	if err != nil {
		return fmt.Errorf("failed to reconcile %v EndpointSlice: %w", addressType, err)
	}

	err = createUpdateEndpointSlice(ctx, addressType, endpointSlice)
	if err != nil {
		return err
	}

	return nil
}

func (sc *ServiceController) createEndpointSlice(
	ctx context.Context,
	addressType v1discovery.AddressType,
	endpointSlice *v1discovery.EndpointSlice,
) error {
	err := sc.Create(ctx, endpointSlice)
	if err != nil {
		return fmt.Errorf("failed to create %v EndpointSlice: %w", addressType, err)
	}

	return nil
}

func (sc *ServiceController) updateEndpointSlice(
	ctx context.Context,
	addressType v1discovery.AddressType,
	endpointSlice *v1discovery.EndpointSlice,
) error {
	err := sc.Update(ctx, endpointSlice)
	if err != nil {
		return fmt.Errorf("failed to update %v EndpointSlice: %w", addressType, err)
	}

	return nil
}

func (sc *ServiceController) getEndpointSlice(
	service *v1.Service,
	pods *v1.PodList,
	addressType v1discovery.AddressType,
	identifiers map[string]int,
) (*v1discovery.EndpointSlice, error) {
	endpoints := sc.getEndpoints(pods, addressType, identifiers)

	endpointSlice := &v1discovery.EndpointSlice{
		ObjectMeta: metav1.ObjectMeta{
			Name:      endpoint.GetEndpointSliceName(service, addressType),
			Namespace: service.GetNamespace(),
			Labels: map[string]string{
				v1alpha1.LabelService: service.GetName(),
			},
		},
		Endpoints:   endpoints,
		AddressType: addressType,
	}

	err := ctrl.SetControllerReference(service, endpointSlice, sc.Scheme)
	if err != nil {
		return nil, fmt.Errorf("failed to SetControllerReference on EndpointSlice: %w", err)
	}

	return endpointSlice, nil
}

func (sc *ServiceController) getEndpoints(
	pods *v1.PodList,
	addressType v1discovery.AddressType,
	identifiers map[string]int,
) []v1discovery.Endpoint {
	endpoints := []v1discovery.Endpoint{}

	// get the UPs and readiness of the pods
	for _, pod := range pods.Items {
		ready := podReady(pod)

		ips, _ := sc.GetIPsFunc(pod, sc.Networks) // todo: error

		endpointIPs := []string{}

		// Get only IPs of correct IP family
		for _, ip := range ips {
			ipAddr := net.ParseIP(ip)

			if ipAddr == nil {
				continue
			}

			ipFamily := v1discovery.AddressTypeIPv6

			if ipAddr.To4() != nil {
				ipFamily = v1discovery.AddressTypeIPv4
			}

			if ipFamily == addressType {
				endpointIPs = append(endpointIPs, ip)
			}
		}

		// an endpoint does not access empty address list
		if len(endpointIPs) == 0 {
			continue
		}

		var idString *string

		id, exists := identifiers[string(pod.UID)]
		if exists {
			str := strconv.Itoa(id)
			idString = &str
		}

		endpnt := v1discovery.Endpoint{
			TargetRef: &v1.ObjectReference{
				Kind:      pod.Kind,
				Name:      pod.GetName(),
				Namespace: pod.GetNamespace(),
				UID:       pod.GetUID(),
			},
			Conditions: v1discovery.EndpointConditions{
				Ready: &ready,
			},
			Addresses: endpointIPs,
			Zone:      idString,
		}
		endpoints = append(endpoints, endpnt)
	}

	return endpoints
}

// podReady checks if a pod is ready: All containers in ready state and pod status running.
func podReady(pod v1.Pod) bool {
	for _, container := range pod.Status.ContainerStatuses {
		if !container.Ready {
			return false
		}
	}

	return pod.Status.Phase == v1.PodRunning
}

func getIdentifiers(
	maxEndpoints uint32,
	pods *v1.PodList,
	endpoints []v1discovery.Endpoint,
) map[string]int {
	identifiers := map[string]int{}

	identifierInUseMap := map[int]struct{}{}
	podMap := map[string]v1.Pod{}

	for _, pod := range pods.Items {
		// todo: skip the pods with no network and non ready pods
		podMap[string(pod.UID)] = pod
	}

	// collect identifiers in use
	for _, endpnt := range endpoints {
		pod, exists := podMap[string(endpnt.TargetRef.UID)]
		if !exists || !podReady(pod) { // todo: remove non ready and move filter in previous loop
			continue
		}

		id := endpoint.GetIdentifier(endpnt)
		if id == nil {
			continue
		}

		identifiers[string(pod.UID)] = *id
		identifierInUseMap[*id] = struct{}{}
	}

	// compute new identifiers
	for _, pod := range pods.Items {
		_, exists := identifiers[string(pod.UID)]
		if !podReady(pod) || exists {
			continue
		}

		identifier := getIdentifier(identifierInUseMap, maxEndpoints)
		if identifier < 0 {
			continue
		}

		identifierInUseMap[identifier] = struct{}{}
		identifiers[string(pod.UID)] = identifier
	}

	return identifiers
}

// getIdentifier returns a free identifier. -1 is returned if none could be found.
func getIdentifier(identifierInUseMap map[int]struct{}, maxEndpoints uint32) int {
	for i := 0; i < int(maxEndpoints); i++ {
		_, exists := identifierInUseMap[i]
		if !exists {
			return i
		}
	}

	return -1
}
