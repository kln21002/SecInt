/*
Copyright (c) 2023 Nordix Foundation

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package controllermanager_test

import (
	"context"
	"time"

	netdefv1 "github.com/k8snetworkplumbingwg/network-attachment-definition-client/pkg/apis/k8s.cni.cncf.io/v1"
	"github.com/meridio-io/meridio/api/v1alpha1"
	"github.com/meridio-io/meridio/pkg/controller/statelessloadbalancer/endpoint"
	. "github.com/onsi/ginkgo/v2"
	. "github.com/onsi/gomega"
	v1 "k8s.io/api/core/v1"
	v1discovery "k8s.io/api/discovery/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
)

var _ = Describe("Service controller", func() {
	const (
		serviceAName = "service-a"
		timeout      = time.Second * 10
		interval     = time.Millisecond * 250
	)

	When("Creating a service", func() {
		var (
			service           *v1.Service
			ctx               context.Context
			ipv4EndpointSlice *v1discovery.EndpointSlice
			ipv6EndpointSlice *v1discovery.EndpointSlice
		)

		BeforeEach(func() {
			ctx = context.Background()

			service = &v1.Service{
				ObjectMeta: metav1.ObjectMeta{
					Name:      serviceAName,
					Namespace: namespace,
					Labels: map[string]string{
						v1alpha1.LabelServiceProxy: serviceProxy,
					},
				},
				Spec: v1.ServiceSpec{
					ClusterIP: "None",
				},
			}
			Expect(k8sClient.Create(ctx, service)).Should(Succeed())
		})

		AfterEach(func() {
			Expect(k8sClient.Delete(ctx, service)).Should(Succeed())

			// https://book.kubebuilder.io/reference/envtest.html#testing-considerations
			// https://stackoverflow.com/questions/64821970/operator-controller-could-not-delete-correlated-resources
			// Kubelet garbage collection doesn't work with envTest, so the deployment has to be deleted manually.
			if ipv4EndpointSlice != nil {
				Expect(k8sClient.Delete(ctx, ipv4EndpointSlice)).Should(Succeed())
			}
			if ipv6EndpointSlice != nil {
				Expect(k8sClient.Delete(ctx, ipv6EndpointSlice)).Should(Succeed())
			}
		})

		It("endpointslices are created", func() {
			By("Checking the ipv4 endpointslice")
			key := types.NamespacedName{Name: endpoint.GetEndpointSliceName(service, v1discovery.AddressTypeIPv4), Namespace: namespace}
			ipv4EndpointSlice = &v1discovery.EndpointSlice{}

			Eventually(func() bool {
				err := k8sClient.Get(ctx, key, ipv4EndpointSlice)
				return err == nil
			}, timeout, interval).Should(BeTrue())
			Expect(ipv4EndpointSlice.AddressType).Should(Equal(v1discovery.AddressTypeIPv4))
			Expect(ipv4EndpointSlice.Endpoints).Should(BeNil())

			By("Checking the ipv6 endpointslice")
			key = types.NamespacedName{Name: endpoint.GetEndpointSliceName(service, v1discovery.AddressTypeIPv6), Namespace: namespace}
			ipv6EndpointSlice = &v1discovery.EndpointSlice{}

			Eventually(func() bool {
				err := k8sClient.Get(ctx, key, ipv6EndpointSlice)
				return err == nil
			}, timeout, interval).Should(BeTrue())
			Expect(ipv6EndpointSlice.AddressType).Should(Equal(v1discovery.AddressTypeIPv6))
			Expect(ipv6EndpointSlice.Endpoints).Should(BeNil())
		})
	})

	When("Creating a service with pods selected", func() {
		var (
			service              *v1.Service
			ctx                  context.Context
			ipv4EndpointSlice    *v1discovery.EndpointSlice
			ipv6EndpointSlice    *v1discovery.EndpointSlice
			podSelected          *v1.Pod
			podSelectedNotReady  *v1.Pod
			podSelectedNoNetwork *v1.Pod
			podNotSelected       *v1.Pod
			podSelectedOnTheFly  *v1.Pod
		)

		BeforeEach(func() {
			ctx = context.Background()

			podSelected = &v1.Pod{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "service",
					Namespace: namespace,
					Labels: map[string]string{
						"type": "service",
					},
					Annotations: map[string]string{
						netdefv1.NetworkStatusAnnot: "[{\"name\":\"default/macvlan-nad\",\"interface\":\"net1\",\"ips\":[\"169.255.100.6\",\"fd00::6\"],\"mac\":\"72:24:87:fc:10:a8\",\"dns\":{}}]",
					},
				},
				Spec: v1.PodSpec{
					Containers: []v1.Container{
						{
							Name:  "test",
							Image: "abc",
						},
					},
				},
				Status: v1.PodStatus{
					Phase: v1.PodRunning,
					ContainerStatuses: []v1.ContainerStatus{
						{
							Name:  "test",
							Ready: true,
						},
					},
				},
			}
			Expect(k8sClient.Create(ctx, podSelected)).Should(Succeed())
			key := types.NamespacedName{Name: podSelected.Name, Namespace: namespace}
			Expect(k8sClient.Get(ctx, key, podSelected)).Should(Succeed())
			podSelected.Status.Phase = v1.PodRunning
			Expect(k8sClient.Status().Update(ctx, podSelected)).Should(Succeed())

			podSelectedNotReady = &v1.Pod{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "service-not-ready",
					Namespace: namespace,
					Labels: map[string]string{
						"type": "service",
					},
					Annotations: map[string]string{
						netdefv1.NetworkStatusAnnot: "[{\"name\":\"default/macvlan-nad\",\"interface\":\"net1\",\"ips\":[\"169.255.100.10\",\"fd00::10\"],\"mac\":\"72:24:87:fc:10:b8\",\"dns\":{}}]",
					},
				},
				Spec: v1.PodSpec{
					Containers: []v1.Container{
						{
							Name:  "test",
							Image: "abc",
						},
					},
				},
				Status: v1.PodStatus{
					Phase: v1.PodPending,
					ContainerStatuses: []v1.ContainerStatus{
						{
							Name:  "test",
							Ready: false,
						},
					},
				},
			}
			Expect(k8sClient.Create(ctx, podSelectedNotReady)).Should(Succeed())

			podSelectedNoNetwork = &v1.Pod{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "service-no-network",
					Namespace: namespace,
					Labels: map[string]string{
						"type": "service",
					},
					Annotations: map[string]string{
						netdefv1.NetworkStatusAnnot: "[{\"name\":\"default/other-network\",\"interface\":\"net1\",\"ips\":[\"169.255.101.6\",\"fd01::6\"],\"mac\":\"72:24:87:fc:10:a9\",\"dns\":{}}]",
					},
				},
				Spec: v1.PodSpec{
					Containers: []v1.Container{
						{
							Name:  "test",
							Image: "abc",
						},
					},
				},
				Status: v1.PodStatus{
					Phase: v1.PodRunning,
					ContainerStatuses: []v1.ContainerStatus{
						{
							Name:  "test",
							Ready: true,
						},
					},
				},
			}
			Expect(k8sClient.Create(ctx, podSelectedNoNetwork)).Should(Succeed())
			key = types.NamespacedName{Name: podSelectedNoNetwork.Name, Namespace: namespace}
			Expect(k8sClient.Get(ctx, key, podSelectedNoNetwork)).Should(Succeed())
			podSelectedNoNetwork.Status.Phase = v1.PodRunning
			Expect(k8sClient.Status().Update(ctx, podSelectedNoNetwork)).Should(Succeed())

			podNotSelected = &v1.Pod{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "not-service",
					Namespace: namespace,
					Labels: map[string]string{
						"type": "not-service",
					},
					Annotations: map[string]string{
						netdefv1.NetworkStatusAnnot: "[{\"name\":\"default/macvlan-nad\",\"interface\":\"net1\",\"ips\":[\"169.255.100.5\",\"fd00::5\"],\"mac\":\"72:24:87:fc:10:a7\",\"dns\":{}}]",
					},
				},
				Spec: v1.PodSpec{
					Containers: []v1.Container{
						{
							Name:  "test",
							Image: "abc",
						},
					},
				},
				Status: v1.PodStatus{
					Phase: v1.PodRunning,
					ContainerStatuses: []v1.ContainerStatus{
						{
							Name:  "test",
							Ready: true,
						},
					},
				},
			}
			Expect(k8sClient.Create(ctx, podNotSelected)).Should(Succeed())
			key = types.NamespacedName{Name: podNotSelected.Name, Namespace: namespace}
			Expect(k8sClient.Get(ctx, key, podNotSelected)).Should(Succeed())
			podNotSelected.Status.Phase = v1.PodRunning
			Expect(k8sClient.Status().Update(ctx, podNotSelected)).Should(Succeed())

			podSelectedOnTheFly = &v1.Pod{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "service-on-the-fly",
					Namespace: namespace,
					Labels: map[string]string{
						"type": "service",
					},
					Annotations: map[string]string{
						netdefv1.NetworkStatusAnnot: "[{\"name\":\"default/macvlan-nad\",\"interface\":\"net1\",\"ips\":[\"169.255.100.11\",\"fd00::11\"],\"mac\":\"72:24:87:fc:10:b1\",\"dns\":{}}]",
					},
				},
				Spec: v1.PodSpec{
					Containers: []v1.Container{
						{
							Name:  "test",
							Image: "abc",
						},
					},
				},
				Status: v1.PodStatus{
					Phase: v1.PodRunning,
					ContainerStatuses: []v1.ContainerStatus{
						{
							Name:  "test",
							Ready: true,
						},
					},
				},
			}

			service = &v1.Service{
				ObjectMeta: metav1.ObjectMeta{
					Name:      serviceAName,
					Namespace: namespace,
					Labels: map[string]string{
						v1alpha1.LabelServiceProxy: serviceProxy,
					},
				},
				Spec: v1.ServiceSpec{
					ClusterIP: "None",
					Selector: map[string]string{
						"type": "service",
					},
				},
			}
			Expect(k8sClient.Create(ctx, service)).Should(Succeed())
		})

		AfterEach(func() {
			Expect(k8sClient.Delete(ctx, service)).Should(Succeed())

			// https://book.kubebuilder.io/reference/envtest.html#testing-considerations
			// https://stackoverflow.com/questions/64821970/operator-controller-could-not-delete-correlated-resources
			// Kubelet garbage collection doesn't work with envTest, so the deployment has to be deleted manually.
			if ipv4EndpointSlice != nil {
				Expect(k8sClient.Delete(ctx, ipv4EndpointSlice)).Should(Succeed())
			}
			if ipv6EndpointSlice != nil {
				Expect(k8sClient.Delete(ctx, ipv6EndpointSlice)).Should(Succeed())
			}

			Expect(k8sClient.Delete(ctx, podSelected)).Should(Succeed())
			Expect(k8sClient.Delete(ctx, podSelectedNotReady)).Should(Succeed())
			Expect(k8sClient.Delete(ctx, podSelectedNoNetwork)).Should(Succeed())
			Expect(k8sClient.Delete(ctx, podNotSelected)).Should(Succeed())
		})

		It("endpointslices are created with 2 endpoints", func() {
			By("Checking the ipv4 endpointslice")
			key := types.NamespacedName{Name: endpoint.GetEndpointSliceName(service, v1discovery.AddressTypeIPv4), Namespace: namespace}
			ipv4EndpointSlice = &v1discovery.EndpointSlice{}

			Eventually(func() bool {
				err := k8sClient.Get(ctx, key, ipv4EndpointSlice)
				return err == nil
			}, timeout, interval).Should(BeTrue())
			Expect(len(ipv4EndpointSlice.Endpoints)).Should(Equal(2))

			By("Checking the ipv6 endpointslice")
			key = types.NamespacedName{Name: endpoint.GetEndpointSliceName(service, v1discovery.AddressTypeIPv6), Namespace: namespace}
			ipv6EndpointSlice = &v1discovery.EndpointSlice{}

			Eventually(func() bool {
				err := k8sClient.Get(ctx, key, ipv6EndpointSlice)
				return err == nil
			}, timeout, interval).Should(BeTrue())
			Expect(len(ipv6EndpointSlice.Endpoints)).Should(Equal(2))

			Expect(len(ipv4EndpointSlice.Endpoints[0].Addresses)).Should(Equal(1))
			Expect(len(ipv6EndpointSlice.Endpoints[0].Addresses)).Should(Equal(1))
			Expect(len(ipv4EndpointSlice.Endpoints[1].Addresses)).Should(Equal(1))
			Expect(len(ipv6EndpointSlice.Endpoints[1].Addresses)).Should(Equal(1))

			if ipv4EndpointSlice.Endpoints[0].TargetRef.Name == podSelected.Name {
				Expect(ipv4EndpointSlice.Endpoints[0].TargetRef.Name).Should(Equal(podSelected.Name))
				Expect(ipv6EndpointSlice.Endpoints[0].TargetRef.UID).Should(Equal(podSelected.UID))
				Expect(ipv4EndpointSlice.Endpoints[0].Addresses[0]).Should(Equal("169.255.100.6"))
				Expect(ipv6EndpointSlice.Endpoints[0].Addresses[0]).Should(Equal("fd00::6"))

				Expect(ipv4EndpointSlice.Endpoints[1].TargetRef.Name).Should(Equal(podSelectedNotReady.Name))
				Expect(ipv6EndpointSlice.Endpoints[1].TargetRef.UID).Should(Equal(podSelectedNotReady.UID))
				Expect(ipv4EndpointSlice.Endpoints[1].Addresses[0]).Should(Equal("169.255.100.10"))
				Expect(ipv6EndpointSlice.Endpoints[1].Addresses[0]).Should(Equal("fd00::10"))
			} else {
				Expect(ipv4EndpointSlice.Endpoints[0].TargetRef.Name).Should(Equal(podSelectedNotReady.Name))
				Expect(ipv6EndpointSlice.Endpoints[0].TargetRef.UID).Should(Equal(podSelectedNotReady.UID))
				Expect(ipv4EndpointSlice.Endpoints[0].Addresses[0]).Should(Equal("169.255.100.10"))
				Expect(ipv6EndpointSlice.Endpoints[0].Addresses[0]).Should(Equal("fd00::10"))

				Expect(ipv4EndpointSlice.Endpoints[1].TargetRef.Name).Should(Equal(podSelected.Name))
				Expect(ipv6EndpointSlice.Endpoints[1].TargetRef.UID).Should(Equal(podSelected.UID))
				Expect(ipv4EndpointSlice.Endpoints[1].Addresses[0]).Should(Equal("169.255.100.6"))
				Expect(ipv6EndpointSlice.Endpoints[1].Addresses[0]).Should(Equal("fd00::6"))
			}
		})

		It("adds and remove endpoints on the fly", func() {
			By("Adding a new selected pod")
			Expect(k8sClient.Create(ctx, podSelectedOnTheFly)).Should(Succeed())
			key := types.NamespacedName{Name: podSelectedOnTheFly.Name, Namespace: namespace}
			Expect(k8sClient.Get(ctx, key, podSelectedOnTheFly)).Should(Succeed())
			podSelectedOnTheFly.Status.Phase = v1.PodRunning
			Expect(k8sClient.Status().Update(ctx, podSelectedOnTheFly)).Should(Succeed())

			By("Checking the ipv4 endpointslice")
			key = types.NamespacedName{Name: endpoint.GetEndpointSliceName(service, v1discovery.AddressTypeIPv4), Namespace: namespace}
			ipv4EndpointSlice = &v1discovery.EndpointSlice{}

			Eventually(func() bool {
				err := k8sClient.Get(ctx, key, ipv4EndpointSlice)
				return err == nil && len(ipv4EndpointSlice.Endpoints) == 3
			}, timeout, interval).Should(BeTrue())

			By("Checking the ipv6 endpointslice")
			key = types.NamespacedName{Name: endpoint.GetEndpointSliceName(service, v1discovery.AddressTypeIPv6), Namespace: namespace}
			ipv6EndpointSlice = &v1discovery.EndpointSlice{}

			Eventually(func() bool {
				err := k8sClient.Get(ctx, key, ipv6EndpointSlice)
				return err == nil && len(ipv6EndpointSlice.Endpoints) == 3
			}, timeout, interval).Should(BeTrue())

			By("Deleting the selected pod")
			Expect(k8sClient.Delete(ctx, podSelectedOnTheFly)).Should(Succeed())

			By("Checking the ipv4 endpointslice")
			key = types.NamespacedName{Name: endpoint.GetEndpointSliceName(service, v1discovery.AddressTypeIPv4), Namespace: namespace}
			ipv4EndpointSlice = &v1discovery.EndpointSlice{}

			Eventually(func() bool {
				err := k8sClient.Get(ctx, key, ipv4EndpointSlice)
				return err == nil && len(ipv4EndpointSlice.Endpoints) == 2
			}, timeout, interval).Should(BeTrue())

			By("Checking the ipv6 endpointslice")
			key = types.NamespacedName{Name: endpoint.GetEndpointSliceName(service, v1discovery.AddressTypeIPv6), Namespace: namespace}
			ipv6EndpointSlice = &v1discovery.EndpointSlice{}

			Eventually(func() bool {
				err := k8sClient.Get(ctx, key, ipv6EndpointSlice)
				return err == nil && len(ipv6EndpointSlice.Endpoints) == 2
			}, timeout, interval).Should(BeTrue())
		})
	})
})
