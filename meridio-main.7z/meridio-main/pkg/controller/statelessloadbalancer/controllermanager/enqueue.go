/*
Copyright (c) 2023 Nordix Foundation

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package controllermanager

import (
	"context"

	"github.com/meridio-io/meridio/api/v1alpha1"
	"github.com/meridio-io/meridio/pkg/log"
	v1 "k8s.io/api/core/v1"
	apierrors "k8s.io/apimachinery/pkg/api/errors"
	"k8s.io/apimachinery/pkg/types"
	"sigs.k8s.io/controller-runtime/pkg/client"
	"sigs.k8s.io/controller-runtime/pkg/reconcile"
)

func (sc *ServiceController) podEnqueue(ctx context.Context, object client.Object) []reconcile.Request {
	reconcileRequests := []reconcile.Request{}
	services := &v1.ServiceList{}

	// todo: check https://github.com/kubernetes-sigs/controller-runtime/blob/v0.15.0/pkg/client/options.go#L412
	err := sc.List(ctx,
		services,
		client.MatchingLabels{
			v1alpha1.LabelServiceProxy: sc.ServiceProxy,
		})
	if err != nil {
		log.FromContextOrGlobal(ctx).Error(err, "failed listing the services during the pod enqueue")
	}

items:
	for _, service := range services.Items {
		for labelSelectorKey, labelSelectorValue := range service.Spec.Selector {
			value, exists := object.GetLabels()[labelSelectorKey]
			if !exists || value != labelSelectorValue {
				continue items
			}
		}
		reconcileRequests = append(reconcileRequests,
			reconcile.Request{
				NamespacedName: types.NamespacedName{
					Name:      service.GetName(),
					Namespace: service.GetNamespace(),
				},
			})
	}

	return reconcileRequests
}

func (pc *PodController) podEnqueue(ctx context.Context, object client.Object) []reconcile.Request {
	reconcileRequests := []reconcile.Request{}

	value, exists := object.GetLabels()[v1alpha1.LabelServiceProxy]
	if !exists || value != pc.ServiceProxy {
		return reconcileRequests
	}

	value, exists = object.GetLabels()[v1alpha1.LabelServiceProxyPlane]
	if !exists || value != v1alpha1.ValueDataPlane {
		return reconcileRequests
	}

	services := &v1.ServiceList{}

	err := pc.List(ctx,
		services,
		client.MatchingLabels{
			v1alpha1.LabelServiceProxy: pc.ServiceProxy,
		})
	if err != nil {
		log.FromContextOrGlobal(ctx).Error(err, "failed listing the services during the pod enqueue")
	}

	return pc.getPodsForServices(ctx, services.Items, object.GetNamespace())
}

func (pc *PodController) serviceEnqueue(ctx context.Context, object client.Object) []reconcile.Request {
	reconcileRequests := []reconcile.Request{}

	value, exists := object.GetLabels()[v1alpha1.LabelServiceProxy]
	if !exists || value != pc.ServiceProxy {
		return reconcileRequests
	}

	service, ok := object.(*v1.Service)
	if !ok {
		log.FromContextOrGlobal(ctx).Error(nil, "unexpected object type in service enqueue, expected Service")

		return reconcileRequests
	}

	return pc.getPodsForServices(ctx, []v1.Service{*service}, object.GetNamespace())
}

func (pc *PodController) flowEnqueue(ctx context.Context, object client.Object) []reconcile.Request {
	value, exists := object.GetLabels()[v1alpha1.LabelService]
	if !exists {
		return []reconcile.Request{}
	}

	service := &v1.Service{}
	serviceKey := types.NamespacedName{Name: value, Namespace: object.GetNamespace()}

	err := pc.Get(ctx, serviceKey, service)
	if err != nil {
		if apierrors.IsNotFound(err) {
			return []reconcile.Request{}
		}

		log.FromContextOrGlobal(ctx).Error(err, "failed to get the service in flow enqueue for pod controller")
	}

	return pc.getPodsForServices(ctx, []v1.Service{*service}, object.GetNamespace())
}

func (pc *PodController) getPodsForServices(
	ctx context.Context,
	services []v1.Service,
	namespace string,
) []reconcile.Request {
	reconcileRequests := []reconcile.Request{}
	podsToReconcile := map[string]struct{}{}

	for _, service := range services {
		pods := &v1.PodList{}

		var matchingLabels client.MatchingLabels = service.Spec.Selector

		err := pc.List(ctx,
			pods,
			matchingLabels)
		if err != nil {
			log.FromContextOrGlobal(ctx).Error(err, "failed listing the pods during the pod enqueue")
		}

		for _, pod := range pods.Items {
			podsToReconcile[pod.GetName()] = struct{}{}
		}
	}

	for pod := range podsToReconcile {
		reconcileRequests = append(reconcileRequests,
			reconcile.Request{
				NamespacedName: types.NamespacedName{
					Name:      pod,
					Namespace: namespace,
				},
			})
	}

	return reconcileRequests
}
