/*
Copyright (c) 2023 Nordix Foundation

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package controllermanager_test

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"
	"time"

	netdefv1 "github.com/k8snetworkplumbingwg/network-attachment-definition-client/pkg/apis/k8s.cni.cncf.io/v1"
	"github.com/meridio-io/meridio/api/v1alpha1"
	"github.com/meridio-io/meridio/pkg/controller/statelessloadbalancer/endpoint"
	. "github.com/onsi/ginkgo/v2"
	. "github.com/onsi/gomega"
	v1 "k8s.io/api/core/v1"
	v1discovery "k8s.io/api/discovery/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
)

var _ = Describe("Pod controller", func() {
	const (
		serviceAName = "service-a"
		flowAName    = "flow-a"
		timeout      = time.Second * 10
		interval     = time.Millisecond * 250
	)

	When("Creating a pod", func() {
		var (
			ctx                          context.Context
			pod                          *v1.Pod
			key                          types.NamespacedName
			networkSelectionElements     []netdefv1.NetworkSelectionElement
			networkSelectionElementsJSON string
		)

		BeforeEach(func() {
			ctx = context.Background()

			networkSelectionElements = []netdefv1.NetworkSelectionElement{
				{
					Name:             networkName,
					InterfaceRequest: "net1",
				},
			}
			networkSelectionElementsJSONBytes, err := json.Marshal(networkSelectionElements)
			Expect(err).Should(BeNil())
			networkSelectionElementsJSON = string(networkSelectionElementsJSONBytes)

			pod = &v1.Pod{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "service",
					Namespace: namespace,
					Labels: map[string]string{
						"type": "service",
					},
					Annotations: map[string]string{
						netdefv1.NetworkAttachmentAnnot: networkSelectionElementsJSON,
						netdefv1.NetworkStatusAnnot:     fmt.Sprintf("[{\"name\":\"%s/%s\",\"interface\":\"net1\",\"ips\":[\"169.255.100.6\",\"fd00::6\"],\"mac\":\"72:24:87:fc:10:a8\",\"dns\":{}}]", namespace, networkName),
					},
				},
				Spec: v1.PodSpec{
					Containers: []v1.Container{
						{
							Name:  "test",
							Image: "abc",
						},
					},
				},
				Status: v1.PodStatus{
					Phase: v1.PodRunning,
					ContainerStatuses: []v1.ContainerStatus{
						{
							Name:  "test",
							Ready: true,
						},
					},
				},
			}
			Expect(k8sClient.Create(ctx, pod)).Should(Succeed())
			key = types.NamespacedName{Name: pod.Name, Namespace: namespace}
			Expect(k8sClient.Get(ctx, key, pod)).Should(Succeed())
			pod.Status.Phase = v1.PodRunning
			Expect(k8sClient.Status().Update(ctx, pod)).Should(Succeed())
		})

		AfterEach(func() {
			Expect(k8sClient.Delete(ctx, pod)).Should(Succeed())
		})

		It("has not been modified", func() {
			By("Checking the pod annotation")
			Expect(k8sClient.Get(ctx, key, pod)).Should(Succeed())

			networkSelectionElementsJSONUpdated, exists := pod.Annotations[netdefv1.NetworkAttachmentAnnot]
			Expect(exists).Should(BeTrue())
			Expect(networkSelectionElementsJSONUpdated).Should(Equal(networkSelectionElementsJSON))
		})

		When("Creating a service selecting the pod and a flow", func() {
			var (
				service *v1.Service
				flow    *v1alpha1.Flow
			)

			BeforeEach(func() {
				vips := []string{"20.0.0.1/32", "2000::1/128"}
				flow = &v1alpha1.Flow{
					ObjectMeta: metav1.ObjectMeta{
						Name:      flowAName,
						Namespace: namespace,
						Labels: map[string]string{
							v1alpha1.LabelService: serviceAName,
						},
					},
					Spec: v1alpha1.FlowSpec{
						DestinationCIDRs: vips,
						Protocols: []v1alpha1.TransportProtocol{
							v1alpha1.TCP,
						},
					},
				}
				Expect(k8sClient.Create(ctx, flow)).Should(Succeed())

				service = &v1.Service{
					ObjectMeta: metav1.ObjectMeta{
						Name:      serviceAName,
						Namespace: namespace,
						Labels: map[string]string{
							v1alpha1.LabelServiceProxy: serviceProxy,
						},
					},
					Spec: v1.ServiceSpec{
						ClusterIP: "None",
						Selector: map[string]string{
							"type": "service",
						},
					},
				}
				Expect(k8sClient.Create(ctx, service)).Should(Succeed())
			})

			AfterEach(func() {
				Expect(k8sClient.Delete(ctx, service)).Should(Succeed())
				Expect(k8sClient.Delete(ctx, flow)).Should(Succeed())
				deleteEndpointSliceForService(service)

				By("Checking the pod annotation")
				Eventually(func() bool {
					Expect(k8sClient.Get(ctx, key, pod)).Should(Succeed())
					networkSelectionElementsJSONUpdated, exists := pod.Annotations[netdefv1.NetworkAttachmentAnnot]
					Expect(exists).Should(BeTrue())
					return networkSelectionElementsJSONUpdated == networkSelectionElementsJSON
				}, timeout, interval).Should(BeTrue())
			})

			It("has added the network resources to the pod", func() {
				By("Checking the pod annotation")
				var networkSelectionElementsUpdated []netdefv1.NetworkSelectionElement
				var networkSelectionElementsJSONUpdated string

				Eventually(func() bool {
					Expect(k8sClient.Get(ctx, key, pod)).Should(Succeed())

					var exists bool
					networkSelectionElementsJSONUpdated, exists = pod.Annotations[netdefv1.NetworkAttachmentAnnot]
					Expect(exists).Should(BeTrue())

					err := json.Unmarshal([]byte(networkSelectionElementsJSONUpdated), &networkSelectionElementsUpdated)
					Expect(err).Should(BeNil())

					return len(networkSelectionElementsUpdated) == 3
				}, timeout, interval).Should(BeTrue())

				Expect(strings.Count(networkSelectionElementsJSONUpdated, "\"name\":\"vip\"")).Should(Equal(2))
				Expect(strings.Count(networkSelectionElementsJSONUpdated, "\"vip\":\"20.0.0.1/32\"")).Should(Equal(1))
				Expect(strings.Count(networkSelectionElementsJSONUpdated, "\"vip\":\"2000::1/128\"")).Should(Equal(1))
			})

			When("Creating a proxy instance", func() {
				var (
					proxyPod                          *v1.Pod
					proxyNetworkSelectionElementsJSON string
				)

				BeforeEach(func() {
					networkSelectionElementsJSONBytes, err := json.Marshal(networkSelectionElements)
					Expect(err).Should(BeNil())
					proxyNetworkSelectionElementsJSON = string(networkSelectionElementsJSONBytes)

					proxyPod = &v1.Pod{
						ObjectMeta: metav1.ObjectMeta{
							Name:      "proxy",
							Namespace: namespace,
							Labels: map[string]string{
								v1alpha1.LabelServiceProxy:      serviceProxy,
								v1alpha1.LabelServiceProxyPlane: v1alpha1.ValueDataPlane,
							},
							Annotations: map[string]string{
								netdefv1.NetworkAttachmentAnnot: proxyNetworkSelectionElementsJSON,
								netdefv1.NetworkStatusAnnot:     fmt.Sprintf("[{\"name\":\"%s/%s\",\"interface\":\"net1\",\"ips\":[\"169.255.100.7\",\"fd00::7\"],\"mac\":\"72:24:87:fc:10:a9\",\"dns\":{}}]", namespace, networkName),
							},
						},
						Spec: v1.PodSpec{
							Containers: []v1.Container{
								{
									Name:  "test",
									Image: "abc",
								},
							},
						},
						Status: v1.PodStatus{
							Phase: v1.PodRunning,
							ContainerStatuses: []v1.ContainerStatus{
								{
									Name:  "test",
									Ready: true,
								},
							},
						},
					}
					Expect(k8sClient.Create(ctx, proxyPod)).Should(Succeed())
					proxyKey := types.NamespacedName{Name: proxyPod.Name, Namespace: namespace}
					Expect(k8sClient.Get(ctx, proxyKey, proxyPod)).Should(Succeed())
					proxyPod.Status.Phase = v1.PodRunning
					Expect(k8sClient.Status().Update(ctx, proxyPod)).Should(Succeed())
				})

				AfterEach(func() {
					Expect(k8sClient.Delete(ctx, proxyPod)).Should(Succeed())

					var networkSelectionElementsUpdated []netdefv1.NetworkSelectionElement
					var networkSelectionElementsJSONUpdated string
					Eventually(func() bool {
						Expect(k8sClient.Get(ctx, key, pod)).Should(Succeed())
						var exists bool
						networkSelectionElementsJSONUpdated, exists = pod.Annotations[netdefv1.NetworkAttachmentAnnot]
						Expect(exists).Should(BeTrue())
						err := json.Unmarshal([]byte(networkSelectionElementsJSONUpdated), &networkSelectionElementsUpdated)
						Expect(err).Should(BeNil())
						return len(networkSelectionElementsUpdated) == 3
					}, timeout, interval).Should(BeTrue())
				})

				It("has updated the network resources of the pod", func() {
					By("Checking the pod annotation")
					var networkSelectionElementsUpdated []netdefv1.NetworkSelectionElement
					var networkSelectionElementsJSONUpdated string

					Eventually(func() bool {
						Expect(k8sClient.Get(ctx, key, pod)).Should(Succeed())

						var exists bool
						networkSelectionElementsJSONUpdated, exists = pod.Annotations[netdefv1.NetworkAttachmentAnnot]
						Expect(exists).Should(BeTrue())

						err := json.Unmarshal([]byte(networkSelectionElementsJSONUpdated), &networkSelectionElementsUpdated)
						Expect(err).Should(BeNil())

						return len(networkSelectionElementsUpdated) == 5
					}, timeout, interval).Should(BeTrue())

					Expect(strings.Count(networkSelectionElementsJSONUpdated, "\"name\":\"vip\"")).Should(Equal(2))
					Expect(strings.Count(networkSelectionElementsJSONUpdated, "\"name\":\"policy-route\"")).Should(Equal(2))
					Expect(strings.Count(networkSelectionElementsJSONUpdated, "\"vip\":\"20.0.0.1/32\"")).Should(Equal(1))
					Expect(strings.Count(networkSelectionElementsJSONUpdated, "\"vip\":\"2000::1/128\"")).Should(Equal(1))
					Expect(strings.Count(networkSelectionElementsJSONUpdated, "\"gateways\":[\"169.255.100.7\"]")).Should(Equal(1))
					Expect(strings.Count(networkSelectionElementsJSONUpdated, "\"gateways\":[\"fd00::7\"]")).Should(Equal(1))
					Expect(strings.Count(networkSelectionElementsJSONUpdated, "\"policyRoutes\":[{\"srcPrefix\":\"20.0.0.1/32\"}]")).Should(Equal(1))
					Expect(strings.Count(networkSelectionElementsJSONUpdated, "\"policyRoutes\":[{\"srcPrefix\":\"2000::1/128\"}]")).Should(Equal(1))
				})

				When("Updating the flow with new VIPs", func() {
					BeforeEach(func() {
						vips := []string{"20.0.0.1/32", "2000::1/128", "40.0.0.1/32", "4000::1/128"}

						flowKey := types.NamespacedName{Name: flow.Name, Namespace: namespace}
						Expect(k8sClient.Get(ctx, flowKey, flow)).Should(Succeed())
						flow.Spec.DestinationCIDRs = vips
						Expect(k8sClient.Update(ctx, flow)).Should(Succeed())
					})

					AfterEach(func() {
						vips := []string{"20.0.0.1/32", "2000::1/128"}

						flowKey := types.NamespacedName{Name: flow.Name, Namespace: namespace}
						Expect(k8sClient.Get(ctx, flowKey, flow)).Should(Succeed())
						flow.Spec.DestinationCIDRs = vips
						Expect(k8sClient.Update(ctx, flow)).Should(Succeed())

						var networkSelectionElementsUpdated []netdefv1.NetworkSelectionElement
						var networkSelectionElementsJSONUpdated string
						Eventually(func() bool {
							Expect(k8sClient.Get(ctx, key, pod)).Should(Succeed())
							var exists bool
							networkSelectionElementsJSONUpdated, exists = pod.Annotations[netdefv1.NetworkAttachmentAnnot]
							Expect(exists).Should(BeTrue())
							err := json.Unmarshal([]byte(networkSelectionElementsJSONUpdated), &networkSelectionElementsUpdated)
							Expect(err).Should(BeNil())
							return len(networkSelectionElementsUpdated) == 5
						}, timeout, interval).Should(BeTrue())
					})

					It("has updated the network resources of the pod", func() {
						By("Checking the pod annotation")
						var networkSelectionElementsUpdated []netdefv1.NetworkSelectionElement
						var networkSelectionElementsJSONUpdated string

						Eventually(func() bool {
							Expect(k8sClient.Get(ctx, key, pod)).Should(Succeed())

							var exists bool
							networkSelectionElementsJSONUpdated, exists = pod.Annotations[netdefv1.NetworkAttachmentAnnot]
							Expect(exists).Should(BeTrue())

							err := json.Unmarshal([]byte(networkSelectionElementsJSONUpdated), &networkSelectionElementsUpdated)
							Expect(err).Should(BeNil())

							return len(networkSelectionElementsUpdated) == 7
						}, timeout, interval).Should(BeTrue())

						Expect(strings.Count(networkSelectionElementsJSONUpdated, "\"name\":\"vip\"")).Should(Equal(4))
						Expect(strings.Count(networkSelectionElementsJSONUpdated, "\"name\":\"policy-route\"")).Should(Equal(2))
						Expect(strings.Count(networkSelectionElementsJSONUpdated, "\"vip\":\"20.0.0.1/32\"")).Should(Equal(1))
						Expect(strings.Count(networkSelectionElementsJSONUpdated, "\"vip\":\"2000::1/128\"")).Should(Equal(1))
						Expect(strings.Count(networkSelectionElementsJSONUpdated, "\"vip\":\"40.0.0.1/32\"")).Should(Equal(1))
						Expect(strings.Count(networkSelectionElementsJSONUpdated, "\"vip\":\"4000::1/128\"")).Should(Equal(1))
						Expect(strings.Count(networkSelectionElementsJSONUpdated, "\"gateways\":[\"169.255.100.7\"]")).Should(Equal(1))
						Expect(strings.Count(networkSelectionElementsJSONUpdated, "\"gateways\":[\"fd00::7\"]")).Should(Equal(1))
						Expect(strings.Count(networkSelectionElementsJSONUpdated, "\"policyRoutes\":[{\"srcPrefix\":\"20.0.0.1/32\"},{\"srcPrefix\":\"40.0.0.1/32\"}]")).Should(Equal(1))
						Expect(strings.Count(networkSelectionElementsJSONUpdated, "\"policyRoutes\":[{\"srcPrefix\":\"2000::1/128\"},{\"srcPrefix\":\"4000::1/128\"}]")).Should(Equal(1))
					})
				})
			})
		})
	})
})

func deleteEndpointSliceForService(service *v1.Service) {
	ipv4EndpointSlice := &v1discovery.EndpointSlice{
		ObjectMeta: metav1.ObjectMeta{
			Name:      endpoint.GetEndpointSliceName(service, v1discovery.AddressTypeIPv4),
			Namespace: namespace,
		},
	}
	_ = k8sClient.Delete(ctx, ipv4EndpointSlice)
	ipv6EndpointSlice := &v1discovery.EndpointSlice{
		ObjectMeta: metav1.ObjectMeta{
			Name:      endpoint.GetEndpointSliceName(service, v1discovery.AddressTypeIPv6),
			Namespace: namespace,
		},
	}
	_ = k8sClient.Delete(ctx, ipv6EndpointSlice)
}
