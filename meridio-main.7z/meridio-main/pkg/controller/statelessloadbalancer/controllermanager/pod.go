/*
Copyright (c) 2023 Nordix Foundation

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package controllermanager

import (
	"context"
	"fmt"
	"net"

	"github.com/meridio-io/meridio/api/v1alpha1"
	"github.com/meridio-io/meridio/pkg/controller/statelessloadbalancer/network"
	v1 "k8s.io/api/core/v1"
	apierrors "k8s.io/apimachinery/pkg/api/errors"
	"k8s.io/apimachinery/pkg/runtime"
	ctrl "sigs.k8s.io/controller-runtime"
	"sigs.k8s.io/controller-runtime/pkg/client"
	"sigs.k8s.io/controller-runtime/pkg/handler"
)

// PodController reconcile the pods to add the network resources required
// by the service (network attachement, VIP, routes...).
type PodController struct {
	client.Client
	Scheme *runtime.Scheme
	// ServiceProxy is used to reconcile the pods with the
	// correct label.
	ServiceProxy string
	// GetIPsFunc is used when to get the IPs of the service proxies
	// so they can be used as gateways for source based routing.
	GetIPsFunc GetIPs
	// Networks is used when calling GetIPsFunc.
	// They represent the networks that will be reconciled.
	Networks []*v1alpha1.Network
}

// NewPodController is the constructor of the PodController struct.
func NewPodController(
	clnt client.Client,
	scheme *runtime.Scheme,
	serviceProxy string,
	networks []*v1alpha1.Network,
) *PodController {
	podController := &PodController{
		Client:       clnt,
		Scheme:       scheme,
		ServiceProxy: serviceProxy,
		Networks:     networks,
		GetIPsFunc:   network.GetIPs,
	}

	return podController
}

// Reconcile implements the reconciliation of the pod object.
//
// For more details, check Reconcile and its Result here:
// - https://pkg.go.dev/sigs.k8s.io/controller-runtime@v0.13.0/pkg/reconcile
func (pc *PodController) Reconcile(ctx context.Context, req ctrl.Request) (ctrl.Result, error) {
	pod := &v1.Pod{}

	err := pc.Get(ctx, req.NamespacedName, pod)
	if err != nil {
		if apierrors.IsNotFound(err) {
			return ctrl.Result{}, nil
		}

		return ctrl.Result{}, fmt.Errorf("failed to get the pod: %w", err)
	}

	if pod.Status.Phase != v1.PodRunning {
		return ctrl.Result{}, nil
	}

	services := &v1.ServiceList{}

	err = pc.List(ctx,
		services,
		client.MatchingLabels{
			v1alpha1.LabelServiceProxy: pc.ServiceProxy,
		})
	if err != nil {
		return ctrl.Result{}, fmt.Errorf("failed listing the services: %w", err)
	}

	// Filter services for this pod
	filteredServices := filterServices(pod, services.Items)

	vipV4, vipV6, err := pc.getVIPs(ctx, filteredServices)
	if err != nil {
		return ctrl.Result{}, err
	}

	gatewaysV4, gatewaysV6, err := pc.getGatewayIPs(ctx)
	if err != nil {
		return ctrl.Result{}, err
	}

	updatedPod, err := network.SetNetworkAttachmentAnnotation(
		pod,
		pc.ServiceProxy,
		vipV4,
		vipV6,
		gatewaysV4,
		gatewaysV6)
	if err != nil {
		return ctrl.Result{}, fmt.Errorf("failed to set network to the pod: %w", err)
	}

	if !network.EqualNetworkAttachmentAnnotation(pod, updatedPod) {
		err = pc.Update(ctx, updatedPod)
		if err != nil {
			return ctrl.Result{}, fmt.Errorf("failed to udpdate the pod: %w", err)
		}
	}

	return ctrl.Result{}, nil
}

// SetupWithManager sets up the controller with the Manager.
func (pc *PodController) SetupWithManager(mgr ctrl.Manager) error {
	err := ctrl.NewControllerManagedBy(mgr).
		For(&v1.Pod{}).
		// With EnqueueRequestsFromMapFunc, on an update the func is called twice
		// (1 time for old and 1 time for new object)
		Watches(&v1.Pod{}, handler.EnqueueRequestsFromMapFunc(pc.podEnqueue)).
		Watches(&v1.Service{}, handler.EnqueueRequestsFromMapFunc(pc.serviceEnqueue)).
		Watches(&v1alpha1.Flow{}, handler.EnqueueRequestsFromMapFunc(pc.flowEnqueue)).
		Complete(pc)
	if err != nil {
		return fmt.Errorf("failed to build the pod controller manager: %w", err)
	}

	return nil
}

func (pc *PodController) getVIPs(
	ctx context.Context,
	services []*v1.Service,
) ([]string, []string, error) {
	vips := []string{}

	for _, service := range services {
		flows := &v1alpha1.FlowList{}

		var matchingLabels client.MatchingLabels = map[string]string{
			v1alpha1.LabelService: service.GetName(),
		}

		err := pc.List(
			ctx,
			flows,
			matchingLabels,
		)
		if err != nil {
			return nil, nil, fmt.Errorf("failed listing the flows: %w", err)
		}

		for _, flow := range flows.Items {
			vips = append(vips, flow.Spec.DestinationCIDRs...)
		}
	}

	// remove duplicates and invalid VIPs
	vipMap := map[string]struct{}{}
	vipv4List := []string{}
	vipv6List := []string{}

	for _, vip := range vips {
		_, netIP, err := net.ParseCIDR(vip)
		if err != nil {
			continue
		}

		_, exists := vipMap[netIP.String()]
		if exists {
			continue
		}

		vipMap[netIP.String()] = struct{}{}

		if netIP.IP.To4() != nil {
			vipv4List = append(vipv4List, netIP.String())

			continue
		}

		vipv6List = append(vipv6List, netIP.String())
	}

	return vipv4List, vipv6List, nil
}

func (pc *PodController) getGatewayIPs(ctx context.Context) ([]string, []string, error) {
	pods := &v1.PodList{}

	err := pc.List(ctx,
		pods,
		client.MatchingLabels{
			v1alpha1.LabelServiceProxy:      pc.ServiceProxy,
			v1alpha1.LabelServiceProxyPlane: v1alpha1.ValueDataPlane,
		})
	if err != nil {
		return nil, nil, fmt.Errorf("failed listing the service proxy data-plane pods: %w", err)
	}

	ipv4 := []string{}
	ipv6 := []string{}

	for _, pod := range pods.Items {
		ips, _ := pc.GetIPsFunc(pod, pc.Networks) // todo: error

		// Get only IPs of correct IP family
		for _, ip := range ips {
			ipAddr := net.ParseIP(ip)

			if ipAddr == nil {
				continue
			}

			if ipAddr.To4() != nil {
				ipv4 = append(ipv4, ip)

				continue
			}

			ipv6 = append(ipv6, ip)
		}
	}

	return ipv4, ipv6, nil
}

func filterServices(
	pod *v1.Pod,
	services []v1.Service,
) []*v1.Service {
	res := []*v1.Service{}

items:
	for _, service := range services {
		for labelSelectorKey, labelSelectorValue := range service.Spec.Selector {
			value, exists := pod.GetLabels()[labelSelectorKey]
			if !exists || value != labelSelectorValue {
				continue items
			}
		}
		ns := service
		res = append(res, &ns)
	}

	return res
}
