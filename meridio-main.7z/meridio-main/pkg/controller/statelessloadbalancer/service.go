/*
Copyright (c) 2023 Nordix Foundation

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package statelessloadbalancer

import (
	"context"
	"fmt"

	"github.com/meridio-io/meridio/api/v1alpha1"
	"github.com/meridio-io/meridio/pkg/controller/statelessloadbalancer/endpoint"
	"github.com/meridio-io/meridio/pkg/log"
	v1 "k8s.io/api/core/v1"
	v1discovery "k8s.io/api/discovery/v1"
	apierrors "k8s.io/apimachinery/pkg/api/errors"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/types"
	ctrl "sigs.k8s.io/controller-runtime"
	"sigs.k8s.io/controller-runtime/pkg/client"
	"sigs.k8s.io/controller-runtime/pkg/handler"
)

type serviceManager interface {
	SetService(ctx context.Context, service *v1.Service) error
	DeleteService(ctx context.Context, serviceName string) error
	SetFlows(ctx context.Context, service *v1.Service, flows []v1alpha1.Flow) error
	SetEndpoints(ctx context.Context, service *v1.Service, endpoints []v1discovery.Endpoint) error
}

// ServiceController reconciles a Service object as a stateless load-balancer.
type ServiceController struct {
	client.Client
	Scheme *runtime.Scheme
	// ServiceProxy is used to reconcile the service with the
	// correct label.
	ServiceProxy   string
	ServiceManager serviceManager
}

// Reconcile implements the reconciliation of the Service object as a stateless load-balancer.
// This function is trigger by any change (create/update/delete) in any resource related
// to the object (Service, Flow, EndpointSlice).
//
// For more details, check Reconcile and its Result here:
// - https://pkg.go.dev/sigs.k8s.io/controller-runtime@v0.13.0/pkg/reconcile
func (sc *ServiceController) Reconcile(ctx context.Context, req ctrl.Request) (ctrl.Result, error) {
	// Get the service to reconcile and delete it if it could not be found.
	service := &v1.Service{}

	err := sc.Get(ctx, req.NamespacedName, service)
	if err != nil {
		if apierrors.IsNotFound(err) {
			// Delete Service from manager if not found
			err = sc.ServiceManager.DeleteService(ctx, req.Name)
			if err != nil {
				log.FromContextOrGlobal(ctx).Error(err, "failed to delete service")
			}

			return ctrl.Result{}, nil
		}

		return ctrl.Result{}, fmt.Errorf("failed to get the service: %w", err)
	}

	// The service proxy label does not exists or if it does not correspond to the one managed, so the
	// Service has to be deleted from manager.
	value, exists := service.GetLabels()[v1alpha1.LabelServiceProxy]
	if !exists || value != sc.ServiceProxy {
		err = sc.ServiceManager.DeleteService(ctx, req.Name)
		if err != nil {
			log.FromContextOrGlobal(ctx).Error(err, "failed to delete service")
		}

		return ctrl.Result{}, nil
	}

	// Instantiate the service
	err = sc.ServiceManager.SetService(ctx, service)
	if err != nil {
		return ctrl.Result{}, fmt.Errorf("failed to set service with service manager: %w", err)
	}

	err = sc.reconcileFlows(ctx, service)
	if err != nil {
		return ctrl.Result{}, err
	}

	err = sc.reconcileEndpoints(ctx, service)
	if err != nil {
		return ctrl.Result{}, err
	}

	return ctrl.Result{}, nil
}

func (sc *ServiceController) reconcileFlows(
	ctx context.Context,
	service *v1.Service,
) error {
	// Get and set flows corresponding to this service.
	var matchingLabels client.MatchingLabels = map[string]string{
		v1alpha1.LabelService: service.GetName(),
	}

	flows := &v1alpha1.FlowList{}

	err := sc.List(ctx,
		flows,
		matchingLabels)
	if err != nil {
		return fmt.Errorf("failed to list the flows: %w", err)
	}

	err = sc.ServiceManager.SetFlows(ctx, service, flows.Items)
	if err != nil {
		return fmt.Errorf("failed to set flows with service manager: %w", err)
	}

	return nil
}

func (sc *ServiceController) reconcileEndpoints(
	ctx context.Context,
	service *v1.Service,
) error {
	// Get and set endpoints corresponding to this service. The endpoints are splitted
	// into 2 endpointslices, 1 for ipv4 and the other for ipv6. They are then merged together.
	ipv4EndpointSlice := &v1discovery.EndpointSlice{}
	ipv6EndpointSlice := &v1discovery.EndpointSlice{}

	err := sc.Get(ctx, types.NamespacedName{
		Name:      endpoint.GetEndpointSliceName(service, v1discovery.AddressTypeIPv4),
		Namespace: service.GetNamespace(),
	}, ipv4EndpointSlice)
	if err != nil {
		if !apierrors.IsNotFound(err) {
			return fmt.Errorf("failed to get IPv4 EndpointSlice: %w", err)
		}
	}

	err = sc.Get(ctx, types.NamespacedName{
		Name:      endpoint.GetEndpointSliceName(service, v1discovery.AddressTypeIPv6),
		Namespace: service.GetNamespace(),
	}, ipv6EndpointSlice)
	if err != nil {
		if !apierrors.IsNotFound(err) {
			return fmt.Errorf("failed to get IPv6 EndpointSlice: %w", err)
		}
	}

	mergedEndpointSlices := endpoint.MergeEndpointSlices(ipv4EndpointSlice, ipv6EndpointSlice)
	mergedEndpoints := []v1discovery.Endpoint{}

	if mergedEndpointSlices != nil {
		mergedEndpoints = mergedEndpointSlices.Endpoints
	}

	err = sc.ServiceManager.SetEndpoints(ctx, service, mergedEndpoints)
	if err != nil {
		return fmt.Errorf("failed to set endpoints with service manager: %w", err)
	}

	return nil
}

// SetupWithManager sets up the controller with the Manager.
func (sc *ServiceController) SetupWithManager(mgr ctrl.Manager) error {
	err := ctrl.NewControllerManagedBy(mgr).
		For(&v1.Service{}).
		// With EnqueueRequestsFromMapFunc, on an update the func is called twice
		// (1 time for old and 1 time for new object)
		Watches(&v1alpha1.Flow{}, handler.EnqueueRequestsFromMapFunc(flowEnqueue)).
		Watches(&v1discovery.EndpointSlice{}, handler.EnqueueRequestsFromMapFunc(endpointSliceEnqueue)).
		Complete(sc)
	if err != nil {
		return fmt.Errorf("failed to build the service manager: %w", err)
	}

	return nil
}
