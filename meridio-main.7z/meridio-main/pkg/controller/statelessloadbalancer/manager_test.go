/*
Copyright (c) 2023 Nordix Foundation

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package statelessloadbalancer_test

import (
	"context"
	"sync"
	"testing"

	"github.com/meridio-io/meridio/api/v1alpha1"
	"github.com/meridio-io/meridio/pkg/controller/statelessloadbalancer"
	"github.com/meridio-io/meridio/pkg/controller/statelessloadbalancer/endpoint"
	"github.com/meridio-io/meridio/pkg/nfqlb"
	"github.com/stretchr/testify/assert"
	"go.uber.org/goleak"
	v1 "k8s.io/api/core/v1"
	v1discovery "k8s.io/api/discovery/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
)

func TestManager_Set_Delete_Service(t *testing.T) {
	t.Cleanup(func() { goleak.VerifyNone(t) })

	fakeLB := newFakeLoadBalancerInstance()
	serviceAName := "service-a"
	serviceA := &v1.Service{
		ObjectMeta: metav1.ObjectMeta{
			Name: serviceAName,
		},
		Spec: v1.ServiceSpec{
			ClusterIP: "None",
		},
	}

	manager := statelessloadbalancer.NewManager(fakeLB)

	err := manager.DeleteService(context.TODO(), serviceAName)
	assert.Nil(t, err)
	assert.NotContains(t, fakeLB.services, serviceAName)
	assert.Equal(t, len(fakeLB.services), 0)

	err = manager.SetService(context.TODO(), serviceA)
	assert.Nil(t, err)
	assert.Contains(t, fakeLB.services, serviceAName)
	assert.Equal(t, len(fakeLB.services), 1)

	err = manager.SetService(context.TODO(), serviceA)
	assert.Nil(t, err)
	assert.Contains(t, fakeLB.services, serviceAName)
	assert.Equal(t, len(fakeLB.services), 1)

	err = manager.DeleteService(context.TODO(), serviceAName)
	assert.Nil(t, err)
	assert.NotContains(t, fakeLB.services, serviceAName)
	assert.Equal(t, len(fakeLB.services), 0)
}

func TestManager_SetFlows(t *testing.T) {
	t.Cleanup(func() { goleak.VerifyNone(t) })

	fakeLB := newFakeLoadBalancerInstance()
	serviceAName := "service-a"
	serviceA := &v1.Service{
		ObjectMeta: metav1.ObjectMeta{
			Name: serviceAName,
		},
		Spec: v1.ServiceSpec{
			ClusterIP: "None",
		},
	}

	manager := statelessloadbalancer.NewManager(fakeLB)

	err := manager.SetService(context.TODO(), serviceA)
	assert.Nil(t, err)
	assert.Contains(t, fakeLB.services, serviceAName)
	assert.Equal(t, 1, len(fakeLB.services))

	service, exists := fakeLB.services[serviceAName]
	assert.True(t, exists)
	assert.NotNil(t, service)

	flows := []v1alpha1.Flow{
		{
			ObjectMeta: metav1.ObjectMeta{
				Name: "flow-1",
			},
		},
		{
			ObjectMeta: metav1.ObjectMeta{
				Name: "flow-2",
			},
		},
	}

	err = manager.SetFlows(context.TODO(), serviceA, flows)
	assert.Nil(t, err)
	assert.Contains(t, service.flows, "flow-1.service-a")
	assert.Contains(t, service.flows, "flow-2.service-a")
	assert.Equal(t, 2, len(service.flows))

	flows = []v1alpha1.Flow{
		{
			ObjectMeta: metav1.ObjectMeta{
				Name: "flow-1",
			},
		},
		{
			ObjectMeta: metav1.ObjectMeta{
				Name: "flow-3",
			},
		},
	}

	err = manager.SetFlows(context.TODO(), serviceA, flows)
	assert.Nil(t, err)
	assert.Contains(t, service.flows, "flow-1.service-a")
	assert.Contains(t, service.flows, "flow-3.service-a")
	assert.Equal(t, 2, len(service.flows))

	err = manager.SetFlows(context.TODO(), serviceA, []v1alpha1.Flow{})
	assert.Nil(t, err)
	assert.Equal(t, 0, len(service.flows))
}

func TestManager_SetEndpoints(t *testing.T) {
	t.Cleanup(func() { goleak.VerifyNone(t) })

	fakeLB := newFakeLoadBalancerInstance()
	serviceAName := "service-a"
	serviceA := &v1.Service{
		ObjectMeta: metav1.ObjectMeta{
			Name: serviceAName,
		},
		Spec: v1.ServiceSpec{
			ClusterIP: "None",
		},
	}

	manager := statelessloadbalancer.NewManager(fakeLB)

	err := manager.SetService(context.TODO(), serviceA)
	assert.Nil(t, err)
	assert.Contains(t, fakeLB.services, serviceAName)
	assert.Equal(t, 1, len(fakeLB.services))

	service, exists := fakeLB.services[serviceAName]
	assert.True(t, exists)
	assert.NotNil(t, service)

	readyTrue := true
	endpoints := []v1discovery.Endpoint{
		*endpoint.SetIdentifier(v1discovery.Endpoint{
			Addresses: []string{"172.16.1.1"},
			TargetRef: &v1.ObjectReference{
				UID: "a",
			},
			Conditions: v1discovery.EndpointConditions{
				Ready: &readyTrue,
			},
		}, 0),
		*endpoint.SetIdentifier(v1discovery.Endpoint{
			Addresses: []string{"172.16.1.2"},
			TargetRef: &v1.ObjectReference{
				UID: "b",
			},
			Conditions: v1discovery.EndpointConditions{
				Ready: &readyTrue,
			},
		}, 1),
	}

	err = manager.SetEndpoints(context.TODO(), serviceA, endpoints)
	assert.Nil(t, err)
	assert.Contains(t, service.targets, 0)
	assert.Contains(t, service.targets, 1)
	assert.Equal(t, 2, len(service.targets))

	// updated endpoint
	endpoints = []v1discovery.Endpoint{
		*endpoint.SetIdentifier(v1discovery.Endpoint{
			Addresses: []string{"172.16.1.1"},
			TargetRef: &v1.ObjectReference{
				UID: "a",
			},
			Conditions: v1discovery.EndpointConditions{
				Ready: &readyTrue,
			},
		}, 0),
		*endpoint.SetIdentifier(v1discovery.Endpoint{
			Addresses: []string{"172.16.1.3"},
			TargetRef: &v1.ObjectReference{
				UID: "b",
			},
			Conditions: v1discovery.EndpointConditions{
				Ready: &readyTrue,
			},
		}, 1),
	}

	err = manager.SetEndpoints(context.TODO(), serviceA, endpoints)
	assert.Nil(t, err)
	assert.Contains(t, service.targets, 0)
	assert.Contains(t, service.targets, 1)
	assert.Equal(t, 2, len(service.targets))

	// deleted endpoint
	endpoints = []v1discovery.Endpoint{
		*endpoint.SetIdentifier(v1discovery.Endpoint{
			Addresses: []string{"172.16.1.1"},
			TargetRef: &v1.ObjectReference{
				UID: "a",
			},
			Conditions: v1discovery.EndpointConditions{
				Ready: &readyTrue,
			},
		}, 0),
	}

	err = manager.SetEndpoints(context.TODO(), serviceA, endpoints)
	assert.Nil(t, err)
	assert.Contains(t, service.targets, 0)
	assert.Equal(t, 1, len(service.targets))

	// not ready endpoint
	readyFalse := false
	endpoints = []v1discovery.Endpoint{
		*endpoint.SetIdentifier(v1discovery.Endpoint{
			Addresses: []string{"172.16.1.1"},
			TargetRef: &v1.ObjectReference{
				UID: "a",
			},
			Conditions: v1discovery.EndpointConditions{
				Ready: &readyFalse,
			},
		}, 0),
	}

	err = manager.SetEndpoints(context.TODO(), serviceA, endpoints)
	assert.Nil(t, err)
	assert.Equal(t, 0, len(service.targets))
}

type fakeLoadBalancerInstance struct {
	services map[string]*fakeServiceInstance
	mu       sync.Mutex
}

func newFakeLoadBalancerInstance() *fakeLoadBalancerInstance {
	return &fakeLoadBalancerInstance{
		services: map[string]*fakeServiceInstance{},
	}
}

func (flbi *fakeLoadBalancerInstance) AddService(ctx context.Context, name string) (statelessloadbalancer.ServiceInstance, error) {
	flbi.mu.Lock()
	defer flbi.mu.Unlock()

	s := newFakeServiceInstance()
	flbi.services[name] = s

	return s, nil
}

func (flbi *fakeLoadBalancerInstance) DeleteService(ctx context.Context, name string) error {
	flbi.mu.Lock()
	defer flbi.mu.Unlock()

	delete(flbi.services, name)

	return nil
}

type fakeServiceInstance struct {
	flows   map[string]nfqlb.Flow
	targets map[int][]string
	mu      sync.Mutex
}

func newFakeServiceInstance() *fakeServiceInstance {
	return &fakeServiceInstance{
		flows:   map[string]nfqlb.Flow{},
		targets: map[int][]string{},
	}
}

func (nfsi *fakeServiceInstance) AddFlow(ctx context.Context, flowToAdd statelessloadbalancer.Flow) error {
	nfsi.mu.Lock()
	defer nfsi.mu.Unlock()

	nfsi.flows[flowToAdd.GetName()] = flowToAdd

	return nil
}

func (nfsi *fakeServiceInstance) DeleteFlow(ctx context.Context, flowToDelete statelessloadbalancer.Flow) error {
	nfsi.mu.Lock()
	defer nfsi.mu.Unlock()

	delete(nfsi.flows, flowToDelete.GetName())

	return nil
}

func (nfsi *fakeServiceInstance) AddTarget(ctx context.Context, ips []string, identifier int) error {
	nfsi.mu.Lock()
	defer nfsi.mu.Unlock()

	nfsi.targets[identifier] = ips

	return nil
}

func (nfsi *fakeServiceInstance) DeleteTarget(ctx context.Context, ips []string, identifier int) error {
	nfsi.mu.Lock()
	defer nfsi.mu.Unlock()

	delete(nfsi.targets, identifier)

	return nil
}
