/*
Copyright (c) 2023 Nordix Foundation

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

// Package bird represents a bird instance connecting to gateways via routing protocols
// to advertise VIP addresses.
package bird

import (
	"context"
	"errors"
	"fmt"
	"net"
	"os"
	"os/exec"
	"sync"

	"github.com/vishvananda/netlink"
)

// Bird represents the bird configuration.
type Bird struct {
	// filename (with path) to communicate with birdc
	CommunicationSocket string
	// configuration file (with path)
	ConfigFile      string
	BirdLogFileSize int
	// Add important bird log snippets to bird logs
	LogEnabled bool
	// Enable ECMP towards next-hops of available gateways
	ECMPEnabled   bool
	DropIfNoPeer  bool
	VRRPs         []string
	ExtInterface  string
	VIPs          []string
	Gateways      map[string]Gateway
	AdvertiseVIPs bool

	DefaultBGPHoldTime   int
	DefaultKernelTableID int
	DefaultLocalASN      uint32
	DefaultRemoteASN     uint32
	DefaultLocalPort     uint16
	DefaultRemotePort    uint16

	mu sync.Mutex
}

// New is the bird constructor.
func New() *Bird {
	bird := &Bird{
		DefaultBGPHoldTime:   defaultBGPHoldTime,
		DefaultKernelTableID: defaultKernelTableID,
		DefaultLocalASN:      defaultLocalASN,
		DefaultLocalPort:     defaultLocalPort,
		DefaultRemoteASN:     defaultRemoteASN,
		DefaultRemotePort:    defaultRemotePort,
		VRRPs:                []string{},
		VIPs:                 []string{},
		Gateways:             map[string]Gateway{},
	}

	return bird
}

// Run starts bird with the current bird configuration. Bird will be stopped
// when the context in parameter will be cancelled.
func (b *Bird) Run(ctx context.Context) error {
	err := b.writeConfig()
	if err != nil {
		return err
	}

	//nolint:gosec
	cmd := exec.CommandContext(
		ctx,
		"bird",
		"-d",
		"-c",
		b.ConfigFile,
		"-s",
		b.CommunicationSocket,
	)

	var errFinal error

	stdoutStderr, err := cmd.CombinedOutput()
	if err != nil && !errors.Is(err, context.Cause(ctx)) {
		errFinal = fmt.Errorf("failed starting bird ; %w; %s", err, stdoutStderr)
	}

	return errFinal
}

// Apply applies the configuration by writing it to the config file specified by path.
func (b *Bird) Apply(ctx context.Context) error {
	err := b.writeConfig()
	if err != nil {
		return err
	}

	arg := `"` + b.ConfigFile + `"`

	err = b.cmd(ctx, "configure", arg)
	if err != nil {
		return fmt.Errorf("create %v, err: %w", b.ConfigFile, err)
	}

	err = b.setPolicyRoutes(ctx, b.VIPs)
	if err != nil {
		return fmt.Errorf("failed to set the policy routes %v: %w", b.VIPs, err)
	}

	return nil
}

// ExportConfiguration exports the current bird configuration.
func (b *Bird) ExportConfiguration() string {
	b.mu.Lock()
	defer b.mu.Unlock()

	conf := ""

	conf += b.baseConfig()
	conf += b.vipsConfig()

	if len(b.VRRPs) > 0 {
		conf += b.vrrpsConfig()
	} else if b.DropIfNoPeer {
		conf += dropIfNoPeerConfig(true, true)
	}

	conf += b.kernelConfig("ipv4", true)
	conf += b.kernelConfig("ipv6", true)
	conf += b.gatewaysConfig()

	return conf
}

// SetVIPs sets the vips for the current bird configuration.
func (b *Bird) SetVIPs(vips []string) {
	b.mu.Lock()
	defer b.mu.Unlock()

	b.VIPs = vips
}

// SetGateway sets/updates a gateway for the current bird configuration.
func (b *Bird) SetGateway(gateway Gateway) {
	b.mu.Lock()
	defer b.mu.Unlock()

	b.Gateways[gateway.GetName()] = gateway
}

// DeleteGateway deletes a gateway for the current bird configuration.
func (b *Bird) DeleteGateway(name string) {
	b.mu.Lock()
	defer b.mu.Unlock()

	delete(b.Gateways, name)
}

func (b *Bird) writeConfig() error {
	file, err := os.Create(b.ConfigFile)
	if err != nil {
		return fmt.Errorf("create %v, err: %w", b.ConfigFile, err)
	}

	defer file.Close()

	conf := b.ExportConfiguration()

	_, err = file.WriteString(conf)
	if err != nil {
		return fmt.Errorf("write config to %v, err: %w", b.ConfigFile, err)
	}

	return nil
}

func (b *Bird) cmd(ctx context.Context, args ...string) error {
	args = append([]string{"-s", b.CommunicationSocket}, args...)
	cmd := exec.CommandContext(
		ctx,
		"birdc",
		args...,
	)

	stdoutStderr, err := cmd.CombinedOutput()
	if err != nil && !errors.Is(err, context.Cause(ctx)) {
		return fmt.Errorf("%w; %s", err, stdoutStderr)
	}

	return nil
}

func (b *Bird) setPolicyRoutes(_ context.Context, vips []string) error {
	rules, err := netlink.RuleListFiltered(netlink.FAMILY_ALL, &netlink.Rule{
		Table: b.DefaultKernelTableID,
	}, netlink.RT_FILTER_TABLE)
	if err != nil {
		return fmt.Errorf("failed to list rules: %w", err)
	}

	vipMap := map[string]*net.IPNet{}

	for _, vip := range vips {
		_, vipIPNet, err := net.ParseCIDR(vip)
		if err != nil {
			continue
		}

		vipMap[vipIPNet.String()] = vipIPNet
	}

	var errFinal error

	for _, rule := range rules {
		currentRule := rule

		_, exists := vipMap[rule.Src.String()]
		if !exists {
			err := netlink.RuleDel(&currentRule)
			if err != nil {
				errFinal = fmt.Errorf("failed to RuleDel ; %w; %w", err, errFinal)
			}

			continue
		}

		delete(vipMap, rule.Src.String())
	}

	for _, vipIPNet := range vipMap {
		rule := netlink.NewRule()
		rule.Priority = 100
		rule.Table = b.DefaultKernelTableID
		rule.Src = vipIPNet

		err := netlink.RuleAdd(rule)
		if err != nil {
			errFinal = fmt.Errorf("failed to RuleAdd ; %w; %w", err, errFinal)
		}
	}

	return errFinal
}
