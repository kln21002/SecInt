/*
Copyright (c) 2023 Nordix Foundation

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

//nolint:goconst
package bird

import (
	"fmt"
	"sort"
	"strconv"
	"strings"
	"syscall"

	"github.com/meridio-io/meridio/api/v1alpha1"
)

// baseConfig returns the common part of BIRD config.
func (b *Bird) baseConfig() string {
	conf := ""

	if b.BirdLogFileSize > 0 {
		conf += fmt.Sprintf("log \"%s\" %v \"%s\" { debug, trace, info, remote, warning, error, auth, fatal, bug };\n",
			logFile, b.BirdLogFileSize, logFileBackup)
	}

	if b.LogEnabled {
		conf += "log stderr all;\n"
	} else {
		conf += "log stderr { error, fatal, bug, warning };\n"
	}

	conf += "\n"
	conf += baseConfig()
	conf += "\n"

	// BGP protocol template
	// BGP protocol templates (IPv4 and IPv6)
	// Separate templates ensure that multi-protocol extension capability is
	// only advertised for a single protocol when a Gateway is created from
	// any of the templates.
	bgpTemplate := func(family int, name string) string {
		template := fmt.Sprintf("template bgp %s {\n", name)
		template += "\tdebug {events, states, interfaces};\n"
		template += "\tdirect;\n"
		template += "\thold time " + strconv.Itoa(b.DefaultBGPHoldTime) + ";\n"
		template += "\tbfd off;\n" // can be enabled per protocol session i.e. per gateway
		template += "\tgraceful restart off;\n"
		template += "\tsetkey off;\n"

		if family == syscall.AF_INET {
			template += "\tipv4 {\n"
		} else {
			template += "\tipv6 {\n"
		}

		template += "\t\timport none;\n"
		template += "\t\texport none;\n"
		// advertise this router as next-hop
		template += "\t\tnext hop self;\n"
		template += "\t};\n"
		template += "}\n"

		return template
	}
	conf += bgpTemplate(syscall.AF_INET, bgpTemplateIPv4)
	conf += "\n"
	conf += bgpTemplate(syscall.AF_INET6, bgpTemplateIPv6)
	conf += "\n"

	return conf
}

func baseConfig() string {
	conf := ""

	// The Device protocol is not a real routing protocol. It does not generate any
	// routes and it only serves as a module for getting information about network
	// interfaces from the kernel. It is necessary in almost any configuration.
	conf += "protocol device {\n"
	conf += "}\n"
	conf += "\n"

	// Filter matching default IPv4, IPv6 routes
	conf += "filter default_rt {\n"
	conf += "\tif ( net ~ [ 0.0.0.0/0 ] ) then accept;\n"
	conf += "\tif ( net ~ [ 0::/0 ] ) then accept;\n"
	conf += "\telse reject;\n"
	conf += "}\n"
	conf += "\n"

	// filter telling what BGP nFE can send to BGP GW peers
	// hint: only the VIP addresses
	//
	// Note: Since VIPs are configured as static routes in BIRD, there's
	// no point maintaining complex v4/v6 filters. Such filters would require
	// updates upon changes related to VIP addresses anyways...
	conf += "filter cluster_e_static {\n"
	conf += "\tif ( net ~ [ 0.0.0.0/0 ] ) then reject;\n"
	conf += "\tif ( net ~ [ 0::/0 ] ) then reject;\n"
	conf += "\tif source = RTS_STATIC && dest != RTD_BLACKHOLE then accept;\n"
	conf += "\telse reject;\n"
	conf += "}\n"

	return conf
}

// kernelConfig creates kernel proto part of the BIRD config.
//
// Kernel proto is used to sync default routes learnt from BGP peer into
// local network stack (to the specified routing table).
// Note: No need to sync learnt default routes to stack, in case there are
// no VIPs configured for the particular IP family.
//
//nolint:revive // todo: fix flag-parameter
func (b *Bird) kernelConfig(ipFamily string, enabled bool) string {
	conf := ""

	eFilter := "none"
	if enabled {
		eFilter = "filter default_rt"
	}

	conf += "protocol kernel {\n"
	conf += "\t" + ipFamily + " {\n"
	conf += "\t\timport none;\n"
	conf += "\t\texport " + eFilter + ";\n"
	conf += "\t};\n"
	conf += "\tkernel table " + strconv.FormatInt(int64(b.DefaultKernelTableID), 10) + ";\n"

	if b.ECMPEnabled {
		conf += "\tmerge paths on;\n"
	}

	if b.DropIfNoPeer {
		// Setting the metric for the default blackhole route must be supported,
		// which requires the kernel proto's metric to be set to zero.
		//
		// "Metric 0 has a special meaning of undefined metric, in which either OS default is used,
		// or per-route metric can be set using krt_metric attribute. Default: 32. "
		conf += "\tmetric 0;\n"
	}

	conf += "}\n"
	conf += "\n"

	return conf
}

// dropIfNoPeerConfig create static default blackhole routes, that will be synced to the routing table
// used by VIP src routing rules.
//
// The aim is to drop packets from VIP src addresses when no external gateways are
// available, when configured accordingly. (So that the POD's default route installed
// for the prrimary network couldn't interfere.)
// XXX: Default route of the primary network could still interfere e.g. when a VIP is
// removed; there can be a transient period of time when FE still gets outbound packets
// with the very VIP as src addr.
//
// Notes:
// - These routes are configured with the highest (linux) metric (-> lowest prio)
// - BIRD 2.0.7 has a strange behaviour that differs between IPv4 and IPv6:
//   - IPv4: - seemingly all the default routes are installed to the OS kernel routing
//     table including e.g. default blackhole routes with lower preference
//   - BIRD fails to remove all the BGP related routes when there's a BIRD
//     managed blackhole route for the same destination as well
//   - IPv6: default route with the highest preference gets installed to OS kernel routing table
//
//nolint:revive // todo: fix flag-parameter
func dropIfNoPeerConfig(hasVIP4 bool, hasVIP6 bool) string {
	conf := ""

	if hasVIP4 {
		conf += "protocol static BH4 {\n"
		conf += "\tipv4 { preference 0; };\n"
		conf += "\troute 0.0.0.0/0 blackhole {\n"
		conf += "\t\tkrt_metric=4294967295;\n"
		conf += "\t};\n"
		conf += "}\n"
		conf += "\n"
	}

	if hasVIP6 {
		conf += "protocol static BH6 {\n"
		conf += "\tipv6 { preference 0; };\n"
		conf += "\troute 0::/0 blackhole {\n"
		conf += "\t\tkrt_metric=4294967295;\n"
		conf += "\t};\n"
		conf += "}\n"
		conf += "\n"
	}

	return conf
}

// vrrpsConfig, BIRD managed default static routes substituting other routing protocol related
// external routes.
func (b *Bird) vrrpsConfig() string {
	conf := ""

	for _, ip := range b.VRRPs {
		if isIPv4(ip) {
			conf += "protocol static {\n"
			conf += "\tipv4;\n"
			conf += "\troute 0.0.0.0/0 via " + strings.Split(ip, "/")[0] + "%'" + b.ExtInterface + "' onlink;\n"
			conf += "}\n"
			conf += "\n"
		} else if isIPv6(ip) {
			conf += "protocol static {\n"
			conf += "\tipv6;\n"
			conf += "\troute 0::/0 via " + strings.Split(ip, "/")[0] + "%'" + b.ExtInterface + "' onlink;\n"
			conf += "}\n"
			conf += "\n"
		}
	}

	return conf
}

// vipsConfig create static routes for VIP addresses in BIRD config.
//
// VIP addresses are configured as static routes in BIRD. They are
// only advertised to BGP peers and not synced into local network stack.
//
// Note: VIPs shall be advertised only if external connectivity is OK.
func (b *Bird) vipsConfig() string {
	conf := ""
	ipv4, ipv6 := "", ""

	for _, vip := range b.VIPs {
		if isIPv6CIDR(vip) {
			// IPv6
			// v6 += "\troute " + vip + " blackhole;\n"
			ipv6 += "\troute " + vip + " via \"lo\";\n"
		} else if isIPv4CIDR(vip) {
			// IPv4
			// v4 += "\troute " + vip + " blackhole;\n"
			ipv4 += "\troute " + vip + " via \"lo\";\n"
		}
	}

	if ipv4 != "" {
		if b.AdvertiseVIPs {
			conf += "protocol static VIP4 {\n"
			conf += "\tipv4 { preference 110; };\n"
			conf += ipv4
			conf += "}\n"
			conf += "\n"
		}
	}

	if ipv6 != "" {
		if b.AdvertiseVIPs {
			conf += "protocol static VIP6 {\n"
			conf += "\tipv6 { preference 110; };\n"
			conf += ipv6
			conf += "}\n"
			conf += "\n"
		}
	}

	return conf
}

// writeConfigGW creates BGP proto part of the BIRD config for each gateway to connect with them
//
// BGP is restricted to the external interface.
// Only VIP related routes are announced to peer, and only default routes are accepted.
//
// Note: When VRRP IPs are configured, BGP sessions won't import any routes from external
// peers, as external routes are going to be taken care of by static default routes (VRRP IPs
// as next hops).
func (b *Bird) gatewaysConfig() string {
	conf := ""

	// Ordering the gateways to avoid flaky tests
	// https://bitfieldconsulting.com/golang/map-iteration
	gateways := []string{}

	for gateway := range b.Gateways {
		gateways = append(gateways, gateway)
	}

	sort.Strings(gateways)

	for _, gateway := range gateways {
		conf += b.gatewayConfig(b.Gateways[gateway])
	}

	// Have to add BFD protocol so that BGP or STATIC could ask for a BFD session
	// Note: BIRD 2.0.8 does not support per peer BFD attributes for Static protocol,
	// thus only 1 BFD configuration per interface is possible
	conf += "protocol bfd 'NBR-BFD' {\n"
	conf += fmt.Sprintf("\tinterface \"%v\" {\n", b.ExtInterface)
	conf += bfdConfig(&emptyBFD{})
	conf += "\t};\n"
	conf += "}\n"

	return conf
}

func (b *Bird) gatewayConfig(gateway Gateway) string {
	conf := ""
	name := `NBR-` + gateway.GetName()
	ipFamily := "ipv4"

	if isIPv6(gateway.GetAddress()) {
		ipFamily = "ipv6"
	}

	switch gateway.GetProtocol() {
	case v1alpha1.BGP:
		bgpSpec := gateway.GetBgpSpec()
		if bgpSpec == nil {
			return conf
		}

		conf += b.bgpConfig(name, ipFamily, gateway.GetAddress(), bgpSpec)
	case v1alpha1.Static:
		// todo: static
		return conf
	}

	return conf
}

func (b *Bird) bgpConfig(name string, ipFamily string, address string, bgpSpec BgpSpec) string {
	conf := ""

	ipv := fmt.Sprintf("\t%v {\n", ipFamily)

	if len(b.VRRPs) > 0 {
		ipv += "\t\timport none;\n"
	} else {
		ipv += "\t\timport filter default_rt;\n"
	}

	ipv += "\t\texport filter cluster_e_static;\n"
	ipv += "\t};\n"

	bgpTemplate := bgpTemplateIPv4
	if ipFamily == "ipv6" {
		bgpTemplate = bgpTemplateIPv6
	}

	conf += fmt.Sprintf("protocol bgp '%v' from %s {\n", name, bgpTemplate)
	conf += fmt.Sprintf("\tinterface \"%v\";\n", b.ExtInterface)

	localASN := b.DefaultLocalASN
	localPort := b.DefaultLocalPort
	remoteASN := b.DefaultRemoteASN
	remotePort := b.DefaultRemotePort

	if bgpSpec.GetLocalASN() != nil {
		localASN = *bgpSpec.GetLocalASN()
	}

	if bgpSpec.GetLocalPort() != nil {
		localPort = *bgpSpec.GetLocalPort()
	}

	if bgpSpec.GetRemoteASN() != nil {
		remoteASN = *bgpSpec.GetRemoteASN()
	}

	if bgpSpec.GetRemotePort() != nil {
		remotePort = *bgpSpec.GetRemotePort()
	}

	conf += fmt.Sprintf("\tlocal port %v as %v;\n", localPort, localASN)
	conf += fmt.Sprintf("\tneighbor %v port %v as %v;\n", address, remotePort, remoteASN)

	bfdSpec := bgpSpec.GetBfdSpec()
	if bfdSpec != nil {
		conf += "\tbfd {\n"
		conf += bfdConfig(bfdSpec)
		conf += "\t};\n"
	}

	// todo: holdtime
	// holdTime := bgpSpec.GetHoldTime()
	// if holdTime != nil {
	// 	conf += fmt.Sprintf("\thold time %v;\n", *holdTime)
	// }

	conf += ipv
	conf += "}\n"
	conf += "\n"

	return conf
}

func bfdConfig(bfdSpec BfdSpec) string {
	conf := ""
	prefix := "\t\t"

	if bfdSpec.GetMinRx() != "" {
		conf += fmt.Sprintf("%smin rx interval %v;\n", prefix, bfdSpec.GetMinRx())
	}

	if bfdSpec.GetMinTx() != "" {
		conf += fmt.Sprintf("%vmin tx interval %v;\n", prefix, bfdSpec.GetMinTx())
	}

	if bfdSpec.GetMultiplier() != nil {
		conf += fmt.Sprintf("%vmultiplier %v;\n", prefix, *bfdSpec.GetMultiplier())
	}

	return conf
}

type emptyBFD struct{}

func (*emptyBFD) GetSwitch() *bool {
	return nil
}

func (*emptyBFD) GetMinTx() string {
	return ""
}

func (*emptyBFD) GetMinRx() string {
	return ""
}

func (*emptyBFD) GetMultiplier() *uint16 {
	return nil
}
