/*
Copyright (c) 2023 Nordix Foundation

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package bird_test

import (
	"testing"

	"github.com/meridio-io/meridio/api/v1alpha1"
	"github.com/meridio-io/meridio/pkg/bird"
)

var bfd = &bfdSpec{
	sw:         newBool(true),
	minTx:      "300ms",
	minRx:      "300ms",
	multiplier: newUint16(5),
}

var bgp = &bgpSpec{
	remotePort: newUint16(10179),
	localPort:  newUint16(10179),
	remoteASN:  newUint32(4248829953),
	localASN:   newUint32(8103),
	holdTime:   "24s",
	bfd:        bfd,
}

var gatewayIPv4BGPBFD = &gateway{
	name:     "gateway-v4-a-1",
	address:  "169.254.100.150",
	protocol: v1alpha1.BGP,
	bgp:      bgp,
}

var gatewayIPv6BGPBFD = &gateway{
	name:     "gateway-v6-a-1",
	address:  "100:100::150",
	protocol: v1alpha1.BGP,
	bgp:      bgp,
}

func TestBird_ExportConfiguration(t *testing.T) {
	type fields struct {
		ECMPEnabled   bool
		DropIfNoPeer  bool
		VRRPs         []string
		ExtInterface  string
		VIPs          []string
		Gateways      map[string]bird.Gateway
		AdvertiseVIPs bool
	}
	tests := []struct {
		name   string
		fields fields
		want   string
	}{
		{
			name: "empty",
			fields: fields{
				ECMPEnabled:   false,
				DropIfNoPeer:  false,
				VRRPs:         []string{},
				ExtInterface:  "ext-vlan",
				VIPs:          []string{},
				Gateways:      map[string]bird.Gateway{},
				AdvertiseVIPs: false,
			},
			want: emptyConfig,
		},
		{
			name: "ipv4 and ipv6 VIPs",
			fields: fields{
				ECMPEnabled:   false,
				DropIfNoPeer:  false,
				VRRPs:         []string{},
				ExtInterface:  "ext-vlan",
				VIPs:          []string{"20.0.0.1/32", "2000::1/128"},
				Gateways:      map[string]bird.Gateway{},
				AdvertiseVIPs: true,
			},
			want: ipv4AndIPv6VIPsConfig,
		},
		{
			name: "ipv4 and ipv6 bgp bfd",
			fields: fields{
				ECMPEnabled:  false,
				DropIfNoPeer: false,
				VRRPs:        []string{},
				ExtInterface: "ext-vlan",
				VIPs:         []string{},
				Gateways: map[string]bird.Gateway{
					gatewayIPv4BGPBFD.GetName(): gatewayIPv4BGPBFD,
					gatewayIPv6BGPBFD.GetName(): gatewayIPv6BGPBFD,
				},
				AdvertiseVIPs: true,
			},
			want: ipv4AndIPv6BGPBFD,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			b := bird.New()
			b.ConfigFile = "./bird.conf"
			b.ECMPEnabled = tt.fields.ECMPEnabled
			b.DropIfNoPeer = tt.fields.DropIfNoPeer
			b.VRRPs = tt.fields.VRRPs
			b.ExtInterface = tt.fields.ExtInterface
			b.VIPs = tt.fields.VIPs
			b.Gateways = tt.fields.Gateways
			b.AdvertiseVIPs = tt.fields.AdvertiseVIPs
			if got := b.ExportConfiguration(); got != tt.want {
				// b.Apply(context.TODO())
				t.Errorf("Bird.ExportConfiguration() = %v, want %v", got, tt.want)
			}
		})
	}
}

var emptyConfig = `log stderr { error, fatal, bug, warning };

protocol device {
}

filter default_rt {
	if ( net ~ [ 0.0.0.0/0 ] ) then accept;
	if ( net ~ [ 0::/0 ] ) then accept;
	else reject;
}

filter cluster_e_static {
	if ( net ~ [ 0.0.0.0/0 ] ) then reject;
	if ( net ~ [ 0::/0 ] ) then reject;
	if source = RTS_STATIC && dest != RTD_BLACKHOLE then accept;
	else reject;
}

template bgp LINK4 {
	debug {events, states, interfaces};
	direct;
	hold time 3;
	bfd off;
	graceful restart off;
	setkey off;
	ipv4 {
		import none;
		export none;
		next hop self;
	};
}

template bgp LINK6 {
	debug {events, states, interfaces};
	direct;
	hold time 3;
	bfd off;
	graceful restart off;
	setkey off;
	ipv6 {
		import none;
		export none;
		next hop self;
	};
}

protocol kernel {
	ipv4 {
		import none;
		export filter default_rt;
	};
	kernel table 4096;
}

protocol kernel {
	ipv6 {
		import none;
		export filter default_rt;
	};
	kernel table 4096;
}

protocol bfd 'NBR-BFD' {
	interface "ext-vlan" {
	};
}
`

var ipv4AndIPv6VIPsConfig = `log stderr { error, fatal, bug, warning };

protocol device {
}

filter default_rt {
	if ( net ~ [ 0.0.0.0/0 ] ) then accept;
	if ( net ~ [ 0::/0 ] ) then accept;
	else reject;
}

filter cluster_e_static {
	if ( net ~ [ 0.0.0.0/0 ] ) then reject;
	if ( net ~ [ 0::/0 ] ) then reject;
	if source = RTS_STATIC && dest != RTD_BLACKHOLE then accept;
	else reject;
}

template bgp LINK4 {
	debug {events, states, interfaces};
	direct;
	hold time 3;
	bfd off;
	graceful restart off;
	setkey off;
	ipv4 {
		import none;
		export none;
		next hop self;
	};
}

template bgp LINK6 {
	debug {events, states, interfaces};
	direct;
	hold time 3;
	bfd off;
	graceful restart off;
	setkey off;
	ipv6 {
		import none;
		export none;
		next hop self;
	};
}

protocol static VIP4 {
	ipv4 { preference 110; };
	route 20.0.0.1/32 via "lo";
}

protocol static VIP6 {
	ipv6 { preference 110; };
	route 2000::1/128 via "lo";
}

protocol kernel {
	ipv4 {
		import none;
		export filter default_rt;
	};
	kernel table 4096;
}

protocol kernel {
	ipv6 {
		import none;
		export filter default_rt;
	};
	kernel table 4096;
}

protocol bfd 'NBR-BFD' {
	interface "ext-vlan" {
	};
}
`

var ipv4AndIPv6BGPBFD = `log stderr { error, fatal, bug, warning };

protocol device {
}

filter default_rt {
	if ( net ~ [ 0.0.0.0/0 ] ) then accept;
	if ( net ~ [ 0::/0 ] ) then accept;
	else reject;
}

filter cluster_e_static {
	if ( net ~ [ 0.0.0.0/0 ] ) then reject;
	if ( net ~ [ 0::/0 ] ) then reject;
	if source = RTS_STATIC && dest != RTD_BLACKHOLE then accept;
	else reject;
}

template bgp LINK4 {
	debug {events, states, interfaces};
	direct;
	hold time 3;
	bfd off;
	graceful restart off;
	setkey off;
	ipv4 {
		import none;
		export none;
		next hop self;
	};
}

template bgp LINK6 {
	debug {events, states, interfaces};
	direct;
	hold time 3;
	bfd off;
	graceful restart off;
	setkey off;
	ipv6 {
		import none;
		export none;
		next hop self;
	};
}

protocol kernel {
	ipv4 {
		import none;
		export filter default_rt;
	};
	kernel table 4096;
}

protocol kernel {
	ipv6 {
		import none;
		export filter default_rt;
	};
	kernel table 4096;
}

protocol bgp 'NBR-gateway-v4-a-1' from LINK4 {
	interface "ext-vlan";
	local port 10179 as 8103;
	neighbor 169.254.100.150 port 10179 as 4248829953;
	bfd {
		min rx interval 300ms;
		min tx interval 300ms;
		multiplier 5;
	};
	ipv4 {
		import filter default_rt;
		export filter cluster_e_static;
	};
}

protocol bgp 'NBR-gateway-v6-a-1' from LINK6 {
	interface "ext-vlan";
	local port 10179 as 8103;
	neighbor 100:100::150 port 10179 as 4248829953;
	bfd {
		min rx interval 300ms;
		min tx interval 300ms;
		multiplier 5;
	};
	ipv6 {
		import filter default_rt;
		export filter cluster_e_static;
	};
}

protocol bfd 'NBR-BFD' {
	interface "ext-vlan" {
	};
}
`

type gateway struct {
	name     string
	address  string
	protocol v1alpha1.RoutingProtocol
	bgp      *bgpSpec
	static   *staticSpec
}

func (gw *gateway) GetName() string {
	return gw.name
}

func (gw *gateway) GetAddress() string {
	return gw.address
}

func (gw *gateway) GetProtocol() v1alpha1.RoutingProtocol {
	return gw.protocol
}

func (gw *gateway) GetBgpSpec() bird.BgpSpec {
	return gw.bgp
}

func (gw *gateway) GetStatic() bird.StaticSpec {
	return gw.static
}

type bgpSpec struct {
	remoteASN  *uint32
	localASN   *uint32
	bfd        *bfdSpec
	holdTime   string
	remotePort *uint16
	localPort  *uint16
}

func (bgps *bgpSpec) GetRemoteASN() *uint32 {
	return bgps.remoteASN
}

func (bgps *bgpSpec) GetLocalASN() *uint32 {
	return bgps.localASN
}

func (bgps *bgpSpec) GetBfdSpec() bird.BfdSpec {
	return bgps.bfd
}

func (bgps *bgpSpec) GetHoldTime() string {
	return bgps.holdTime
}

func (bgps *bgpSpec) GetRemotePort() *uint16 {
	return bgps.remotePort
}

func (bgps *bgpSpec) GetLocalPort() *uint16 {
	return bgps.localPort
}

type staticSpec struct {
	bfd *bfdSpec
}

func (ss *staticSpec) GetBfdSpec() bird.BfdSpec {
	return ss.bfd
}

type bfdSpec struct {
	sw         *bool
	minTx      string
	minRx      string
	multiplier *uint16
}

func (bfds *bfdSpec) GetSwitch() *bool {
	return bfds.sw
}

func (bfds *bfdSpec) GetMinTx() string {
	return bfds.minTx
}

func (bfds *bfdSpec) GetMinRx() string {
	return bfds.minRx
}

func (bfds *bfdSpec) GetMultiplier() *uint16 {
	return bfds.multiplier
}

func newBool(val bool) *bool {
	return &val
}

func newUint16(val uint16) *uint16 {
	return &val
}

func newUint32(val uint32) *uint32 {
	return &val
}
