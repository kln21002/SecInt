/*
Copyright (c) 2023 Nordix Foundation

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package e2e_test

import (
	"flag"
	"log"
	"os"
	"strings"
	"testing"

	. "github.com/onsi/ginkgo/v2"
	. "github.com/onsi/gomega"
	"gopkg.in/yaml.v2"
)

var (
	configurationPath string

	config *Configuration
)

func init() {
	flag.StringVar(&configurationPath, "configuration", "", "Path of the configuration for the environment")
}

func TestE2e(t *testing.T) {
	if testing.Short() {
		t.Skip()
	}

	config = &Configuration{}

	yamlFile, err := os.ReadFile(configurationPath)
	if err != nil {
		log.Fatalf("failed to read configuration file (%v): %v", configurationPath, err)
	}

	err = yaml.Unmarshal(yamlFile, config)
	if err != nil {
		log.Fatalf("failed to unmarshal configuration file (%v): %v", configurationPath, err)
	}

	RegisterFailHandler(onFailure)
	suiteConfig, reporterConfig := GinkgoConfiguration()
	suiteConfig.SkipStrings = cleanSlice(append(suiteConfig.SkipStrings, config.Tests.Skip...))
	suiteConfig.FocusStrings = cleanSlice(append(suiteConfig.FocusStrings, config.Tests.Focus...))
	RunSpecs(t, "E2e Suite", suiteConfig, reporterConfig)
}

func onFailure(message string, callerSkip ...int) {
	Fail(message, callerSkip...)
}

// removes spaces in entries and removes empty entries
func cleanSlice(items []string) []string {
	res := []string{}
	for _, item := range items {
		i := strings.ReplaceAll(item, " ", "")
		if i == "" {
			continue
		}
		res = append(res, i)
	}
	return res
}

var _ = BeforeSuite(func() {
	err := config.Tests.Exec("global/init")
	Expect(err).ToNot(HaveOccurred())
})

var _ = AfterSuite(func() {
	err := config.Tests.Exec("global/end")
	Expect(err).ToNot(HaveOccurred())
})
