/*
Copyright (c) 2023 Nordix Foundation

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package e2e_test

import (
	"bytes"
	"fmt"
	osexec "os/exec"
	"path/filepath"
	"strings"
	"time"
)

// Configuration represent the full e2e suite configuration.
type Configuration struct {
	// Acceptance represents the setting for the tests to pass or fail.
	Acceptance *Acceptance `yaml:"acceptance,omitempty"`
	// Tests represents the parameters to run the e2e tests.
	Tests *Tests `yaml:"tests,omitempty"`
}

// Acceptance represents the setting for the tests to pass or fail.
type Acceptance struct {
	// IgnoreLostConnections to true to ignore the lost connections when running the traffic tests.
	IgnoreLostConnections bool `yaml:"ignoreLostConnections,omitempty"`
}

// Tests represents the parameters to run the e2e tests.
type Tests struct {
	// IP Family to test on.
	IPFamily string `yaml:"ipFamily,omitempty"`
	// Path to the script.
	ScriptsPath string `yaml:"scriptsPath,omitempty"`
	// List of test to skip.
	Skip []string `yaml:"skip,omitempty"`
	// List of test to focus on.
	Focus []string `yaml:"focus,omitempty"`
	// Timeout of a test.
	Timeout time.Duration `yaml:"timeout,omitempty"`
	// Prints the output of the scripts.
	PrintScriptOutput bool `yaml:"printScriptOutput,omitempty"`
}

// Exec executes the script passed as parameter (name) with the arguments.
func (t *Tests) Exec(name string, args ...string) error {
	cmdArgs := []string{"-c", filepath.Join(t.ScriptsPath, name)}
	cmdArgs = append(cmdArgs, args...)

	cmd := osexec.Command("/bin/sh", cmdArgs...)

	var stdout bytes.Buffer

	var stderr bytes.Buffer

	cmd.Stdout = &stdout
	cmd.Stderr = &stderr

	err := cmd.Run()
	if err != nil {
		return fmt.Errorf("%w; %s", err, stderr.String())
	}

	if t.PrintScriptOutput {
		fmt.Print(cmd.Stdout)
	}

	return nil
}

// IPv4Enabled returns true if the ip family parameter is set to ipv4 or dualstack.
func (t *Tests) IPv4Enabled() bool {
	return strings.ToLower(t.IPFamily) == "ipv4" || strings.ToLower(t.IPFamily) == "dualstack"
}

// IPv4Enabled returns true if the ip family parameter is set to ipv6 or dualstack.
func (t *Tests) IPv6Enabled() bool {
	return strings.ToLower(t.IPFamily) == "ipv6" || strings.ToLower(t.IPFamily) == "dualstack"
}
