# Demo

## Installation 

Kubernetes
```
kind create cluster --config docs/demo/kind.yaml
```

Gateways
```
curl -sfL https://raw.githubusercontent.com/Nordix/Meridio/master/docs/demo/scripts/kind/external-host.sh | bash -
```

Multus
```
helm install multus ./deployments/Multus
```

Meridio
```
helm install meridio-crds ./deployments/Meridio-CRDs
helm install meridio ./deployments/Meridio
```

Network
```
kubectl apply -f ./examples/networks.yaml
```

Targets
```
kubectl apply -f ./examples/deployment.yaml
```

Meridio custom resources
```
kubectl apply -f ./examples/proxy.yaml
kubectl apply -f ./examples/gateways.yaml
kubectl apply -f ./examples/ns-a.yaml
kubectl apply -f ./examples/flow-1.yaml
```

## traffic

```
docker exec -it trench-a mconnect -address 20.0.0.1:4000 -nconn 400 -timeout 2s
```
