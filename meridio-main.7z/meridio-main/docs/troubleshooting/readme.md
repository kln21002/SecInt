# Troubleshooting

List the endpoints
```
kubectl get endpointslice <Network-Service>-ipv4
kubectl get endpointslice <Network-Service>-ipv6
```
