# Stateless Load Balancer Controller Manager

### Pod controller

The stateless load balancer controller manager reconciles the pods by checking which network services are selecting the pod. Once found, the list of destination IP (VIP) is gathered via the list of flows selected in the network services. The list of IP belonging to the service proxies is also collected. The network attachement annotations are then recompiled with the correct list of VIP and policy routes and added to the pod.

Once the annotation modified, the (multus-dynamic-networks-controller
)[https://github.com/k8snetworkplumbingwg/multus-dynamic-networks-controller] will get a notification and call the Multus API, so the CNIs are call and the networks are attached to/detached from the pod.

### Network Service

The stateless load balancer controller manager reconciles the endpoint slices (one for IPv4 and one for IPv6) for the network services. 

## Communication

Here are all components the stateless-load-balancer controller manager is communicating with:

Component | Secured | Method | Description
--- | --- | --- | ---
Kubernetes API | TLS | TCP | Apply/Update/Delete/Watch resources

## Health check

/

## Privileges

/
