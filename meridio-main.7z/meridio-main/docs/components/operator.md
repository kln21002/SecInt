# Operator

## Communication

Here are all components the operator is communicating with:

Component | Secured | Method | Description
--- | --- | --- | ---
Kubernetes API | TLS | TCP | Apply/Update/Delete/Watch resources

## Health check

/

## Privileges

/
