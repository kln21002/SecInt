# Stateless Load Balancer

## Communication

Here are all components the stateless-load-balancer is communicating with:

Component | Secured | Method | Description
--- | --- | --- | ---
Kubernetes API | TLS | TCP | Apply/Update/Delete/Watch resources

## Health check

/

## Privileges

/
