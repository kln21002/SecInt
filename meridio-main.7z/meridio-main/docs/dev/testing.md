# Testing

## Steps

### Kind 

1. Deploy the environment
```
make -s -C test/e2e/environment/kind-helper/ MERIDIO_VERSION=latest KUBERNETES_VERSION=v1.28 IP_FAMILY=ipv4 KUBERNETES_WORKERS=2
```

2. Run the e2e tests
```
make e2e
```
