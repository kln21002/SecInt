# meridio-unit-test

This image is used to run the unit tests in an isolated enviornment since the tests are setting IPs, routes, rules...

Build/Tag/Push
```
make meridio-unit-test
```
