/*
Copyright (c) 2023 Nordix Foundation

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package v1alpha1

import (
	v1discovery "k8s.io/api/discovery/v1"
	"k8s.io/kubernetes/pkg/proxy/apis"
)

const (
	// LabelServiceProxy is used to indicate to which service proxy a
	// service belongs to.
	// It also indicates which resources (flows, gateways, workloads...)
	// belongs to the service proxy.
	// https://kubernetes.io/docs/reference/labels-annotations-taints/#servicekubernetesioservice-proxy-name
	LabelServiceProxy = apis.LabelServiceProxyName

	// LabelService is used to indicate to which service
	// an endpointSlice belongs to.
	// https://kubernetes.io/docs/reference/labels-annotations-taints/#kubernetesioservice-name
	LabelService = v1discovery.LabelServiceName

	// LabelServiceMaxEndpoints defines the maximum number of endpoints that a
	// service can handle.
	LabelServiceMaxEndpoints = "meridio.io/service-max-endpoints"

	// LabelServiceProxyType is used to indicate which type of service
	// a service proxy is handling.
	LabelServiceProxyType = "meridio.io/service-proxy-type"

	// LabelServiceProxyPlane is used to indicate if service proxy resource
	// is used as data-plane or control-place component.
	LabelServiceProxyPlane = "meridio.io/service-proxy-plane"

	// ValueData is used as a value to the LabelServiceProxyPlane label to define a
	// data-plane component.
	ValueDataPlane = "data"
	// ValueData is used as a value to the LabelServiceProxyPlane label to define a
	// control-plane component.
	ValueControlPlane = "control"
)
