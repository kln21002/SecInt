/*
Copyright (c) 2023 Nordix Foundation

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package v1alpha1

import (
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
)

// +genclient
// +k8s:deepcopy-gen:interfaces=k8s.io/apimachinery/pkg/runtime.Object

// Flow is a specification for a Flow resource.
type Flow struct {
	metav1.TypeMeta `json:",inline"`
	// Standard object's metadata.
	// More info: https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#metadata
	// +optional
	metav1.ObjectMeta `json:"metadata,omitempty"`

	// Specification of the desired behavior of the Flow.
	// More info: https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#spec-and-status
	// +optional
	Spec FlowSpec `json:"spec"`

	// Most recently observed status of the Flow.
	// Populated by the system.
	// Read-only.
	// More info: https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#spec-and-status
	// +optional
	Status FlowStatus `json:"status"`
}

// +enum
type TransportProtocol string

const (
	// TCP represents the layer 4 protocol.
	TCP TransportProtocol = "TCP"
	// UDP represents the layer 4 protocol.
	UDP TransportProtocol = "UDP"
	// SCTP represents the layer 4 protocol.
	SCTP TransportProtocol = "SCTP"
)

// FlowSpec is the spec for a Flow resource.
type FlowSpec struct {
	// Destination CIDRs that this flow will send traffic to.
	// The destination CIDRs should not have overlaps.
	//nolint:tagliatelle
	DestinationCIDRs []string `json:"destinationCIDRs"`

	// Source CIDRs allowed in the flow.
	// The source CIDRs should not have overlaps.
	//nolint:tagliatelle
	SourceCIDRs []string `json:"sourceCIDRs,omitempty"`

	// Source port ranges allowed in the flow.
	// The ports should not have overlaps.
	// Ports can be defined by:
	// - a single port, such as 3000;
	// - a port range, such as 3000-4000;
	// - "any", which is equivalent to port range 0-65535.
	SourcePorts []string `json:"sourcePorts,omitempty"`

	// Destination port ranges allowed in the flow.
	// The ports should not have overlaps.
	// Ports can be defined by:
	// - a single port, such as 3000;
	// - a port range, such as 3000-4000;
	// - "any", which is equivalent to port range 0-65535.
	DestinationPorts []string `json:"destinationPorts,omitempty"`

	// Protocols allowed in this flow.
	// The protocols should not have overlaps.
	Protocols []TransportProtocol `json:"protocols"`

	// Priority of the flow
	Priority int32 `json:"priority"`

	// ByteMatches matches bytes in the L4 header in the flow.
	// +optional
	ByteMatches []string `json:"byteMatches,omitempty"`
}

// FlowStatus is the status for a Flow resource.
type FlowStatus struct{}

// +k8s:deepcopy-gen:interfaces=k8s.io/apimachinery/pkg/runtime.Object

// FlowList is a list of Flow resources.
type FlowList struct {
	metav1.TypeMeta `json:",inline"`
	metav1.ListMeta `json:"metadata"`

	Items []Flow `json:"items"`
}

// +k8s:deepcopy-gen:interfaces=k8s.io/apimachinery/pkg/runtime.Object

// Gateway is a specification for a Gateway resource.
type Gateway struct {
	metav1.TypeMeta `json:",inline"`
	// Standard object's metadata.
	// More info: https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#metadata
	// +optional
	metav1.ObjectMeta `json:"metadata,omitempty"`

	// Specification of the desired behavior of the Gateway.
	// More info: https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#spec-and-status
	// +optional
	Spec GatewaySpec `json:"spec"`

	// Most recently observed status of the Gateway.
	// Populated by the system.
	// Read-only.
	// More info: https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#spec-and-status
	// +optional
	Status GatewayStatus `json:"status"`
}

// GatewaySpec defines the desired state of Gateway.
type GatewaySpec struct {
	// Address of the Gateway Router
	Address string `json:"address"`

	// The routing choice between the Gateway Router and Attractor FrontEnds.
	// +optional
	Protocol RoutingProtocol `json:"protocol,omitempty"`

	// Parameters to set up the BGP session to specified Address.
	// If the Protocol is static, this property must be empty.
	// If the Protocol is bgp, the minimal parameters to be defined in bgp properties
	// are RemoteASN and LocalASN
	// +optional
	Bgp BgpSpec `json:"bgp,omitempty"`

	// Parameters to work with the static routing configured on the Gateway Router with specified Address.
	// If the Protocol is bgp, this property must be empty.
	// +optional
	Static StaticSpec `json:"static,omitempty"`
}

// RoutingProtocol represents the routing protocol used in a gateway.
// +enum
type RoutingProtocol string

const (
	// BGP, Border Gateway Protocol.
	BGP RoutingProtocol = "BGP"
	// Static Routing.
	Static RoutingProtocol = "Static"
)

// BgpSpec defines the parameters to set up a BGP session.
type BgpSpec struct {
	// The ASN number of the Gateway Router
	//nolint:tagliatelle
	RemoteASN *uint32 `json:"remoteASN,omitempty"`

	// The ASN number of the system where the Attractor FrontEnds locates
	//nolint:tagliatelle
	LocalASN *uint32 `json:"localASN,omitempty"`

	// BFD monitoring of BGP session.
	// +optional
	BFD BfdSpec `json:"bfd,omitempty"`

	// Hold timer of the BGP session. Please refere to BGP material to understand what this implies.
	// The value must be a valid duration format. For example, 90s, 1m, 1h.
	// The duration will be rounded by second
	// Minimum duration is 3s.
	// +optional
	HoldTime string `json:"holdTime,omitempty"`

	// BGP listening port of the Gateway Router.
	// +optional
	RemotePort *uint16 `json:"remotePort,omitempty"`

	// BGP listening port of the Attractor FrontEnds.
	// +optional
	LocalPort *uint16 `json:"localPort,omitempty"`

	// BGP authentication (RFC2385).
	// +optional
	Auth *BgpAuth `json:"auth,omitempty"`
}

// StaticSpec defines the parameters to set up static routes.
type StaticSpec struct {
	// BFD monitoring of Static session.
	// +optional
	BFD BfdSpec `json:"bfd,omitempty"`
}

// Bfd defines the parameters to configure the BFD session.
// The static gateways shares the same interface shall define the same bfd configuration.
type BfdSpec struct {
	// BFD monitoring.
	// Valid values are:
	// - false: no BFD monitoring;
	// - true: turns on the BFD monitoring.
	// When left empty, there is no BFD monitoring.
	// +optional
	Switch *bool `json:"switch,omitempty"`

	// Min-tx timer of bfd session. Please refere to BFD material to understand what this implies.
	// The value must be a valid duration format. For example, 300ms, 90s, 1m, 1h.
	// The duration will be rounded by millisecond.
	// +optional
	MinTx string `json:"minTx,omitempty"`

	// Min-rx timer of bfd session. Please refere to BFD material to understand what this implies.
	// The value must be a valid duration format. For example, 300ms, 90s, 1m, 1h.
	// The duration will be rounded by millisecond.
	// +optional
	MinRx string `json:"minRx,omitempty"`

	// Multiplier of bfd session.
	// When this number of bfd packets failed to receive, bfd session will go down.
	// +optional
	Multiplier *uint16 `json:"multiplier,omitempty"`
}

// BgpAuth defines the parameters to configure BGP authentication.
type BgpAuth struct {
	// Name of the BGP authentication key, used internally as a reference.
	// KeyName is a key in the data section of a Secret. The associated value in
	// the Secret is the password (pre-shared key) to be used for authentication.
	// Must consist of alphanumeric characters, ".", "-" or "_".
	KeyName string `json:"keyName,omitempty"`

	// Name of the kubernetes Secret containing the password (pre-shared key)
	// that can be looked up based on KeyName.
	// Must be a valid lowercase RFC 1123 subdomain. (Must consist of lower case alphanumeric
	// characters, '-' or '.', and must start and end with an alphanumeric character.)
	KeySource string `json:"keySource,omitempty"`
}

// GatewayStatus is the status for a Gateway resource.
type GatewayStatus struct{}

// +k8s:deepcopy-gen:interfaces=k8s.io/apimachinery/pkg/runtime.Object

// GatewayList is a list of Gateway resources.
type GatewayList struct {
	metav1.TypeMeta `json:",inline"`
	metav1.ListMeta `json:"metadata"`

	Items []Gateway `json:"items"`
}

// +k8s:deepcopy-gen:interfaces=k8s.io/apimachinery/pkg/runtime.Object

// ServiceProxy is a specification for a ServiceProxy resource.
type ServiceProxy struct {
	metav1.TypeMeta `json:",inline"`
	// Standard object's metadata.
	// More info: https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#metadata
	// +optional
	metav1.ObjectMeta `json:"metadata,omitempty"`

	// Specification of the desired behavior of the ServiceProxy.
	// More info: https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#spec-and-status
	// +optional
	Spec ServiceProxySpec `json:"spec"`

	// Most recently observed status of the ServiceProxy.
	// Populated by the system.
	// Read-only.
	// More info: https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#spec-and-status
	// +optional
	Status ServiceProxyStatus `json:"status"`
}

// ServiceType represents the type of service running in this proxy.
// +enum
type ServiceType string

const (
	// StatelessloadbalancerRouter is a stateless load-balancer to handle the service
	// and a router to handle the gateway.
	StatelessloadbalancerRouter ServiceType = "StatelessLoadBalancerRouter"
)

// ServiceProxySpec is the spec for a ServiceProxy resource.
type ServiceProxySpec struct {
	// Type is the type of service running in this proxy.
	Type ServiceType `json:"type"`

	// Replicas is the number of proxy running.
	// +optional
	Replicas *int32 `json:"replicas,omitempty"`

	// Networks are the list of networks serving for the service.
	Networks []Network `json:"networks,omitempty"`
}

// +enum
type MountMethod string

const (
	// MountMountMethod mounts automatically the network on the pod.
	MountMountMethod MountMethod = "Mount"
	// ManualMountMethod lets the user mount the network by himself.
	// This applies only to the endpoints. Selected endpoints without the network
	// mounted will be ignored.
	ManualMountMethod MountMethod = "Manual"
	// NoMountMountMethod will not mount the network.
	NoMountMountMethod MountMethod = "NoMount"
)

// Network represents a single network, its way to attach it, and the way it should be mounted to
// the endpoints and proxy pods.
type Network struct {
	// Name of the network.
	Name string `json:"name,omitempty"`

	// ProxyMountMethod defines the way to mount the network on the proxy pod.
	ProxyMountMethod MountMethod `json:"proxyMountMethod,omitempty"`

	// EndpointMountMethod defines the way to mount the network on the endpoint pod.
	EndpointMountMethod MountMethod `json:"endpointMountMethod,omitempty"`

	// NetworkAttachementAnnotation represents a network attached via an annotation.
	// +optional
	NetworkAttachementAnnotation *NetworkAttachementAnnotation `json:"networkAttachementAnnotation,omitempty"`
}

// NetworkAttachementAnnotation represents a network attached via an annotation.
type NetworkAttachementAnnotation struct {
	// Key of the network attachement (e.g.: k8s.v1.cni.cncf.io/networks).
	Key string `json:"key,omitempty"`

	// StatusKey of the network attachement status (e.g.: k8s.v1.cni.cncf.io/network-status).
	StatusKey string `json:"statusKey,omitempty"`

	// Value added for the "Key" (e.g.: [{"name":"macvlan-vlan-100","interface":"macvlan-100"}]).
	Value string `json:"value,omitempty"`
}

// ServiceProxyStatus is the status for a ServiceProxy resource.
type ServiceProxyStatus struct{}

// +k8s:deepcopy-gen:interfaces=k8s.io/apimachinery/pkg/runtime.Object

// ServiceProxyList is a list of ServiceProxy resources.
type ServiceProxyList struct {
	metav1.TypeMeta `json:",inline"`
	metav1.ListMeta `json:"metadata"`

	Items []ServiceProxy `json:"items"`
}
