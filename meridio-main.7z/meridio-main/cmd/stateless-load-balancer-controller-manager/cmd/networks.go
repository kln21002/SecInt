/*
Copyright (c) 2023 Nordix Foundation

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package cmd

import (
	"encoding/json"
	"fmt"

	"github.com/meridio-io/meridio/api/v1alpha1"
)

// FilterNetworks parses the networks passed as parameter, and filters out the networks that are not
// manually mounted for the endpoints and mounted for the proxies.
func FilterNetworks(networksJSON string) ([]*v1alpha1.Network, error) {
	networks := []v1alpha1.Network{}

	err := json.Unmarshal([]byte(networksJSON), &networks)
	if err != nil {
		return nil, fmt.Errorf("failed to json.Unmarshal networks (%s): %w", networksJSON, err)
	}

	res := []*v1alpha1.Network{}

	for _, network := range networks {
		if network.EndpointMountMethod != v1alpha1.ManualMountMethod ||
			network.ProxyMountMethod != v1alpha1.MountMountMethod {
			continue
		}

		net := network

		res = append(res, &net)
	}

	return res, nil
}
