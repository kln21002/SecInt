/*
Copyright (c) 2023 Nordix Foundation

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package cmd

import (
	"reflect"
	"testing"

	"github.com/meridio-io/meridio/api/v1alpha1"
)

func TestFilterNetworks(t *testing.T) {
	type args struct {
		networksJSON string
	}
	tests := []struct {
		name    string
		args    args
		want    []*v1alpha1.Network
		wantErr bool
	}{
		{
			name: "empty",
			args: args{
				networksJSON: "[]",
			},
			want:    []*v1alpha1.Network{},
			wantErr: false,
		},
		{
			name: "error not json",
			args: args{
				networksJSON: "",
			},
			want:    nil,
			wantErr: true,
		},
		{
			name: "2 networks 1 out",
			args: args{
				networksJSON: `[{"name":"gateway-network","proxyMountMethod":"Mount","endpointMountMethod":"NoMount","networkAttachementAnnotation":{"key":"k8s.v1.cni.cncf.io/networks","statusKey":"k8s.v1.cni.cncf.io/network-status","value":"[{\"name\":\"macvlan-vlan-100\",\"interface\":\"macvlan-100\"},{\"name\":\"vlan-100\",\"interface\":\"vlan-100\"}]"}},{"name":"internal-service-network","proxyMountMethod":"Mount","endpointMountMethod":"Manual","networkAttachementAnnotation":{"key":"k8s.v1.cni.cncf.io/networks","statusKey":"k8s.v1.cni.cncf.io/network-status","value":"[{\"name\":\"macvlan-nad\",\"interface\":\"net1\"}]"}}]`,
			},
			want: []*v1alpha1.Network{
				{
					Name:                "internal-service-network",
					EndpointMountMethod: v1alpha1.ManualMountMethod,
					ProxyMountMethod:    v1alpha1.MountMountMethod,
					NetworkAttachementAnnotation: &v1alpha1.NetworkAttachementAnnotation{
						Key:       "k8s.v1.cni.cncf.io/networks",
						StatusKey: "k8s.v1.cni.cncf.io/network-status",
						Value:     "[{\"name\":\"macvlan-nad\",\"interface\":\"net1\"}]",
					},
				},
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := FilterNetworks(tt.args.networksJSON)
			if (err != nil) != tt.wantErr {
				t.Errorf("FilterNetworks() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("FilterNetworks() = %v, want %v", got, tt.want)
			}
		})
	}
}
